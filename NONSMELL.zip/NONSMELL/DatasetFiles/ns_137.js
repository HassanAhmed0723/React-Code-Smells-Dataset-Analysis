export const BadgeGallery = () => (
    <>
      {SIZES.options.map(size => (
        <div key={size} style={{ marginBottom: 40 }}>
          <h4>{size}</h4>
          {COLORS.options.map(color => (
            <Badge
              count={9}
              textColor={color}
              size={size}
              key={`${color}_${size}`}
              style={{ marginRight: '15px' }}
            />
          ))}
        </div>
      ))}
    </>
  );
  