export const useResultsTableView = (
    chartDataResult: QueryData[] | undefined,
    datasourceId: string,
  ) => {
    if (!isDefined(chartDataResult)) {
      return <div />;
    }
    if (chartDataResult.length === 1) {
      return (
        <PaginationContainer data-test="drill-by-results-table">
          <SingleQueryResultPane
            colnames={chartDataResult[0].colnames}
            coltypes={chartDataResult[0].coltypes}
            data={chartDataResult[0].data}
            dataSize={DATA_SIZE}
            datasourceId={datasourceId}
            isVisible
          />
        </PaginationContainer>
      );
    }
    return (
      <Tabs fullWidth={false} data-test="drill-by-results-tabs">
        {chartDataResult.map((res, index) => (
          <Tabs.TabPane tab={t('Results %s', index + 1)} key={index}>
            <PaginationContainer>
              <SingleQueryResultPane
                colnames={res.colnames}
                coltypes={res.coltypes}
                data={res.data}
                dataSize={DATA_SIZE}
                datasourceId={datasourceId}
                isVisible
              />
            </PaginationContainer>
          </Tabs.TabPane>
        ))}
      </Tabs>
    );
  };