export const Tooltip = ({ overlayStyle, color, ...props }: TooltipProps) => {
    const theme = useTheme();
    const defaultColor = `${theme.colors.grayscale.dark2}e6`;
    return (
      <>
        {/* Safari hack to hide browser default tooltips */}
        <Global
          styles={css`
            .ant-tooltip-open {
              display: inline-block;
              &::after {
                content: '';
                display: block;
              }
            }
          `}
        />
        <BaseTooltip
          overlayStyle={{
            fontSize: theme.typography.sizes.s,
            lineHeight: '1.6',
            maxWidth: theme.gridUnit * 62,
            minWidth: theme.gridUnit * 30,
            ...overlayStyle,
          }}
          // make the tooltip display closer to the label
          align={{ offset: [0, 1] }}
          color={defaultColor || color}
          trigger="hover"
          placement="bottom"
          // don't allow hovering over the tooltip
          mouseLeaveDelay={0}
          {...props}
        />
      </>
    );
  };