export const ThemeColors = () => {
    const { colors } = supersetTheme;
    return Object.keys(colors).map(collection => (
      <div>
        <h2>{collection}</h2>
        <table style={{ width: '300px' }}>
          {Object.keys(colors[collection]).map(k => {
            const hex = colors[collection][k];
            return (
              <tr>
                <td>{k}</td>
                <td>
                  <code>{hex}</code>
                </td>
                <td style={{ width: '150px', backgroundColor: hex }} />
              </tr>
            );
          })}
        </table>
      </div>
    ));
  };