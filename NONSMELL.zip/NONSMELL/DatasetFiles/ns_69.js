export const noFixedRange = () => (
    <SuperChart
      chartType="big-number"
      width={400}
      height={400}
      queriesData={[
        {
          data: testData.slice(0, 9),
          from_dttm: testData[testData.length - 1][TIME_COLUMN],
          to_dttm: testData[0][TIME_COLUMN],
        },
      ]}
      formData={{
        ...formData,
        timeRangeFixed: false,
      }}
    />
  );