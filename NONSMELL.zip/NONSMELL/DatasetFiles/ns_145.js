export const InteractiveIcon = (args: CertifiedBadgeProps) => (
    <CertifiedBadge {...args} />
  );