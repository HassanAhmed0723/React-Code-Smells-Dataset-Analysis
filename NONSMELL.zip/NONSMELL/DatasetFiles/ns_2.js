const StyledSectionHeader = styled('div')<StyledSectionHeaderProps>`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 75px 20px 0;
  max-width: 720px;
  margin: 0 auto;
  ${mq[1]} {
    padding-top: 55px;
  }
  .title,
  .subtitle {
    color: ${props =>
      props.dark
        ? 'var(--ifm-font-base-color-inverse)'
        : 'var(--ifm-font-base-color)'};
  }
`;

const StyledSectionHeaderH1 = styled(StyledSectionHeader)`
  .title {
    font-size: 96px;
    ${mq[1]} {
      font-size: 46px;
    }
  }
  .line {
    margin-top: -45px;
    margin-bottom: 15px;
    ${mq[1]} {
      margin-top: -20px;
      margin-bottom: 30px;
    }
  }
  .subtitle {
    font-size: 30px;
    line-height: 40px;
    ${mq[1]} {
      font-size: 25px;
      line-height: 29px;
    }
  }
`;

const StyledSectionHeaderH2 = styled(StyledSectionHeader)`
  .title {
    font-size: 48px;
    ${mq[1]} {
      font-size: 34px;
    }
  }
  .line {
    margin-top: -15px;
    margin-bottom: 15px;
    ${mq[1]} {
      margin-top: -5px;
    }
  }
  .subtitle {
    font-size: 24px;
    line-height: 32px;
    ${mq[1]} {
      font-size: 18px;
      line-height: 26px;
    }
  }
`;

interface SectionHeaderProps {
  level: any;
  title: string;
  subtitle?: string;
  dark?: boolean;
}

const SectionHeader = ({
  level,
  title,
  subtitle,
  dark,
}: SectionHeaderProps) => {
  const Heading = level;

  const StyledRoot =
    level === 'h1' ? StyledSectionHeaderH1 : StyledSectionHeaderH2;

  return (
    <StyledRoot dark={!!dark}>
      <Heading className="title">{title}</Heading>
      <img className="line" src="/img/community/line.png" alt="line" />
      {subtitle && <p className="subtitle">{subtitle}</p>}
    </StyledRoot>
  );
};