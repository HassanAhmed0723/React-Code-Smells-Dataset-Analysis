export default function EventFlow({
    data,
    initialMinEventCount,
    height = 400,
    width = 400,
  }: EventFlowProps) {
    if (data) {
      return (
        <EventFlowApp
          width={width}
          height={height}
          data={data}
          initialMinEventCount={initialMinEventCount}
          initialShowControls={false}
        />
      );
    }
  
    return (
      <div style={{ height, width }}>
        <div>{t('Sorry, there appears to be no data')}</div>
      </div>
    );
  }