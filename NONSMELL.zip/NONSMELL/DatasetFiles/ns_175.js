export const InteractiveDropdownButton = (args: DropdownButtonProps) => (
    <div style={{ margin: '50px 100px' }}>
      <DropdownButton {...args}>Hover</DropdownButton>
    </div>
  );