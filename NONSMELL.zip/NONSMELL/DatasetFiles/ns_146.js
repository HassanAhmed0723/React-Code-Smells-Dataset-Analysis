export const useContextMenu = (
    chartId: number,
    formData: BaseFormData & { [key: string]: any },
    onSelection?: (...args: any) => void,
    displayedItems?: ContextMenuItem[] | ContextMenuItem,
    additionalConfig?: {
      crossFilter?: Record<string, any>;
      drillToDetail?: Record<string, any>;
      drillBy?: Record<string, any>;
    },
  ) => {
    const contextMenuRef = useRef<ChartContextMenuRef>(null);
    const [inContextMenu, setInContextMenu] = useState(false);
    const onContextMenu = (
      offsetX: number,
      offsetY: number,
      filters: ContextMenuFilters,
    ) => {
      contextMenuRef.current?.open(offsetX, offsetY, filters);
      setInContextMenu(true);
    };
  
    const handleContextMenuSelected = useCallback(
      (...args: any) => {
        setInContextMenu(false);
        onSelection?.(...args);
      },
      [onSelection],
    );
  
    const handleContextMenuClosed = useCallback(() => {
      setInContextMenu(false);
    }, []);
  
    const contextMenu = useMemo(
      () => (
        <ChartContextMenu
          ref={contextMenuRef}
          id={chartId}
          formData={formData}
          onSelection={handleContextMenuSelected}
          onClose={handleContextMenuClosed}
          displayedItems={displayedItems}
          additionalConfig={additionalConfig}
        />
      ),
      [
        additionalConfig,
        chartId,
        displayedItems,
        formData,
        handleContextMenuClosed,
        handleContextMenuSelected,
      ],
    );
    return { contextMenu, inContextMenu, onContextMenu };
  };