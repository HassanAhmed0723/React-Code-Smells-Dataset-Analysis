export default function ErrorMessageWithStackTrace({
    title = DEFAULT_TITLE,
    error,
    subtitle,
    copyText,
    link,
    stackTrace,
    source,
    description,
    fallback,
  }: Props) {
    // Check if a custom error message component was registered for this message
    if (error) {
      const ErrorMessageComponent = getErrorMessageComponentRegistry().get(
        error.error_type,
      );
      if (ErrorMessageComponent) {
        return (
          <ErrorMessageComponent
            error={error}
            source={source}
            subtitle={subtitle}
          />
        );
      }
    }
  
    if (fallback) {
      return <>{fallback}</>;
    }
  
    return (
      <ErrorAlert
        level="warning"
        title={title}
        subtitle={subtitle}
        copyText={copyText}
        description={description}
        source={source}
        body={
          link || stackTrace ? (
            <>
              {link && (
                <a href={link} target="_blank" rel="noopener noreferrer">
                  (Request Access)
                </a>
              )}
              <br />
              {stackTrace && <pre>{stackTrace}</pre>}
            </>
          ) : undefined
        }
      />
    );
  }