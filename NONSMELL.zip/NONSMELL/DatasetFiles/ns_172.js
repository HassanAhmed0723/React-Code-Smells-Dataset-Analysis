export default function WindowedMenuList<OptionType extends OptionTypeBase>({
    children,
    ...props
  }: MenuListProps<OptionType>) {
    const {
      maxHeight,
      selectProps,
      theme,
      getStyles,
      cx,
      innerRef,
      isMulti,
      className,
    } = props;
    const {
      // Expose react-window VariableSizeList instance and HTML elements
      windowListRef: windowListRef_,
      windowListInnerRef,
    } = selectProps;
    const defaultWindowListRef = useRef<WindowedList>(null);
    const windowListRef = windowListRef_ || defaultWindowListRef;
  
    // try get default option height from theme configs
    let { optionHeight } = selectProps;
    if (!optionHeight) {
      optionHeight = theme ? detectHeight(theme) : DEFAULT_OPTION_HEIGHT;
    }
  
    const itemCount = children.length;
    const totalHeight = optionHeight * itemCount;
  
    const Row: FunctionComponent<ListChildComponentProps> = ({
      data,
      index,
      style,
    }) => <div style={style}>{data[index]}</div>;
  
    useEffect(() => {
      const lastSelected = getLastSelected(children);
      if (windowListRef.current && lastSelected) {
        windowListRef.current.scrollToItem(lastSelected);
      }
    }, [children, windowListRef]);
  
    return (
      <WindowedList
        css={getStyles('menuList', props)}
        className={cx(
          {
            'menu-list': true,
            'menu-list--is-multi': isMulti,
          },
          className,
        )}
        ref={windowListRef}
        outerRef={innerRef}
        innerRef={windowListInnerRef}
        height={Math.min(totalHeight, maxHeight)}
        width="100%"
        itemData={children}
        itemCount={children.length}
        itemSize={optionHeight}
      >
        {Row}
      </WindowedList>
    );
  }