export default styled(Partition)`
  ${({ theme }) => `
    .superset-legacy-chart-partition {
      position: relative;
    }

    .superset-legacy-chart-partition .chart {
      display: block;
      margin: auto;
      font-size: ${theme.typography.sizes.s}px;
    }

    .superset-legacy-chart-partition rect {
      stroke: ${theme.colors.grayscale.light2};
      fill: ${theme.colors.grayscale.light1};
      fill-opacity: ${theme.opacity.heavy};
      transition: fill-opacity 180ms linear;
      cursor: pointer;
    }

    .superset-legacy-chart-partition rect:hover {
      fill-opacity: 1;
    }

    .superset-legacy-chart-partition g text {
      font-weight: ${theme.typography.weights.bold};
      fill: ${theme.colors.grayscale.dark1};
    }

    .superset-legacy-chart-partition g:hover text {
      fill: ${theme.colors.grayscale.dark2};
    }

    .superset-legacy-chart-partition .partition-tooltip {
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0;
      padding: ${theme.gridUnit}px;
      pointer-events: none;
      background-color: ${theme.colors.grayscale.dark2};
      border-radius: ${theme.gridUnit}px;
    }

    .partition-tooltip td {
      padding-left: ${theme.gridUnit}px;
      font-size: ${theme.typography.sizes.s}px;
      color: ${theme.colors.grayscale.light5};
    }
  `}
`;