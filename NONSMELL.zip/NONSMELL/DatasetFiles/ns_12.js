export interface BaseControlConfig<
  T extends ControlType = ControlType,
  O extends SelectOption = SelectOption,
  V = JsonValue,
> extends AnyDict {
  type: T;
  label?:
    | ReactNode
    | ((
        state: ControlPanelState,
        controlState: ControlState,
        // TODO: add strict `chartState` typing (see superset-frontend/src/explore/types)
        chartState?: AnyDict,
      ) => ReactNode);
  description?:
    | ReactNode
    | ((
        state: ControlPanelState,
        controlState: ControlState,
        // TODO: add strict `chartState` typing (see superset-frontend/src/explore/types)
        chartState?: AnyDict,
      ) => ReactNode);
  default?: V;
  initialValue?: V;
  renderTrigger?: boolean;
  validators?: ControlValueValidator<T, O, V>[];
  warning?: ReactNode;
  error?: ReactNode;
  /**
   * Add additional props to chart control.
   */
  shouldMapStateToProps?: (
    prevState: ControlPanelState,
    state: ControlPanelState,
    controlState: ControlState,
    // TODO: add strict `chartState` typing (see superset-frontend/src/explore/types)
    chartState?: AnyDict,
  ) => boolean;
  mapStateToProps?: (
    state: ControlPanelState,
    controlState: ControlState,
    // TODO: add strict `chartState` typing (see superset-frontend/src/explore/types)
    chartState?: AnyDict,
  ) => ExtraControlProps;
  visibility?: (
    props: ControlPanelsContainerProps,
    controlData: AnyDict,
  ) => boolean;
}

export interface ControlValueValidator<
  T = ControlType,
  O extends SelectOption = SelectOption,
  V = unknown,
> {
  (value: V, state?: ControlState<T, O>): boolean | string;
}

/** --------------------------------------------
 * Additional Config for specific control Types
 * --------------------------------------------- */
export type SelectOption = AnyDict | string | [ReactText, ReactNode];

export type SelectControlType =
  | 'SelectControl'
  | 'SelectAsyncControl'
  | 'MetricsControl'
  | 'FixedOrMetricControl'
  | 'AdhocFilterControl'
  | 'FilterBoxItemControl';

// via react-select/src/filters
export interface FilterOption<T extends SelectOption> {
  label: string;
  value: string;
  data: T;
}

// Ref: superset-frontend/src/components/Select/SupersetStyledSelect.tsx
export interface SelectControlConfig<
  O extends SelectOption = SelectOption,
  T extends SelectControlType = SelectControlType,
> extends BaseControlConfig<T, O> {
  clearable?: boolean;
  freeForm?: boolean;
  multi?: boolean;
  valueKey?: string;
  labelKey?: string;
  options?: O[];
  optionRenderer?: (option: O) => ReactNode;
  valueRenderer?: (option: O) => ReactNode;
  filterOption?:
    | ((option: FilterOption<O>, rawInput: string) => Boolean)
    | null;
}

export type SharedControlConfig<
  T extends InternalControlType = InternalControlType,
  O extends SelectOption = SelectOption,
> = T extends SelectControlType
  ? SelectControlConfig<O, T>
  : BaseControlConfig<T>;

/** --------------------------------------------
 * Custom controls
 * --------------------------------------------- */
export type CustomControlConfig<P = {}> = BaseControlConfig<
  React.ComponentType<P>
> &
  // two run-time properties from superset-frontend/src/explore/components/Control.jsx
  Omit<P, 'onChange' | 'hovered'>;

// Catch-all ControlConfig
//  - if T is known control types, return SharedControlConfig,
//  - if T is object, assume a CustomComponent
//  - otherwise assume it's a custom component control
export type ControlConfig<
  T = AnyDict,
  O extends SelectOption = SelectOption,
> = T extends InternalControlType
  ? SharedControlConfig<T, O>
  : T extends object
  ? CustomControlConfig<T> // eslint-disable-next-line @typescript-eslint/no-explicit-any
  : CustomControlConfig<any>;

/** ===========================================================
 * Chart plugin control panel config
 * ========================================================= */
export type SharedSectionAlias =
  | 'annotations'
  | 'colorScheme'
  | 'datasourceAndVizType'
  | 'sqlaTimeSeries'
  | 'NVD3TimeSeries';

export interface OverrideSharedControlItem<
  A extends SharedControlAlias = SharedControlAlias,
> {
  name: A;
  override: Partial<SharedControls[A]>;
}

export type CustomControlItem = {
  name: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  config: BaseControlConfig<any, any, any>;
};

// use ReactElement instead of ReactNode because `string`, `number`, etc. may
// interfere with other ControlSetItem types
export type ExpandedControlItem = CustomControlItem | ReactElement | null;

export type ControlSetItem =
  | SharedControlAlias
  | OverrideSharedControlItem
  | ExpandedControlItem;

export type ControlSetRow = ControlSetItem[];

// Ref:
//  - superset-frontend/src/explore/components/ControlPanelsContainer.jsx
//  - superset-frontend/src/explore/components/ControlPanelSection.jsx
export interface ControlPanelSectionConfig {
  label?: ReactNode;
  description?: ReactNode;
  expanded?: boolean;
  tabOverride?: TabOverride;
  controlSetRows: ControlSetRow[];
}

export interface StandardizedControls {
  metrics: QueryFormMetric[];
  columns: QueryFormColumn[];
}

export interface StandardizedFormDataInterface {
  // Controls not used in the current viz
  controls: StandardizedControls;
  // Transformation history
  memorizedFormData: Map<string, QueryFormData>;
}

export type QueryStandardizedFormData = QueryFormData & {
  standardizedFormData: StandardizedFormDataInterface;
};

export const isStandardizedFormData = (
  formData: QueryFormData,
): formData is QueryStandardizedFormData =>
  formData?.standardizedFormData?.controls &&
  formData?.standardizedFormData?.memorizedFormData &&
  Array.isArray(formData.standardizedFormData.controls.metrics) &&
  Array.isArray(formData.standardizedFormData.controls.columns);

export interface ControlPanelConfig {
  controlPanelSections: (ControlPanelSectionConfig | null)[];
  controlOverrides?: ControlOverrides;
  sectionOverrides?: SectionOverrides;
  onInit?: (state: ControlStateMapping) => void;
  formDataOverrides?: (formData: QueryFormData) => QueryFormData;
}

export type ControlOverrides = {
  [P in SharedControlAlias]?: Partial<SharedControls[P]>;
};

export type SectionOverrides = {
  [P in SharedSectionAlias]?: Partial<ControlPanelSectionConfig>;
};

// Ref:
//  - superset-frontend/src/explore/components/ConditionalFormattingControl.tsx
export enum COMPARATOR {
  NONE = 'None',
  GREATER_THAN = '>',
  LESS_THAN = '<',
  GREATER_OR_EQUAL = 'â‰¥',
  LESS_OR_EQUAL = 'â‰¤',
  EQUAL = '=',
  NOT_EQUAL = 'â‰ ',
  BETWEEN = '< x <',
  BETWEEN_OR_EQUAL = 'â‰¤ x â‰¤',
  BETWEEN_OR_LEFT_EQUAL = 'â‰¤ x <',
  BETWEEN_OR_RIGHT_EQUAL = '< x â‰¤',
}

export const MULTIPLE_VALUE_COMPARATORS = [
  COMPARATOR.BETWEEN,
  COMPARATOR.BETWEEN_OR_EQUAL,
  COMPARATOR.BETWEEN_OR_LEFT_EQUAL,
  COMPARATOR.BETWEEN_OR_RIGHT_EQUAL,
];

export type ConditionalFormattingConfig = {
  operator?: COMPARATOR;
  targetValue?: number;
  targetValueLeft?: number;
  targetValueRight?: number;
  column?: string;
  colorScheme?: string;
};

export type ColorFormatters = {
  column: string;
  getColorFromValue: (value: number) => string | undefined;
}[];

export default {};

export function isColumnMeta(column: AnyDict): column is ColumnMeta {
  return !!column && 'column_name' in column;
}

export function isSavedExpression(
  column: AdhocColumn | ColumnMeta,
): column is ColumnMeta {
  return (
    'column_name' in column && 'expression' in column && !!column.expression
  );
}

export function isControlPanelSectionConfig(
  section: ControlPanelSectionConfig | null,
): section is ControlPanelSectionConfig {
  return section !== null;
}

export function isDataset(
  datasource: Dataset | QueryResponse | null | undefined,
): datasource is Dataset {
  return !!datasource && 'columns' in datasource;
}

export function isQueryResponse(
  datasource: Dataset | QueryResponse | null | undefined,
): datasource is QueryResponse {
  return !!datasource && 'results' in datasource && 'sql' in datasource;
}

export enum SortSeriesType {
  Name = 'name',
  Max = 'max',
  Min = 'min',
  Sum = 'sum',
  Avg = 'avg',
}

export type SortSeriesData = {
  sort_series_type: SortSeriesType;
  sort_series_ascending: boolean;
};

export type ControlFormValueValidator<V> = (value: V) => string | false;

export type ControlFormItemSpec<T extends ControlType = ControlType> = {
  controlType: T;
  label: ReactNode;
  description: ReactNode;
  placeholder?: string;
  validators?: ControlFormValueValidator<any>[];
  width?: number | string;
  /**
   * Time to delay change propagation.
   */
  debounceDelay?: number;
} & (T extends 'Select'
  ? {
      options: any;
      value?: string;
      defaultValue?: string;
      creatable?: boolean;
      minWidth?: number | string;
      validators?: ControlFormValueValidator<string>[];
    }
  : T extends 'RadioButtonControl'
  ? {
      options: [string, ReactNode][];
      value?: string;
      defaultValue?: string;
    }
  : T extends 'Checkbox'
  ? {
      value?: boolean;
      defaultValue?: boolean;
    }
  : T extends 'InputNumber' | 'Slider'
  ? {
      min?: number;
      max?: number;
      step?: number;
      value?: number;
      defaultValue?: number;
      validators?: ControlFormValueValidator<number>[];
    }
  : T extends 'Input'
  ? {
      controlType: 'Input';
      value?: string;
      defaultValue?: string;
      validators?: ControlFormValueValidator<string>[];
    }
  : T extends 'CurrencyControl'
  ? {
      controlType: 'CurrencyControl';
      value?: Currency;
      defaultValue?: Currency;
    }
  : {});