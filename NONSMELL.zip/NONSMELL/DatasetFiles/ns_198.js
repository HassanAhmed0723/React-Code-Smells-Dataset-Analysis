export const InteractiveIconButton = (args: IconButtonProps) => (
    <IconButton
      buttonText={args.buttonText}
      altText={args.altText}
      icon={args.icon}
      href={args.href}
      target={args.target}
      htmlType={args.htmlType}
    />
  );