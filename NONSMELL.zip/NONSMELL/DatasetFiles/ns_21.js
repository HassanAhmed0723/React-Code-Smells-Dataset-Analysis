export function InfoTooltipWithTrigger({
    label,
    tooltip,
    bsStyle,
    onClick,
    icon = 'info-circle',
    className = 'text-muted',
    placement = 'right',
    iconsStyle = {},
  }: InfoTooltipWithTriggerProps) {
    const iconClass = `fa fa-${icon} ${className} ${
      bsStyle ? `text-${bsStyle}` : ''
    }`;
    const iconEl = (
      <i
        role="button"
        aria-label={t('Show info tooltip')}
        tabIndex={0}
        className={iconClass}
        style={{ cursor: onClick ? 'pointer' : undefined, ...iconsStyle }}
        onClick={onClick}
        onKeyPress={
          onClick &&
          (event => {
            if (event.key === 'Enter' || event.key === ' ') {
              onClick();
            }
          })
        }
      />
    );
    if (!tooltip) {
      return iconEl;
    }
    return (
      <Tooltip
        id={`${kebabCase(label)}-tooltip`}
        title={tooltip}
        placement={placement}
      >
        {iconEl}
      </Tooltip>
    );
  }