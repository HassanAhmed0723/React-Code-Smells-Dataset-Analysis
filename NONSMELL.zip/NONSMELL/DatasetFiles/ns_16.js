export default function FallbackComponent({
    componentStack,
    error,
    height,
    width,
  }: Props) {
    return (
      <div
        css={(theme: SupersetTheme) => ({
          backgroundColor: theme.colors.grayscale.dark2,
          color: theme.colors.grayscale.light5,
          overflow: 'auto',
          padding: 32,
        })}
        style={{ height, width }}
      >
        <div>
          <div>
            <b>{t('Oops! An error occurred!')}</b>
          </div>
          <code>{error ? error.toString() : 'Unknown Error'}</code>
        </div>
        {componentStack && (
          <div>
            <b>{t('Stack Trace:')}</b>
            <code>
              {componentStack.split('\n').map((row: string) => (
                <div key={row}>{row}</div>
              ))}
            </code>
          </div>
        )}
      </div>
    );
  }