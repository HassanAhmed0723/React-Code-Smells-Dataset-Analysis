export const BigEmptyState = () => (
    <EmptyStateBig
      image={<EmptyImage />}
      title="Big empty state"
      description="This is an example of a big empty state"
    />
  );