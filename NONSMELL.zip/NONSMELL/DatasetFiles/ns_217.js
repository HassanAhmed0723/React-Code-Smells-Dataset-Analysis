export const dataProvider = () => {
    const host = text('Set Superset App host for CORS request', 'localhost:8088');
    const visType = select('Chart Plugin Type', VIS_TYPES, VIS_TYPES[0]);
    const width = text('Vis width', '500');
    const height = text('Vis height', '300');
    const formData = text(
      'Override formData',
      JSON.stringify(FORM_DATA_LOOKUP[visType]),
    );
  
    return (
      <div style={{ margin: 16 }}>
        <VerifyCORS host={host}>
          {() => (
            <ChartDataProvider
              client={SupersetClient}
              formData={JSON.parse(formData)}
            >
              {({ loading, payload, error }) => {
                if (loading) return <div>Loading!</div>;
  
                if (error) return renderError(error);
  
                if (payload)
                  return (
                    <>
                      <SuperChart
                        chartType={visType}
                        formData={payload.formData}
                        height={Number(height)}
                        // @TODO fix typing
                        // all vis's now expect objects but api/v1/ returns an array
                        queriesData={payload.queriesData}
                        width={Number(width)}
                      />
                      <br />
                      <Expandable expandableWhat="payload">
                        <pre style={{ fontSize: 11 }}>
                          {JSON.stringify(payload, null, 2)}
                        </pre>
                      </Expandable>
                    </>
                  );
  
                return null;
              }}
            </ChartDataProvider>
          )}
        </VerifyCORS>
      </div>
    );
  };