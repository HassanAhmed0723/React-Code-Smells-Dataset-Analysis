export const ChartErrorMessage: React.FC<Props> = ({
    chartId,
    error,
    ...props
  }) => {
    const { result: owners } = useChartOwnerNames(chartId);
  
    // don't mutate props
    const ownedError = error && {
      ...error,
      extra: { ...error.extra, owners },
    };
  
    return <ErrorMessageWithStackTrace {...props} error={ownedError} />;
  };