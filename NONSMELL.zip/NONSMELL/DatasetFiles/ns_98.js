export const getLayer: getLayerType<unknown> = (
    formData,
    payload,
    onAddFilter,
    setTooltip,
  ) => {
    const fd = formData;
    const {
      intensity = 1,
      radius_pixels: radiusPixels = 30,
      aggregation = 'SUM',
      js_data_mutator: jsFnMutator,
      linear_color_scheme: colorScheme,
    } = fd;
    let data = payload.data.features;
  
    if (jsFnMutator) {
      // Applying user defined data mutator if defined
      const jsFnMutatorFunction = sandboxedEval(fd.js_data_mutator);
      data = jsFnMutatorFunction(data);
    }
  
    const colorScale = getSequentialSchemeRegistry()
      ?.get(colorScheme)
      ?.createLinearScale([0, 6]);
    const colorRange = colorScale
      ?.range()
      ?.map(color => hexToRGB(color))
      ?.reverse() as Color[];
  
    return new HeatmapLayer({
      id: `heatmp-layer-${fd.slice_id}` as const,
      data,
      intensity,
      radiusPixels,
      colorRange,
      aggregation: aggregation.toUpperCase(),
      getPosition: (d: { position: Position; weight: number }) => d.position,
      getWeight: (d: { position: number[]; weight: number }) =>
        d.weight ? d.weight : 1,
      ...commonLayerProps(fd, setTooltip, setTooltipContent),
    });
  };
  