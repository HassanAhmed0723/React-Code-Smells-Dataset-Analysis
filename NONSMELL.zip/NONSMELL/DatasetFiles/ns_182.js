export const BigEmptyStateWithButton = () => (
    <EmptyStateBig
      image={<ChartImage />}
      title="Big empty state"
      description="This is an example of a big empty state with a button"
      buttonText="Click!"
      buttonAction={() => {}}
    />
  );