export function ColumnTypeLabel({ type }: ColumnTypeLabelProps) {
    let typeIcon: ReactNode = (
      <QuestionOutlined aria-label={t('unknown type icon')} />
    );
  
    if (type === '' || type === 'expression') {
      typeIcon = <FunctionSvg aria-label={t('function type icon')} />;
    } else if (type === GenericDataType.STRING) {
      typeIcon = <StringSvg aria-label={t('string type icon')} />;
    } else if (type === GenericDataType.NUMERIC) {
      typeIcon = <NumSvg aria-label={t('numeric type icon')} />;
    } else if (type === GenericDataType.BOOLEAN) {
      typeIcon = <BooleanSvg aria-label={t('boolean type icon')} />;
    } else if (type === GenericDataType.TEMPORAL) {
      typeIcon = <ClockCircleOutlined aria-label={t('temporal type icon')} />;
    }
  
    return <TypeIconWrapper>{typeIcon}</TypeIconWrapper>;
  }