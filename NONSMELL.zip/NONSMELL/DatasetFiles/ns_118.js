const dndAllColumns: typeof sharedControls.groupby = {
    type: 'DndColumnSelect',
    label: t('Columns'),
    description: t('Columns to display'),
    default: [],
    mapStateToProps({ datasource, controls }, controlState) {
      const newState: ExtraControlProps = {};
      if (datasource) {
        if (datasource?.columns[0]?.hasOwnProperty('filterable')) {
          newState.options = (datasource as Dataset)?.columns?.filter(
            (c: ColumnMeta) => c.filterable,
          );
        } else newState.options = datasource.columns;
      }
      newState.queryMode = getQueryMode(controls);
      newState.externalValidationErrors =
        isRawMode({ controls }) && ensureIsArray(controlState?.value).length === 0
          ? [t('must have a value')]
          : [];
      return newState;
    },
    visibility: isRawMode,
    resetOnHide: false,
  };