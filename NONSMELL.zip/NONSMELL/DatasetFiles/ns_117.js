const allColumns: typeof sharedControls.groupby = {
    type: 'SelectControl',
    label: t('Columns'),
    description: t('Columns to display'),
    multi: true,
    freeForm: true,
    allowAll: true,
    commaChoosesOption: false,
    default: [],
    optionRenderer: c => <ColumnOption showType column={c} />,
    valueRenderer: c => <ColumnOption column={c} />,
    valueKey: 'column_name',
    mapStateToProps: ({ datasource, controls }, controlState) => ({
      options: datasource?.columns || [],
      queryMode: getQueryMode(controls),
      externalValidationErrors:
        isRawMode({ controls }) && ensureIsArray(controlState?.value).length === 0
          ? [t('must have a value')]
          : [],
    }),
    visibility: isRawMode,
    resetOnHide: false,
  };
  