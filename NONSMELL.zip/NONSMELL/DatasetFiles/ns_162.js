export const InteractiveCollapse = (args: CollapseProps) => {
    const theme = useTheme();
    return (
      <Collapse
        defaultActiveKey={['1']}
        style={
          args.light ? { background: theme.colors.grayscale.light2 } : undefined
        }
        {...args}
      >
        <Collapse.Panel header="Header 1" key="1">
          Content 1
        </Collapse.Panel>
        <Collapse.Panel header="Header 2" key="2">
          Content 2
        </Collapse.Panel>
      </Collapse>
    );
  };