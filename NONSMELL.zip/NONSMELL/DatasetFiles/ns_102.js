const DeckGLScreenGrid = (props: DeckGLScreenGridProps) => {
    const containerRef = useRef<DeckGLContainerHandle>();
  
    const getAdjustedViewport = useCallback(() => {
      const features = props.payload.data.features || [];
  
      const { width, height, formData } = props;
  
      if (formData.autozoom) {
        return fitViewport(props.viewport, {
          width,
          height,
          points: getPoints(features),
        });
      }
      return props.viewport;
    }, [props]);
  
    const [stateFormData, setStateFormData] = useState(props.payload.form_data);
    const [viewport, setViewport] = useState(getAdjustedViewport());
  
    useEffect(() => {
      if (props.payload.form_data !== stateFormData) {
        setViewport(getAdjustedViewport());
        setStateFormData(props.payload.form_data);
      }
    }, [getAdjustedViewport, props.payload.form_data, stateFormData]);
  
    const setTooltip = useCallback((tooltip: TooltipProps['tooltip']) => {
      const { current } = containerRef;
      if (current) {
        current.setTooltip(tooltip);
      }
    }, []);
  
    const getLayers = useCallback(() => {
      const layer = getLayer(props.formData, props.payload, noop, setTooltip);
  
      return [layer];
    }, [props.formData, props.payload, setTooltip]);
  
    const { formData, payload, setControlValue } = props;
  
    return (
      <div>
        <DeckGLContainerStyledWrapper
          ref={containerRef}
          viewport={viewport}
          layers={getLayers()}
          setControlValue={setControlValue}
          mapStyle={formData.mapbox_style}
          mapboxApiAccessToken={payload.data.mapboxApiKey}
          width={props.width}
          height={props.height}
        />
      </div>
    );
  };