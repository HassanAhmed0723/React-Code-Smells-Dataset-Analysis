export function useExtraControl<
  F extends {
    stack: any;
    area: boolean;
  },
>({
  formData,
  setControlValue,
}: {
  formData: F;
  setControlValue?: HandlerFunction;
}) {
  const { stack, area } = formData;
  const [extraValue, setExtraValue] = useState<JsonValue | undefined>(
    stack ?? undefined,
  );

  useEffect(() => {
    setExtraValue(stack);
  }, [stack]);

  const extraControlsOptions = useMemo(() => {
    if (area) {
      return AreaChartStackControlOptions;
    }
    return [];
  }, [area]);

  const extraControlsHandler = useCallback(
    (value: RadioButtonOption[0]) => {
      if (area) {
        if (setControlValue) {
          setControlValue('stack', value);
          setExtraValue(value);
        }
      }
    },
    [area, setControlValue],
  );

  return {
    extraControlsOptions,
    extraControlsHandler,
    extraValue,
  };
}