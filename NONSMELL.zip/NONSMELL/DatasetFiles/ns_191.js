export const InteractiveTable = (args: FilterableTableProps) => (
    <div css={{ maxWidth: 700 }}>
      <FilterableTable {...args} />
    </div>
  );