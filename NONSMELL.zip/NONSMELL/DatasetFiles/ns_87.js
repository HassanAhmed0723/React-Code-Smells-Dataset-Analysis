const SankeyComponent = ({ className, ...otherProps }) => (
    <div className={className}>
      <ReactSanKey {...otherProps} />
    </div>
  );
  
  SankeyComponent.propTypes = {
    className: PropTypes.string.isRequired,
  };
  
  export default styled(SankeyComponent)`
    ${({ theme }) => `
      .superset-legacy-chart-sankey {
        .node {
          rect {
            cursor: move;
            fill-opacity: ${theme.opacity.heavy};
            shape-rendering: crispEdges;
          }
          text {
            pointer-events: none;
            text-shadow: 0 1px 0 ${theme.colors.grayscale.light5};
            font-size: ${theme.typography.sizes.s}px;
          }
        }
        .link {
          fill: none;
          stroke: ${theme.colors.grayscale.dark2};
          stroke-opacity: ${theme.opacity.light};
          &:hover {
            stroke-opacity: ${theme.opacity.mediumLight};
          }
        }
        .opacity-0 {
          opacity: 0;
        }
      }
      .sankey-tooltip {
        position: absolute;
        width: auto;
        background: ${theme.colors.grayscale.light2};
        padding: ${theme.gridUnit * 3}px;
        font-size: ${theme.typography.sizes.s}px;
        color: ${theme.colors.grayscale.dark2};
        border: 1px solid ${theme.colors.grayscale.light5};
        text-align: center;
        pointer-events: none;
      }
    `}
  `;