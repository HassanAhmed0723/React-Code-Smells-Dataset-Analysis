const useCSSTextTruncation = <T extends HTMLElement>(): [
    React.RefObject<T>,
    boolean,
  ] => {
    const [isTruncated, setIsTruncated] = useState(true);
    const ref = useRef<T>(null);
    const [offsetWidth, setOffsetWidth] = useState(0);
    const [scrollWidth, setScrollWidth] = useState(0);
  
    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(() => {
      setOffsetWidth(ref.current?.offsetWidth ?? 0);
      setScrollWidth(ref.current?.scrollWidth ?? 0);
    });
  
    useEffect(() => {
      setIsTruncated(offsetWidth < scrollWidth);
    }, [offsetWidth, scrollWidth]);
  
    return [ref, isTruncated];
  };
  