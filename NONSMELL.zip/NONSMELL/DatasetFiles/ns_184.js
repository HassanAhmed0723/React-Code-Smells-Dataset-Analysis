function DatabaseErrorMessage({
    error,
    source = 'dashboard',
    subtitle,
  }: ErrorMessageComponentProps<DatabaseErrorExtra>) {
    const { extra, level, message } = error;
  
    const isVisualization = ['dashboard', 'explore'].includes(source);
  
    const body = extra && (
      <>
        <p>
          {t('This may be triggered by:')}
          <br />
          {extra.issue_codes
            .map<React.ReactNode>(issueCode => (
              <IssueCode {...issueCode} key={issueCode.code} />
            ))
            .reduce((prev, curr) => [prev, <br />, curr])}
        </p>
        {isVisualization && extra.owners && (
          <>
            <br />
            <p>
              {tn(
                'Please reach out to the Chart Owner for assistance.',
                'Please reach out to the Chart Owners for assistance.',
                extra.owners.length,
              )}
            </p>
            <p>
              {tn(
                'Chart Owner: %s',
                'Chart Owners: %s',
                extra.owners.length,
                extra.owners.join(', '),
              )}
            </p>
          </>
        )}
      </>
    );