export const InteractiveCheckbox = ({ checked, style }: CheckboxProps) => {
    const [, updateArgs] = useArgs();
    const toggleCheckbox = () => {
      updateArgs({ checked: !checked });
    };
  
    return (
      <>
        <Checkbox onChange={toggleCheckbox} checked={checked} style={style} />
        I'm an interactive checkbox
      </>
    );
  };