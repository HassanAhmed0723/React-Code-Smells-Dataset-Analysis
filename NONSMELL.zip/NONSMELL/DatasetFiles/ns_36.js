export const totalNoData = () => (
    <SuperChart
      chartType="big-number-total"
      width={400}
      height={400}
      queriesData={[{ data: [] }]}
      formData={{
        metric: 'sum__num',
        subheader: 'total female participants',
        vizType: 'big_number_total',
        yAxisFormat: '.3s',
      }}
    />
  );