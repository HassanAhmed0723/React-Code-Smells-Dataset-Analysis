export const Resizable = () => (
    <ResizableChartDemo>
      {size => (
        <SuperChart
          chartType={ChartKeys.DILIGENT}
          width={size.width}
          height={size.height}
          queriesData={[DEFAULT_QUERY_DATA]}
        />
      )}
    </ResizableChartDemo>
  );