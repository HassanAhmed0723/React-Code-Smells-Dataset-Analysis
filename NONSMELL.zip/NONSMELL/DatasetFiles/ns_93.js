export function getLayer(
    fd: QueryFormData,
    payload: JsonObject,
    onAddFilter: HandlerFunction,
    setTooltip: (tooltip: TooltipProps['tooltip']) => void,
  ) {
    const data = payload.data.features;
    const sc = fd.color_picker;
    const tc = fd.target_color_picker;
  
    return new ArcLayer({
      data,
      getSourceColor: d =>
        d.sourceColor || d.color || [sc.r, sc.g, sc.b, 255 * sc.a],
      getTargetColor: d =>
        d.targetColor || d.color || [tc.r, tc.g, tc.b, 255 * tc.a],
      id: `path-layer-${fd.slice_id}` as const,
      strokeWidth: fd.stroke_width ? fd.stroke_width : 3,
      ...commonLayerProps(fd, setTooltip, setTooltipContent(fd)),
    });
  }