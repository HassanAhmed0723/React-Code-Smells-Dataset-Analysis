export default function reactify<Props extends object>(
    renderFn: RenderFuncType<Props>,
    callbacks?: LifeCycleCallbacks,
  ): React.ComponentClass<Props & ReactifyProps> {
    class ReactifiedComponent extends React.Component<Props & ReactifyProps> {
      container?: HTMLDivElement;
  
      constructor(props: Props & ReactifyProps) {
        super(props);
        this.setContainerRef = this.setContainerRef.bind(this);
      }
  
      componentDidMount() {
        this.execute();
      }
  
      componentDidUpdate() {
        this.execute();
      }
  
      componentWillUnmount() {
        this.container = undefined;
        if (callbacks?.componentWillUnmount) {
          callbacks.componentWillUnmount.bind(this)();
        }
      }
  
      setContainerRef(ref: HTMLDivElement) {
        this.container = ref;
      }
  
      execute() {
        if (this.container) {
          renderFn(this.container, this.props);
        }
      }
  
      render() {
        const { id, className } = this.props;
  
        return <div ref={this.setContainerRef} id={id} className={className} />;
      }
    }
  
    const ReactifiedClass: React.ComponentClass<Props & ReactifyProps> =
      ReactifiedComponent;
  
    if (renderFn.displayName) {
      ReactifiedClass.displayName = renderFn.displayName;
    }
    // eslint-disable-next-line react/forbid-foreign-prop-types
    if (renderFn.propTypes) {
      ReactifiedClass.propTypes = {
        ...ReactifiedClass.propTypes,
        ...renderFn.propTypes,
      };
    }
    if (renderFn.defaultProps) {
      ReactifiedClass.defaultProps = renderFn.defaultProps;
    }
  
    return ReactifiedComponent;
  }