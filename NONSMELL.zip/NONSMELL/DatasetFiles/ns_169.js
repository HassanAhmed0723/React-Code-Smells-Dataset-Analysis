export const InteractiveRangePicker = (args: RangePickerProps) => (
    <RangePicker {...args} />
  );
  