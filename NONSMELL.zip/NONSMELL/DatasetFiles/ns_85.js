const Rose = ({ className, ...otherProps }) => (
    <div className={className}>
      <Global
        styles={theme => css`
          .tooltip {
            line-height: 1;
            padding: ${theme.gridUnit * 3}px;
            background: ${theme.colors.grayscale.dark2};
            color: ${theme.colors.grayscale.light5};
            border-radius: 4px;
            pointer-events: none;
            z-index: 1000;
            font-size: ${theme.typography.sizes.s}px;
          }
        `}
      />
      <ReactComponent {...otherProps} />
    </div>
  );
  
  export default styled(Rose)`
    ${({ theme }) => `
      .superset-legacy-chart-rose path {
          transition: fill-opacity 180ms linear;
          stroke: ${theme.colors.grayscale.light5};
          stroke-width: 1px;
          stroke-opacity: 1;
          fill-opacity: 0.75;
      }
  
      .superset-legacy-chart-rose text {
          font-weight: ${theme.typography.weights.normal};
          font-size: ${theme.typography.sizes.s}px;
          font-family: ${theme.typography.families.sansSerif};
          pointer-events: none;
      }
  
      .superset-legacy-chart-rose .clickable path {
          cursor: pointer;
      }
  
      .superset-legacy-chart-rose .hover path {
          fill-opacity: 1;
      }
  
      .nv-legend .nv-series {
          cursor: pointer;
      }
    `}
  `;
  