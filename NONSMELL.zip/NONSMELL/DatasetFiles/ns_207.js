export function ControlFormItem({
    name,
    label,
    description,
    width,
    validators,
    required,
    onChange,
    value: initialValue,
    defaultValue,
    controlType,
    ...props
  }: ControlFormItemProps) {
    const { gridUnit } = useTheme();
    const [hovered, setHovered] = useState(false);
    const [value, setValue] = useState(
      initialValue === undefined ? defaultValue : initialValue,
    );
    const [validationErrors, setValidationErrors] =
      useState<ControlHeaderProps['validationErrors']>();
  
    const handleChange = (e: ChangeEvent<HTMLInputElement> | JsonValue) => {
      const fieldValue =
        e && typeof e === 'object' && 'target' in e
          ? e.target.type === 'checkbox' || e.target.type === 'radio'
            ? e.target.checked
            : e.target.value
          : e;
      const errors =
        (validators
          ?.map(validator =>
            !required && isEmptyValue(fieldValue) ? false : validator(fieldValue),
          )
          .filter(x => !!x) as string[]) || [];
      setValidationErrors(errors);
      setValue(fieldValue);
      if (errors.length === 0 && onChange) {
        onChange(fieldValue as JsonValue);
      }
    };
  
    const Control = ControlFormItemComponents[controlType];
  
    return (
      <div
        css={{
          margin: 2 * gridUnit,
          width,
        }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        {controlType === 'Checkbox' ? (
          <ControlFormItemComponents.Checkbox
            checked={value as boolean}
            onChange={handleChange}
          >
            {label}{' '}
            {hovered && description && (
              <InfoTooltipWithTrigger tooltip={description} />
            )}
          </ControlFormItemComponents.Checkbox>
        ) : (
          <>
            {label && (
              <ControlHeader
                name={name}
                label={label}
                description={description}
                validationErrors={validationErrors}
                hovered={hovered}
                required={required}
              />
            )}
            {/* @ts-ignore */}
            <Control {...props} value={value} onChange={handleChange} />
          </>
        )}
      </div>
    );
  }
  