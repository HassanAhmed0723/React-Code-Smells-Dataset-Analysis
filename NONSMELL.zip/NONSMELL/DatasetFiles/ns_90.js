export default styled(WorldMapComponent)`
  .superset-legacy-chart-world-map {
    position: relative;
    svg {
      background-color: ${({ theme }) => theme.colors.grayscale.light5};
    }
  }
`;