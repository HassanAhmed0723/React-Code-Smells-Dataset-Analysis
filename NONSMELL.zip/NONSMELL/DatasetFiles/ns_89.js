const WorldMapComponent = ({ className, ...otherProps }) => {
    const theme = useTheme();
    return (
      <div className={className}>
        <ReactWorldMap {...otherProps} theme={theme} />
      </div>
    );
  };
  
  WorldMapComponent.propTypes = {
    className: PropTypes.string.isRequired,
  };