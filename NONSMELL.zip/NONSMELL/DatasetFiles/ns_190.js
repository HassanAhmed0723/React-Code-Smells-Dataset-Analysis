export const SupersetFacePile = () => (
    <FacePile users={users} maxCount={number('maxCount', 4)} />
  );