export const InteractiveEditableTitle = (props: EditableTitleProps) => (
    <EditableTitle {...props} />
  );