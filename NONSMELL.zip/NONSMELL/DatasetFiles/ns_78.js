export default styled(Heatmap)`
  ${({ theme }) => `
    .superset-legacy-chart-heatmap {
      position: relative;
      top: 0;
      left: 0;
      height: 100%;
    }

    .superset-legacy-chart-heatmap .axis text {
      font-size: ${theme.typography.sizes.xs}px;
      text-rendering: optimizeLegibility;
    }

    .superset-legacy-chart-heatmap .background-rect {
      stroke: ${theme.colors.grayscale.light2};
      fill-opacity: 0;
      pointer-events: all;
    }

    .superset-legacy-chart-heatmap .axis path,
    .superset-legacy-chart-heatmap .axis line {
      fill: none;
      stroke: ${theme.colors.grayscale.light2};
      shape-rendering: crispEdges;
    }

    .superset-legacy-chart-heatmap canvas,
    .superset-legacy-chart-heatmap img {
      image-rendering: optimizeSpeed; /* Older versions of FF */
      image-rendering: -moz-crisp-edges; /* FF 6.0+ */
      image-rendering: -webkit-optimize-contrast; /* Safari */
      image-rendering: -o-crisp-edges; /* OS X & Windows Opera (12.02+) */
      image-rendering: pixelated; /* Awesome future-browsers */
      -ms-interpolation-mode: nearest-neighbor; /* IE */
    }

    .superset-legacy-chart-heatmap .legendCells text {
      font-size: ${theme.typography.sizes.xs}px;
      font-weight: ${theme.typography.weights.normal};
      opacity: 0;
    }

    .superset-legacy-chart-heatmap .legendCells .cell:first-child text {
      opacity: 1;
    }

    .superset-legacy-chart-heatmap .legendCells .cell:last-child text {
      opacity: 1;
    }

    .dashboard .superset-legacy-chart-heatmap .axis text {
      font-size: ${theme.typography.sizes.xs}px;
      opacity: ${theme.opacity.heavy};
    }
  `}
`;