export default class Fieldset extends React.PureComponent<FieldsetProps> {
    static defaultProps = {
      compact: false,
      title: null,
    };
  
    constructor(props: FieldsetProps) {
      super(props);
      this.onChange = this.onChange.bind(this);
    }
  
    onChange(fieldKey: fieldKeyType, val: any) {
      return this.props.onChange({
        ...this.props.item,
        [fieldKey]: val,
      });
    }
  
    render() {
      const { title } = this.props;
      const propExtender = (field: { props: { fieldKey: fieldKeyType } }) => ({
        onChange: this.onChange,
        value: this.props.item[field.props.fieldKey],
        compact: this.props.compact,
      });
      return (
        <Form className="CRUD" layout="vertical">
          {title && <legend>{title}</legend>}
          {recurseReactClone(this.props.children, Field, propExtender)}
        </Form>
      );
    }
  }