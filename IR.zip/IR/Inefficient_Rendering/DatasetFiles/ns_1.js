const BlurredSection = ({ children }: BlurredSectionProps) => {
  return (
    <StyledBlurredSection>
      {children}
      <img className="blur" src="/img/community/blur.png" alt="Blur" />
    </StyledBlurredSection>
  );
};
