const CrossFilterTag = (props: {
    filter: CrossFilterIndicator;
    orientation: FilterBarOrientation;
    removeCrossFilter: (filterId: number) => void;
  }) => {
    const { filter, orientation, removeCrossFilter } = props;
    const theme = useTheme();
    const [columnRef, columnIsTruncated] =
      useCSSTextTruncation<HTMLSpanElement>();
    const [valueRef, valueIsTruncated] = useCSSTextTruncation<HTMLSpanElement>();
  
    const columnLabel = getColumnLabel(filter.column ?? '');
    return (
      <StyledTag
        css={css`
          ${orientation === FilterBarOrientation.VERTICAL
            ? `
              margin-top: ${theme.gridUnit * 2}px;
            `
            : `
              margin-left: ${theme.gridUnit * 2}px;
            `}
        `}
        closable
        onClose={() => removeCrossFilter(filter.emitterId)}
      >
        <Tooltip title={columnIsTruncated ? columnLabel : null}>
          <StyledCrossFilterColumn ref={columnRef}>
            {columnLabel}
          </StyledCrossFilterColumn>
        </Tooltip>
        <Tooltip title={valueIsTruncated ? filter.value : null}>
          <StyledCrossFilterValue ref={valueRef}>
            {filter.value}
          </StyledCrossFilterValue>
        </Tooltip>
      </StyledTag>
    );
  };