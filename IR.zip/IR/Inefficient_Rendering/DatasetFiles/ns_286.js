export default function renderFilterScopeTreeNodes({ nodes, selectedChartId }) {
    if (!nodes) {
      return [];
    }
  
    return nodes.map(node => traverse({ currentNode: node, selectedChartId }));
  }