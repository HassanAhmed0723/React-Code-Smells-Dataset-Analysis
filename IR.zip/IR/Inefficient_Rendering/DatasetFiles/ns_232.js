function SearchFilter(
    { Header, name, initialValue, onSubmit }: SearchHeaderProps,
    ref: React.RefObject<FilterHandler>,
  ) {
    const [value, setValue] = useState(initialValue || '');
    const handleSubmit = () => {
      if (value) {
        onSubmit(value.trim());
      }
    };
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setValue(e.currentTarget.value);
      if (e.currentTarget.value === '') {
        onSubmit('');
      }
    };
  
    useImperativeHandle(ref, () => ({
      clearFilter: () => {
        setValue('');
        onSubmit('');
      },
    }));
  
    return (
      <Container>
        <FormLabel>{Header}</FormLabel>
        <StyledInput
          allowClear
          data-test="filters-search"
          placeholder={t('Type a value')}
          name={name}
          value={value}
          onChange={handleChange}
          onPressEnter={handleSubmit}
          onBlur={handleSubmit}
          prefix={<SearchIcon iconSize="l" />}
        />
      </Container>
    );
  }