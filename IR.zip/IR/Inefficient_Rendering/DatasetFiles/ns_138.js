export const BadgeTextGallery = () => (
    <>
      {COLORS.options.map(color => (
        <Badge
          text="Hello"
          color={color}
          key={color}
          style={{ marginRight: '15px' }}
        />
      ))}
    </>
  );
  