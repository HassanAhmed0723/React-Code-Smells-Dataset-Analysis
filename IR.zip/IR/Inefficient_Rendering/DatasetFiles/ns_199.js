export const InteractiveIconTooltip = (args: Props) => (
    <div css={{ margin: '40px 70px' }}>
      <IconTooltip {...args}>
        <Icons.Info />
      </IconTooltip>
    </div>
  );