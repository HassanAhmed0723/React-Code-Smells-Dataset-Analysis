export const SupersetRadio = () => {
    const [{ checked, ...rest }, updateArgs] = useArgs();
    return (
      <Radio
        checked={checked}
        onChange={() => updateArgs({ checked: !checked })}
        {...rest}
      >
        Example
      </Radio>
    );
  };