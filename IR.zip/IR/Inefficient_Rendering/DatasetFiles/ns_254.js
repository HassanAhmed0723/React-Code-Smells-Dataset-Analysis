export const customTagRender = (props: CustomTagProps) => {
    const { label, value } = props;
  
    const onPreventMouseDown = (event: React.MouseEvent<HTMLElement>) => {
      // if close icon is clicked, stop propagation to avoid opening the dropdown
      const target = event.target as HTMLElement;
      if (
        target.tagName === 'svg' ||
        target.tagName === 'path' ||
        (target.tagName === 'span' &&
          target.className.includes('ant-tag-close-icon'))
      ) {
        event.stopPropagation();
      }
    };
  
    if (value !== SELECT_ALL_VALUE) {
      return (
        <Tag onMouseDown={onPreventMouseDown} {...(props as object)}>
          {label}
        </Tag>
      );
    }
    return <NoElement />;
  };