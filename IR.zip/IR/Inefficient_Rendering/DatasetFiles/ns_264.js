export const InteractiveTableView = (args: TableViewProps) => (
    <TableView {...args} />
  );