export const Secondary: ComponentStory<typeof ButtonCell> = args => (
    <ButtonCell {...args} />
  );
  
  Secondary.args = {
    onClick: clickHandler,
    label: 'Secondary',
    buttonStyle: 'secondary',
    row: {
      key: 1,
      buttonCell: 'Click Me',
      textCell: 'Some text',
      euroCell: 45.5,
      dollarCell: 45.5,
    },
  };