export const basic = () => (
    <SuperChart
      chartType="calendar"
      width={400}
      height={400}
      datasource={dummyDatasource}
      queriesData={[{ data }]}
      formData={{
        cellSize: 10,
        cellPadding: 2,
        cellRadius: 0,
        domainGranularity: 'month',
        subdomainGranularity: 'day',
        linearColorScheme: 'schemeRdYlBu',
        steps: 10,
        yAxisFormat: '.3s',
        xAxisTimeFormat: 'smart_date',
        showLegend: true,
        showValues: false,
        showMetricName: true,
      }}
    />
  );