export const FrenchLocale: ComponentStory<typeof NumericCell> = args => (
    <NumericCell {...args} />
  );