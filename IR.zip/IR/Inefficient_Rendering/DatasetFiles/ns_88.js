const Sunburst = ({ className, ...otherProps }) => (
    <div className={className}>
      <ReactComponent {...otherProps} />
    </div>
  );
  
  export default styled(Sunburst)`
    ${({ theme }) => `
      .superset-legacy-chart-sunburst text {
        text-rendering: optimizeLegibility;
      }
      .superset-legacy-chart-sunburst path {
        stroke: ${theme.colors.grayscale.light2};
        stroke-width: 0.5px;
      }
      .superset-legacy-chart-sunburst .center-label {
        text-anchor: middle;
        fill: ${theme.colors.grayscale.dark1};
        pointer-events: none;
      }
      .superset-legacy-chart-sunburst .path-abs-percent {
        font-size: ${theme.typography.sizes.m}px;
        font-weight: ${theme.typography.weights.bold};
      }
      .superset-legacy-chart-sunburst .path-cond-percent {
        font-size: ${theme.typography.sizes.s}px;
      }
      .superset-legacy-chart-sunburst .path-metrics {
        color: ${theme.colors.grayscale.base};
      }
      .superset-legacy-chart-sunburst .path-ratio {
        color: ${theme.colors.grayscale.base};
      }
  
      .superset-legacy-chart-sunburst .breadcrumbs text {
        font-weight: ${theme.typography.weights.bold};
        font-size: ${theme.typography.sizes.m}px;
        text-anchor: middle;
        fill: ${theme.colors.grayscale.dark1};
      }
    `}
  `;
  