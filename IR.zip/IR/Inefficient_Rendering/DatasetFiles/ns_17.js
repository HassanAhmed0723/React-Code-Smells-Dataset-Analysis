const NoResultsComponent = ({ className, height, id, width }: Props) => {
    // render the body if the width is auto/100% or greater than 250 pixels
    const shouldRenderBody =
      typeof width === 'string' || width > MIN_WIDTH_FOR_BODY;
  
    const BODY_STRING = t(
      'No results were returned for this query. If you expected results to be returned, ensure any filters are configured properly and the datasource contains data for the selected time range.',
    );
  
    return (
      <Container
        height={height}
        width={width}
        className={className}
        id={id}
        title={shouldRenderBody ? undefined : BODY_STRING}
      >
        <div style={MESSAGE_STYLES}>
          <div className="no-results-title">{t('No Results')}</div>
          {shouldRenderBody && (
            <div className="no-results-body">{BODY_STRING}</div>
          )}
        </div>
      </Container>
    );
  };