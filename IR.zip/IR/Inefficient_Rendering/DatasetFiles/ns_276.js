const IconButton = ({ icon, label, onClick }: IconButtonProps) => (
    <StyledDiv
      tabIndex={0}
      role="button"
      onClick={e => {
        e.preventDefault();
        onClick(e);
      }}
    >
      {icon}
      {label && <StyledSpan>{label}</StyledSpan>}
    </StyledDiv>
  );