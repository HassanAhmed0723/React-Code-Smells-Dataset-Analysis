const CountryMap = ({ className, ...otherProps }) => (
    <div className={className}>
      <ReactComponent {...otherProps} />
    </div>
  );
  
  export default styled(CountryMap)`
    ${({ theme }) => `
      .superset-legacy-chart-country-map svg {
        background-color: ${theme.colors.grayscale.light5};
      }
  
      .superset-legacy-chart-country-map {
        position: relative;
      }
  
      .superset-legacy-chart-country-map .background {
        fill: ${theme.colors.grayscale.light5};
        pointer-events: all;
      }
  
      .superset-legacy-chart-country-map .map-layer {
        fill: ${theme.colors.grayscale.light5};
        stroke: ${theme.colors.grayscale.light1};
      }
  
      .superset-legacy-chart-country-map .effect-layer {
        pointer-events: none;
      }
  
      .superset-legacy-chart-country-map .text-layer {
        color: ${theme.colors.grayscale.dark1};
        text-anchor: middle;
        pointer-events: none;
      }
  
      .superset-legacy-chart-country-map text.result-text {
        font-weight: ${theme.typography.weights.light};
        font-size: ${theme.typography.sizes.xl}px;
      }
  
      .superset-legacy-chart-country-map text.big-text {
        font-weight: ${theme.typography.weights.bold};
        font-size: ${theme.typography.sizes.l}px;
      }
  
      .superset-legacy-chart-country-map path.region {
        cursor: pointer;
        stroke: ${theme.colors.grayscale.light2};
      }
    `}
  `;