export const InteractiveSwitch = ({ checked, ...rest }: SwitchProps) => {
    const [, updateArgs] = useArgs();
    return (
      <Switch
        {...rest}
        checked={checked}
        onChange={value => updateArgs({ checked: value })}
      />
    );
  };