export default styled(Sankey)`
  ${({ theme }) => `
    .superset-legacy-chart-sankey-loop .node rect {
      cursor: move;
      fill-opacity: ${theme.opacity.heavy};
      shape-rendering: crispEdges;
    }

    .superset-legacy-chart-sankey-loop .node text {
      pointer-events: none;
      text-shadow: 0 1px 0 ${theme.colors.grayscale.light5};
    }

    .superset-legacy-chart-sankey-loop .link {
      fill: none;
      stroke: ${theme.colors.grayscale.dark2};
      stroke-opacity: ${theme.opacity.light};
    }

    .superset-legacy-chart-sankey-loop .link:hover {
      stroke-opacity: ${theme.opacity.mediumHeavy};
    }

    .superset-legacy-chart-sankey-loop .link path {
      opacity: ${theme.opacity.mediumLight};
      stroke-opacity: 0;
    }

    .superset-legacy-chart-sankey-loop .link:hover path {
      opacity: ${theme.opacity.heavy};
    }

    .superset-legacy-chart-sankey-loop .link text {
      fill: ${theme.colors.grayscale.base};
      font-size: ${theme.gridUnit * 3}px;
    }

    .superset-legacy-chart-sankey-loop .link:hover text {
      opacity: 1;
    }
 `}
`;