export const Component = (props: DropDownSelectableProps) => (
    <DropdownSelectableIcon
      {...props}
      icon={<Icons.Gear name="gear" iconColor="#000000" />}
    />
  );