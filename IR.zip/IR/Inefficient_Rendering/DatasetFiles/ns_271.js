export const InteractiveWarningIcon = (args: WarningIconWithTooltipProps) => (
    <div css={{ margin: 40 }}>
      <WarningIconWithTooltip {...args} />
    </div>
  );