export default class FilterScopeModal extends React.PureComponent<
  FilterScopeModalProps,
  {}
> {
  modal: ModalTriggerRef;

  constructor(props: FilterScopeModalProps) {
    super(props);

    this.modal = React.createRef() as ModalTriggerRef;
    this.handleCloseModal = this.handleCloseModal.bind(this);
  }

  handleCloseModal(): void {
    this?.modal?.current?.close?.();
  }

  render() {
    const filterScopeProps = {
      onCloseModal: this.handleCloseModal,
    };

    return (
      <ModalTrigger
        ref={this.modal}
        triggerNode={this.props.triggerNode}
        modalBody={
          <FilterScopeModalBody>
            <FilterScope {...filterScopeProps} />
          </FilterScopeModalBody>
        }
        width="80%"
      />
    );
  }
}