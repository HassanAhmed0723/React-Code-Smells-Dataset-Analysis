export default class SpatialControl extends React.Component {
  constructor(props) {
    super(props);
    const v = props.value || {};
    let defaultCol;
    if (props.choices.length > 0) {
      defaultCol = props.choices[0][0];
    }
    this.state = {
      type: v.type || spatialTypes.latlong,
      delimiter: v.delimiter || ',',
      latCol: v.latCol || defaultCol,
      lonCol: v.lonCol || defaultCol,
      lonlatCol: v.lonlatCol || defaultCol,
      reverseCheckbox: v.reverseCheckbox || false,
      geohashCol: v.geohashCol || defaultCol,
      value: null,
      errors: [],
    };
    this.toggleCheckbox = this.toggleCheckbox.bind(this);
    this.onChange = this.onChange.bind(this);
    this.renderReverseCheckbox = this.renderReverseCheckbox.bind(this);
  }

  componentDidMount() {
    this.onChange();
  }

  onChange() {
    const { type } = this.state;
    const value = { type };
    const errors = [];
    const errMsg = t('Invalid lat/long configuration.');
    if (type === spatialTypes.latlong) {
      value.latCol = this.state.latCol;
      value.lonCol = this.state.lonCol;
      if (!value.lonCol || !value.latCol) {
        errors.push(errMsg);
      }
    } else if (type === spatialTypes.delimited) {
      value.lonlatCol = this.state.lonlatCol;
      value.delimiter = this.state.delimiter;
      value.reverseCheckbox = this.state.reverseCheckbox;
      if (!value.lonlatCol || !value.delimiter) {
        errors.push(errMsg);
      }
    } else if (type === spatialTypes.geohash) {
      value.geohashCol = this.state.geohashCol;
      value.reverseCheckbox = this.state.reverseCheckbox;
      if (!value.geohashCol) {
        errors.push(errMsg);
      }
    }
    this.setState({ value, errors });
    this.props.onChange(value, errors);
  }

  setType(type) {
    this.setState({ type }, this.onChange);
  }

  toggleCheckbox() {
    this.setState(
      prevState => ({ reverseCheckbox: !prevState.reverseCheckbox }),
      this.onChange,
    );
  }

  renderLabelContent() {
    if (this.state.errors.length > 0) {
      return 'N/A';
    }
    if (this.state.type === spatialTypes.latlong) {
      return `${this.state.lonCol} | ${this.state.latCol}`;
    }
    if (this.state.type === spatialTypes.delimited) {
      return `${this.state.lonlatCol}`;
    }
    if (this.state.type === spatialTypes.geohash) {
      return `${this.state.geohashCol}`;
    }
    return null;
  }

  renderSelect(name, type) {
    return (
      <SelectControl
        ariaLabel={name}
        name={name}
        choices={this.props.choices}
        value={this.state[name]}
        clearable={false}
        onFocus={() => {
          this.setType(type);
        }}
        onChange={value => {
          this.setState({ [name]: value }, this.onChange);
        }}
      />
    );
  }

  renderReverseCheckbox() {
    return (
      <span>
        {t('Reverse lat/long ')}
        <Checkbox
          checked={this.state.reverseCheckbox}
          onChange={this.toggleCheckbox}
        />
      </span>
    );
  }

  renderPopoverContent() {
    return (
      <div style={{ width: '300px' }}>
        <PopoverSection
          title={t('Longitude & Latitude columns')}
          isSelected={this.state.type === spatialTypes.latlong}
          onSelect={this.setType.bind(this, spatialTypes.latlong)}
        >
          <Row gutter={16}>
            <Col xs={24} md={12}>
              {t('Longitude')}
              {this.renderSelect('lonCol', spatialTypes.latlong)}
            </Col>
            <Col xs={24} md={12}>
              {t('Latitude')}
              {this.renderSelect('latCol', spatialTypes.latlong)}
            </Col>
          </Row>
        </PopoverSection>
        <PopoverSection
          title={t('Delimited long & lat single column')}
          info={t(
            'Multiple formats accepted, look the geopy.points ' +
              'Python library for more details',
          )}
          isSelected={this.state.type === spatialTypes.delimited}
          onSelect={this.setType.bind(this, spatialTypes.delimited)}
        >
          <Row gutter={16}>
            <Col xs={24} md={12}>
              {t('Column')}
              {this.renderSelect('lonlatCol', spatialTypes.delimited)}
            </Col>
            <Col xs={24} md={12}>
              {this.renderReverseCheckbox()}
            </Col>
          </Row>
        </PopoverSection>
        <PopoverSection
          title={t('Geohash')}
          isSelected={this.state.type === spatialTypes.geohash}
          onSelect={this.setType.bind(this, spatialTypes.geohash)}
        >
          <Row gutter={16}>
            <Col xs={24} md={12}>
              {t('Column')}
              {this.renderSelect('geohashCol', spatialTypes.geohash)}
            </Col>
            <Col xs={24} md={12}>
              {this.renderReverseCheckbox()}
            </Col>
          </Row>
        </PopoverSection>
      </div>
    );
  }

  render() {
    return (
      <div>
        <ControlHeader {...this.props} />
        <Popover
          content={this.renderPopoverContent()}
          placement="topLeft" // so that popover doesn't move when label changes
          trigger="click"
        >
          <Label className="pointer">{this.renderLabelContent()}</Label>
        </Popover>
      </div>
    );
  }
}


