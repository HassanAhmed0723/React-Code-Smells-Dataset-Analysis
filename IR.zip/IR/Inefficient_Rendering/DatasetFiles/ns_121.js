class PivotTable extends React.PureComponent {
    render() {
      return <TableRenderer {...this.props} />;
    }
  }