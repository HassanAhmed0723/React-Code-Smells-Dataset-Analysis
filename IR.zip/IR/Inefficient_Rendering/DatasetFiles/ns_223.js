export const InteractiveInfoTooltip = (props: InfoTooltipProps) => {
    const styles = {
      padding: '100px 0 0 200px',
    };
  
    return (
      <div style={styles}>
        <InfoTooltip {...props} />
      </div>
    );
  };