export default function DraggableNewDivider() {
    return (
      <DraggableNewComponent
        id={NEW_MARKDOWN_ID}
        type={MARKDOWN_TYPE}
        label={t('Text')}
        className="fa fa-font"
      />
    );
  }