export default function FilterFieldItem({ label, isSelected }) {
    return (
      <span
        className={cx('filter-field-item filter-container', {
          'is-selected': isSelected,
        })}
      >
        <FormLabel htmlFor={label}>{label}</FormLabel>
      </span>
    );
  }