export const basic = ({ width, height }) => (
    <SuperChart
      chartType="pivot_table_v2"
      datasource={{
        columnFormats: {},
      }}
      width={width}
      height={height}
      queriesData={[basicData]}
      formData={basicFormData}
    />
  );
  basic.story = {
    parameters: {
      initialSize: {
        width: 680,
        height: 420,
      },
    },
  };