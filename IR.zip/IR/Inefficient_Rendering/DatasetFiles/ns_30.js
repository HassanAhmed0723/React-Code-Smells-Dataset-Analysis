export const basicWithTrendline = () => (
    <SuperChart
      chartType="big-number"
      width={400}
      height={400}
      queriesData={[{ data: testData }]}
      formData={formData}
    />
  );