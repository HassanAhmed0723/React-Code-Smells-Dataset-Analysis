export function getLayer(
    formData: QueryFormData,
    payload: JsonObject,
    onAddFilter: () => void,
    setTooltip: (tooltip: TooltipProps['tooltip']) => void,
  ) {
    const fd = formData;
    const colorScale = CategoricalColorNamespace.getScale(fd.color_scheme);
    const colorRange = colorScale
      .range()
      .map(color => hexToRGB(color)) as Color[];
    let data = payload.data.features;
  
    if (fd.js_data_mutator) {
      // Applying user defined data mutator if defined
      const jsFnMutator = sandboxedEval(fd.js_data_mutator);
      data = jsFnMutator(data);
    }
    const aggFunc = getAggFunc(fd.js_agg_function, p => p?.weight);
  
    return new HexagonLayer({
      id: `hex-layer-${fd.slice_id}` as const,
      data,
      radius: fd.grid_size,
      extruded: fd.extruded,
      colorRange,
      outline: false,
      // @ts-ignore
      getElevationValue: aggFunc,
      // @ts-ignore
      getColorValue: aggFunc,
      ...commonLayerProps(fd, setTooltip, setTooltipContent),
    });
  }