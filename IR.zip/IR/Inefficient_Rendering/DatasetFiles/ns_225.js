export const InteractiveLabel = (args: any) => {
    const { hasOnClick, label, ...rest } = args;
    return (
      <Label onClick={hasOnClick ? action('clicked') : undefined} {...rest}>
        {label}
      </Label>
    );
  };