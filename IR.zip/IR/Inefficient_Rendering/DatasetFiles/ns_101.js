export function getLayer(
    formData: QueryFormData,
    payload: JsonObject,
    onAddFilter: () => void,
    setTooltip: (tooltip: TooltipProps['tooltip']) => void,
    datasource: Datasource,
  ) {
    const fd = formData;
    const dataWithRadius = payload.data.features.map((d: JsonObject) => {
      let radius = unitToRadius(fd.point_unit, d.radius) || 10;
      if (fd.multiplier) {
        radius *= fd.multiplier;
      }
      if (d.color) {
        return { ...d, radius };
      }
      const c = fd.color_picker || { r: 0, g: 0, b: 0, a: 1 };
      const color = [c.r, c.g, c.b, c.a * 255];
  
      return { ...d, radius, color };
    });
  
    return new ScatterplotLayer({
      id: `scatter-layer-${fd.slice_id}` as const,
      data: dataWithRadius,
      fp64: true,
      getFillColor: d => d.color,
      getRadius: d => d.radius,
      radiusMinPixels: Number(fd.min_radius) || undefined,
      radiusMaxPixels: Number(fd.max_radius) || undefined,
      stroked: false,
      ...commonLayerProps(
        fd,
        setTooltip,
        setTooltipContent(fd, datasource?.verboseMap),
      ),
    });
  }