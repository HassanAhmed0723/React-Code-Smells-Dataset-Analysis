export const nullInTheMiddle = () => (
    <SuperChart
      chartType="big-number"
      width={400}
      height={400}
      queriesData={[{ data: withNulls(testData, 3) }]}
      formData={formData}
    />
  );