export default function CrossLinks({
    crossLinks,
    maxLinks = 20,
    linkPrefix = '/superset/dashboard/',
  }: CrossLinksProps) {
    const crossLinksRef = useRef<HTMLDivElement>(null);
    const plusRef = useRef<HTMLDivElement>(null);
    const [elementsTruncated, hasHiddenElements] = useTruncation(
      crossLinksRef,
      plusRef,
    );
    const hasMoreItems = useMemo(
      () =>
        crossLinks.length > maxLinks ? crossLinks.length - maxLinks : undefined,
      [crossLinks, maxLinks],
    );
    const links = useMemo(
      () => (
        <span className="truncated" ref={crossLinksRef} data-test="crosslinks">
          {crossLinks.map((link, index) => (
            <Link
              key={link.id}
              to={linkPrefix + link.id}
              target="_blank"
              rel="noreferer noopener"
            >
              {index === 0 ? link.title : `, ${link.title}`}
            </Link>
          ))}
        </span>
      ),
      [crossLinks],
    );
    const tooltipLinks = useMemo(
      () =>
        crossLinks.slice(0, maxLinks).map(l => ({
          title: l.title,
          to: linkPrefix + l.id,
        })),
      [crossLinks, maxLinks],
    );
  
    return (
      <StyledCrossLinks>
        <CrossLinksTooltip
          moreItems={hasMoreItems}
          crossLinks={tooltipLinks}
          show={!!elementsTruncated}
        >
          {links}
          {hasHiddenElements && (
            <span ref={plusRef} className="count" data-test="count-crosslinks">
              +{elementsTruncated}
            </span>
          )}
        </CrossLinksTooltip>
      </StyledCrossLinks>
    );
  }