export const InteractiveIcons = ({
    showNames,
    ...rest
  }: IconType & { showNames: boolean }) => (
    <IconSet>
      {Object.keys(Icons).map(k => {
        const IconComponent = Icons[k];
        return (
          <IconBlock key={k}>
            <IconComponent {...rest} />
            {showNames && k}
          </IconBlock>
        );
      })}
    </IconSet>
  );