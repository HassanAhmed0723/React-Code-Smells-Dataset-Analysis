export function Item({ active, children, onClick }: PaginationItemButton) {
    return (
      <li className={classNames({ active })}>
        <span
          role="button"
          tabIndex={active ? -1 : 0}
          onClick={e => {
            e.preventDefault();
            if (!active) onClick(e);
          }}
        >
          {children}
        </span>
      </li>
    );
  }