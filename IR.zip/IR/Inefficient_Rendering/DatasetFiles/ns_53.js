export const BigTable = ({ width, height }) => {
    const rows = number('Records', 2046, { range: true, min: 0, max: 50000 });
    const cols = number('Columns', 8, { range: true, min: 1, max: 20 });
    const pageLength = number('Page size', 50, { range: true, min: 0, max: 100 });
    const includeSearch = boolean('Include search', true);
    const alignPn = boolean('Align PosNeg', false);
    const showCellBars = boolean('Show Cell Bars', true);
    const allowRearrangeColumns = boolean(
      'Allow end user to drag-and-drop column headers to rearrange them.',
      false,
    );
    const chartProps = loadData(birthNames, {
      pageLength,
      rows,
      cols,
      alignPn,
      showCellBars,
      includeSearch,
      allowRearrangeColumns,
    });
    return (
      <SuperChart
        chartType="table"
        {...chartProps}
        width={width}
        height={height}
      />
    );
  };
  BigTable.story = {
    parameters: {
      initialSize: {
        width: 620,
        height: 440,
      },
    },
  };