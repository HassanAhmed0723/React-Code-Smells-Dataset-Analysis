export function ColumnOption({
    column,
    labelRef,
    showType = false,
  }: ColumnOptionProps) {
    const { expression, column_name, type_generic } = column;
    const hasExpression = expression && expression !== column_name;
    const type = hasExpression ? 'expression' : type_generic;
    const [tooltipText, setTooltipText] = useState<ReactNode>(column.column_name);
    const [columnTypeTooltipText, setcolumnTypeTooltipText] = useState<ReactNode>(
      column.type,
    );
  
    useLayoutEffect(() => {
      setTooltipText(getColumnTooltipNode(column, labelRef));
      setcolumnTypeTooltipText(getColumnTypeTooltipNode(column));
    }, [labelRef, column]);
  
    return (
      <StyleOverrides>
        {showType && type !== undefined && (
          <Tooltip
            id="metric-type-tooltip"
            title={columnTypeTooltipText}
            placement="bottomRight"
            align={{ offset: [8, -2] }}
          >
            <span>
              <ColumnTypeLabel type={type} />
            </span>
          </Tooltip>
        )}
        <Tooltip id="metric-name-tooltip" title={tooltipText}>
          <span
            className="option-label column-option-label"
            css={(theme: SupersetTheme) => css`
              margin-right: ${theme.gridUnit}px;
            `}
            ref={labelRef}
          >
            {getColumnLabelText(column)}
          </span>
        </Tooltip>
        {hasExpression && <SQLPopover sqlExpression={expression} />}
        {column.is_certified && (
          <CertifiedIconWithTooltip
            metricName={column.metric_name}
            certifiedBy={column.certified_by}
            details={column.certification_details}
          />
        )}
      </StyleOverrides>
    );
  }