export interface GlobalFilterProps<D extends object> {
    preGlobalFilteredRows: Row<D>[];
    // filter value cannot be `undefined` otherwise React will report component
    // control type undefined error
    filterValue: string;
    setGlobalFilter: (filterValue: FilterValue) => void;
    searchInput?: ComponentType<SearchInputProps>;
  }