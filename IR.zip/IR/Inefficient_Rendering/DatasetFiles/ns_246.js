function Pagination({ children }: PaginationProps) {
    return <PaginationList role="navigation">{children}</PaginationList>;
  }