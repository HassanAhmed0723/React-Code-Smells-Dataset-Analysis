export default class MarkdownModeDropdown extends React.PureComponent<MarkdownModeDropdownProps> {
    render() {
      const { id, value, onChange } = this.props;
  
      return (
        <PopoverDropdown
          id={id}
          options={dropdownOptions}
          value={value}
          onChange={onChange}
        />
      );
    }
  }
  