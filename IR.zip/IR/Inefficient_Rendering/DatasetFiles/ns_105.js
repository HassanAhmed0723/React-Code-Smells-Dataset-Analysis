export const showMarkers: CustomControlItem = {
    name: 'show_markers',
    config: {
      type: 'CheckboxControl',
      label: t('Show Markers'),
      renderTrigger: true,
      default: false,
      description: t('Show data points as circle markers on the lines'),
    },
  };