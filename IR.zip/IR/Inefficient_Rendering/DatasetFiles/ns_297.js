export default class BackgroundStyleDropdown extends React.PureComponent<BackgroundStyleDropdownProps> {
    render() {
      const { id, value, onChange } = this.props;
      return (
        <PopoverDropdown
          id={id}
          options={backgroundStyleOptions}
          value={value}
          onChange={onChange}
          renderButton={renderButton}
          renderOption={renderOption}
        />
      );
    }
  }