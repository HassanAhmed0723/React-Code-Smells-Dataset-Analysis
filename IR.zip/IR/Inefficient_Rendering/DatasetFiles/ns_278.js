function AddSliceDragPreview({ dragItem, slices, isDragging, currentOffset }) {
    if (!isDragging || !currentOffset || !dragItem || !slices) return null;
  
    const slice = slices[dragItem.index];
  
    // make sure it's a new component and a chart
    const shouldRender =
      slice &&
      dragItem.parentType === NEW_COMPONENT_SOURCE_TYPE &&
      dragItem.type === CHART_TYPE;
  
    return !shouldRender ? null : (
      <AddSliceCard
        style={{
          ...staticCardStyles,
          transform: `translate(${currentOffset.x}px, ${currentOffset.y}px)`,
        }}
        sliceName={slice.slice_name}
        lastModified={slice.changed_on_humanized}
        visType={slice.viz_type}
        datasourceUrl={slice.datasource_url}
        datasourceName={slice.datasource_name}
      />
    );
  }