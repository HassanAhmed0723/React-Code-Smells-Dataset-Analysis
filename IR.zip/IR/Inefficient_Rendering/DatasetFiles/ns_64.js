export const configureCORS = () => {
    const host = text('Superset App host for CORS request', 'localhost:8088');
    const selectEndpoint = select('Endpoint', ENDPOINTS, '');
    const customEndpoint = text('Custom Endpoint (override above)', '');
    const endpoint = customEndpoint || selectEndpoint;
    const method = endpoint
      ? select('Request method', REQUEST_METHODS, 'POST')
      : undefined;
    const postPayload =
      endpoint && method === 'POST'
        ? text('POST payload', JSON.stringify({ form_data: bigNumberFormData }))
        : undefined;
  
    return (
      <div style={{ margin: 16 }}>
        <VerifyCORS
          host={host}
          endpoint={endpoint}
          method={method as VerifyCORSProps['method']}
          postPayload={`${postPayload}`}
        >
          {({ payload }) => (
            <>
              <div className="alert alert-success">
                Success! Update knobs below to try again
              </div>
              <br />
              <Expandable expandableWhat="payload">
                <br />
                <pre style={{ fontSize: 11 }}>
                  {JSON.stringify(payload, null, 2)}
                </pre>
              </Expandable>
            </>
          )}
        </VerifyCORS>
      </div>
    );
  };