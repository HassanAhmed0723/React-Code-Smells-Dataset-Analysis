export function Next({ disabled, onClick }: PaginationButtonProps) {
    return (
      <li className={classNames({ disabled })}>
        <span
          role="button"
          tabIndex={disabled ? -1 : 0}
          onClick={e => {
            e.preventDefault();
            if (!disabled) onClick(e);
          }}
        >
          Â»
        </span>
      </li>
    );
  }