export const InteractiveAnchorLink = (args: any) => (
    <AnchorLink id="link" {...args} />
  );