const TagsList = ({
    tags,
    editable = false,
    onDelete,
    maxTags,
  }: TagsListProps) => {
    const [tempMaxTags, setTempMaxTags] = useState<number | undefined>(maxTags);
  
    const handleDelete = (index: number) => {
      onDelete?.(index);
    };
  
    const expand = () => setTempMaxTags(undefined);
  
    const collapse = () => setTempMaxTags(maxTags);
  
    const tagsIsLong: boolean | null = useMemo(
      () => (tempMaxTags ? tags.length > tempMaxTags : null),
      [tags.length, tempMaxTags],
    );
  
    const extraTags: number | null = useMemo(
      () =>
        typeof tempMaxTags === 'number' ? tags.length - tempMaxTags + 1 : null,
      [tagsIsLong, tags.length, tempMaxTags],
    );
  
    return (
      <TagsDiv className="tag-list">
        {tagsIsLong && typeof tempMaxTags === 'number' ? (
          <>
            {tags.slice(0, tempMaxTags - 1).map((tag: TagType, index) => (
              <Tag
                id={tag.id}
                key={tag.id}
                name={tag.name}
                index={index}
                onDelete={handleDelete}
                editable={editable}
              />
            ))}
            {tags.length > tempMaxTags ? (
              <Tag name={`+${extraTags}...`} onClick={expand} />
            ) : null}
          </>
        ) : (
          <>
            {tags.map((tag: TagType, index) => (
              <Tag
                id={tag.id}
                key={tag.id}
                name={tag.name}
                index={index}
                onDelete={handleDelete}
                editable={editable}
              />
            ))}
            {maxTags ? (
              tags.length > maxTags ? (
                <Tag name="..." onClick={collapse} />
              ) : null
            ) : null}
          </>
        )}
      </TagsDiv>
    );
  };