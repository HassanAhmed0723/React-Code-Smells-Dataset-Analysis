export default function Form(props: FormProps) {
    return <StyledForm {...props} />;
  }