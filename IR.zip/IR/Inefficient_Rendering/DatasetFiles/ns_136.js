InteractiveEsmComponent.story = {
    parameters: {
      knobs: {
        disable: true,
      },
    },
  };