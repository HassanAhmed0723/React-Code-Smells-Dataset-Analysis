export function safeHtmlSpan(possiblyHtmlString: string) {
    const isHtml = isProbablyHTML(possiblyHtmlString);
    if (isHtml) {
      return (
        <span
          className="safe-html-wrapper"
          dangerouslySetInnerHTML={{ __html: sanitizeHtml(possiblyHtmlString) }}
        />
      );
    }
    return possiblyHtmlString;
  }