const config: ControlPanelConfig = {
    controlPanelSections: [
      sections.legacyRegularTime,
      {
        label: t('Event definition'),
        controlSetRows: [
          ['entity'],
          [
            {
              name: 'all_columns_x',
              config: {
                type: 'SelectControl',
                label: t('Event Names'),
                description: t('Columns to display'),
                mapStateToProps: state => ({
                  choices: columnChoices(state?.datasource),
                }),
                // choices is from `mapStateToProps`
                default: (control: ControlState) =>
                  control.choices?.[0]?.[0] || null,
                validators: [validateNonEmpty],
              },
            },
          ],
          ['row_limit'],
          [
            {
              name: 'order_by_entity',
              config: {
                type: 'CheckboxControl',
                label: t('Order by entity id'),
                description: t(
                  'Important! Select this if the table is not already sorted by entity id, ' +
                    'else there is no guarantee that all events for each entity are returned.',
                ),
                default: true,
              },
            },
          ],
          [
            {
              name: 'min_leaf_node_event_count',
              config: {
                type: 'SelectControl',
                freeForm: false,
                label: t('Minimum leaf node event count'),
                default: 1,
                choices: formatSelectOptionsForRange(1, 10),
                description: t(
                  'Leaf nodes that represent fewer than this number of events will be initially ' +
                    'hidden in the visualization',
                ),
              },
            },
          ],
        ],
      },
      {
        label: t('Query'),
        expanded: true,
        controlSetRows: [['adhoc_filters']],
      },
      {
        label: t('Additional metadata'),
        controlSetRows: [
          [
            {
              name: 'all_columns',
              // eslint-disable-next-line @typescript-eslint/consistent-type-assertions
              config: {
                type: 'SelectControl',
                multi: true,
                label: t('Metadata'),
                default: [],
                description: t('Select any columns for metadata inspection'),
                optionRenderer: c => <ColumnOption showType column={c} />,
                valueRenderer: c => <ColumnOption column={c} />,
                valueKey: 'column_name',
                allowAll: true,
                mapStateToProps: state => ({
                  options: state.datasource?.columns || [],
                }),
                commaChoosesOption: false,
                freeForm: true,
              } as SelectControlConfig<ColumnMeta>,
            },
          ],
        ],
      },
    ],
    controlOverrides: {
      entity: {
        label: t('Entity ID'),
        description: t('e.g., a "user id" column'),
      },
      row_limit: {
        label: t('Max Events'),
        description: t(
          'The maximum number of events to return, equivalent to the number of rows',
        ),
      },
    },
  };