export const InteractiveRefreshLabel = (args: RefreshLabelProps) => (
    <RefreshLabel {...args} />
  );