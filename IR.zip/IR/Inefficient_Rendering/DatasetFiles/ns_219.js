export const fixedHeight100Width = () => {
    const width = text('Vis width', '100%');
    const height = text('Vis height', '300');
  
    return (
      <SuperChart
        chartType={ChartKeys.DILIGENT}
        height={height}
        width={width}
        queriesData={[DEFAULT_QUERY_DATA]}
      />
    );
  };