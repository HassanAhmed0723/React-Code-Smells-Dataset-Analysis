export default function Checkbox({
    checked,
    onChange,
    style,
    className,
  }: CheckboxProps) {
    return (
      <Styles
        style={style}
        onClick={() => {
          onChange(!checked);
        }}
        role="checkbox"
        tabIndex={0}
        aria-checked={checked}
        aria-label="Checkbox"
        className={className || ''}
      >
        {checked ? <CheckboxChecked /> : <CheckboxUnchecked />}
      </Styles>
    );
  }