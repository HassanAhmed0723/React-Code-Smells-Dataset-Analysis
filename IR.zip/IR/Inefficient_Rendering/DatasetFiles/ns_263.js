export const Basic: ComponentStory<typeof TimeCell> = args => (
    <TimeCell {...args} />
  );