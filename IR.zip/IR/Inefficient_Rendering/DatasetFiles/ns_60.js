export const withWrapper = () => {
    const width = text('Vis width', '100%');
    const height = text('Vis height', '100%');
  
    return (
      <SuperChart
        chartType={ChartKeys.DILIGENT}
        width={width}
        height={height}
        queriesData={[DEFAULT_QUERY_DATA]}
        Wrapper={({ children }) => (
          <div>
            <div style={{ margin: 10, position: 'fixed' }}>With wrapper!</div>
            {children}
          </div>
        )}
      />
    );
  };