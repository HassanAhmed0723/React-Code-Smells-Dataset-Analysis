export type ControlFormItemSpec<T extends ControlType = ControlType> = {
    controlType: T;
    label: ReactNode;
    description: ReactNode;
    placeholder?: string;
    required?: boolean;
    validators?: ControlFormValueValidator<any>[];
    width?: number | string;
    /**
     * Time to delay change propagation.
     */
    debounceDelay?: number;
  } & (T extends 'Select'
    ? {
        options: SelectOption<any>[];
        value?: string;
        defaultValue?: string;
        creatable?: boolean;
        minWidth?: number | string;
        validators?: ControlFormValueValidator<string>[];
      }
    : T extends 'RadioButtonControl'
    ? {
        options: RadioButtonOption[];
        value?: string;
        defaultValue?: string;
      }
    : T extends 'Checkbox'
    ? {
        value?: boolean;
        defaultValue?: boolean;
      }
    : T extends 'InputNumber' | 'Slider'
    ? {
        min?: number;
        max?: number;
        step?: number;
        value?: number;
        defaultValue?: number;
        validators?: ControlFormValueValidator<number>[];
      }
    : T extends 'Input'
    ? {
        controlType: 'Input';
        value?: string;
        defaultValue?: string;
        validators?: ControlFormValueValidator<string>[];
      }
    : {});export default function ControlForm({
      onChange,
      value,
      children,
    }: ControlFormProps) {
      const theme = useTheme();
      const debouncedOnChange = useMemo(
        () =>
          ({
            0: onChange,
            [FAST_DEBOUNCE]: debounce(onChange, FAST_DEBOUNCE),
          } as Record<number, typeof onChange>),
        [onChange],
      );
    
      const updatedChildren = React.Children.map(children, row => {
        if ('children' in row.props) {
          const defaultWidth = Array.isArray(row.props.children)
            ? `${100 / row.props.children.length}%`
            : undefined;
          return React.cloneElement(row, {
            children: React.Children.map(row.props.children, item => {
              const {
                name,
                width,
                debounceDelay = FAST_DEBOUNCE,
                onChange: onItemValueChange,
              } = item.props;
              return React.cloneElement(item, {
                width: width || defaultWidth,
                value: value?.[name],
                // remove `debounceDelay` from rendered control item props
                // so React DevTools don't throw a `invalid prop` warning.
                debounceDelay: undefined,
                onChange(fieldValue: JsonValue) {
                  // call `onChange` on each FormItem
                  if (onItemValueChange) {
                    onItemValueChange(fieldValue);
                  }
                  // propagate to the form
                  if (!(debounceDelay in debouncedOnChange)) {
                    debouncedOnChange[debounceDelay] = debounce(
                      onChange,
                      debounceDelay,
                    );
                  }
                  debouncedOnChange[debounceDelay]({
                    ...value,
                    [name]: fieldValue,
                  });
                },
              });
            }),
          });
        }
        return row;
      });
      return (
        <div
          css={{
            label: {
              textTransform: 'uppercase',
              color: theme.colors.text.label,
              fontSize: theme.typography.sizes.s,
            },
          }}
        >
          {updatedChildren}
        </div>
      );
    }