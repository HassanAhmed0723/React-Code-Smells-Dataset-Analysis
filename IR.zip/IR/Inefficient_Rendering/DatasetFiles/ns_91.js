export type LegendProps = {
    format: string | null;
    forceCategorical?: boolean;
    position?: null | 'tl' | 'tr' | 'bl' | 'br';
    categories: Record<string, { enabled: boolean; color: number[] }>;
    toggleCategory?: (key: string) => void;
    showSingleCategory?: (key: string) => void;
  };
  
  const Legend = ({
    format: d3Format = null,
    forceCategorical = false,
    position = 'tr',
    categories: categoriesObject = {},
    toggleCategory = () => {},
    showSingleCategory = () => {},
  }: LegendProps) => {
    const format = (value: string) => {
      if (!d3Format || forceCategorical) {
        return value;
      }
  
      const numValue = parseFloat(value);
  
      return formatNumber(d3Format, numValue);
    };
  
    const formatCategoryLabel = (k: string) => {
      if (!d3Format) {
        return k;
      }
  
      if (k.includes(categoryDelimiter)) {
        const values = k.split(categoryDelimiter);
  
        return format(values[0]) + categoryDelimiter + format(values[1]);
      }
  
      return format(k);
    };
  
    if (Object.keys(categoriesObject).length === 0 || position === null) {
      return null;
    }
  
    const categories = Object.entries(categoriesObject).map(([k, v]) => {
      const style = { color: `rgba(${v.color.join(', ')})` };
      const icon = v.enabled ? '\u25FC' : '\u25FB';
  
      return (
        <li key={k}>
          <a
            href="#"
            onClick={() => toggleCategory(k)}
            onDoubleClick={() => showSingleCategory(k)}
          >
            <span style={style}>{icon}</span> {formatCategoryLabel(k)}
          </a>
        </li>
      );
    });
  
    const vertical = position?.charAt(0) === 't' ? 'top' : 'bottom';
    const horizontal = position?.charAt(1) === 'r' ? 'right' : 'left';
    const style = {
      position: 'absolute' as const,
      [vertical]: '0px',
      [horizontal]: '10px',
    };
  
    return (
      <StyledLegend className="dupa" style={style}>
        <ul>{categories}</ul>
      </StyledLegend>
    );
  };