export const InteractivePopover = (args: PopoverProps) => (
    <Popover {...args}>
      <Button
        style={{
          display: 'block',
          margin: '80px auto',
        }}
      >
        I am a button
      </Button>
    </Popover>
  );