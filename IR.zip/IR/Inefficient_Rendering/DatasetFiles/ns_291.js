export default function DraggableNewDivider() {
    return (
      <DraggableNewComponent
        id={NEW_DIVIDER_ID}
        type={DIVIDER_TYPE}
        label={t('Divider')}
        className="divider-placeholder"
      />
    );
  }