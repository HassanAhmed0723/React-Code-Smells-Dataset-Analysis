export default function Select<VT extends string | number>({
    creatable,
    onSearch,
    dropdownMatchSelectWidth = false,
    minWidth = '100%',
    showSearch: showSearch_ = true,
    onChange,
    options,
    children,
    value,
    ...props
  }: SelectProps<VT>) {
    const [searchValue, setSearchValue] = useState<string>();
    // force show search if creatable
    const showSearch = showSearch_ || creatable;
    const handleSearch = showSearch
      ? (input: string) => {
          if (creatable) {
            setSearchValue(input);
          }
          if (onSearch) {
            onSearch(input);
          }
        }
      : undefined;
  
    const optionsHasSearchValue = options?.some(([val]) => val === searchValue);
    const optionsHasValue = options?.some(([val]) => val === value);
  
    const handleChange: SelectProps<VT>['onChange'] = showSearch
      ? (val, opt) => {
          // reset input value once selected
          setSearchValue('');
          if (onChange) {
            onChange(val, opt);
          }
        }
      : onChange;
  
    return (
      <AntdSelect<VT>
        dropdownMatchSelectWidth={dropdownMatchSelectWidth}
        showSearch={showSearch}
        onSearch={handleSearch}
        onChange={handleChange}
        value={value}
        {...props}
        css={{
          minWidth,
        }}
      >
        {options?.map(([val, label]) => (
          <Option value={val}>{label}</Option>
        ))}
        {children}
        {value && !optionsHasValue && (
          <Option key={value} value={value}>
            {value}
          </Option>
        )}
        {searchValue && !optionsHasSearchValue && (
          <Option key={searchValue} value={searchValue}>
            {/* Unfortunately AntD select does not support displaying different
            label for option vs select value, so we can't use
            `t('Create "%s"', searchValue)` here */}
            {searchValue}
          </Option>
        )}
      </AntdSelect>
    );
  }