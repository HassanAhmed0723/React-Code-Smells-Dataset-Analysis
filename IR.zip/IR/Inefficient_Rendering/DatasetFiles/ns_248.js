export interface PopoverProps extends AntdPopoverProps {
    forceRender?: boolean;
  }