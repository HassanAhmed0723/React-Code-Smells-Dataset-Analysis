export const Basic: ComponentStory<typeof ActionCell> = args => (
    <ActionCell {...args} />
  );