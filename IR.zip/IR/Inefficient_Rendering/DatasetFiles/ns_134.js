export const InteractiveSliceTag = (args: any) => <AlteredSliceTag {...args} />;

InteractiveSliceTag.args = {
  origFormData: defaultProps.origFormData,
  currentFormData: defaultProps.currentFormData,
};