export function ProviderWrapper(props: any) {
    const { children, theme } = props;
  
    return (
      <ThemeProvider theme={theme}>
        <Router>
          <QueryParamProvider
            ReactRouterRoute={Route}
            stringifyOptions={{ encode: false }}
          >
            {children}
          </QueryParamProvider>
        </Router>
      </ThemeProvider>
    );
  }