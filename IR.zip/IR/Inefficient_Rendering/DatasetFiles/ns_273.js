class ColorSchemeControlWrapper extends React.PureComponent {
    constructor(props) {
      super(props);
      this.state = { hovered: false };
      this.categoricalSchemeRegistry = getCategoricalSchemeRegistry();
      this.choices = this.categoricalSchemeRegistry.keys().map(s => [s, s]);
      this.schemes = this.categoricalSchemeRegistry.getMap();
    }
  
    setHover(hovered) {
      this.setState({ hovered });
    }
  
    render() {
      const { colorScheme, labelMargin = 0, hasCustomLabelColors } = this.props;
      return (
        <ColorSchemeControl
          description={t(
            "Any color palette selected here will override the colors applied to this dashboard's individual charts",
          )}
          labelMargin={labelMargin}
          name="color_scheme"
          onChange={this.props.onChange}
          value={colorScheme}
          choices={this.choices}
          clearable
          schemes={this.schemes}
          hovered={this.state.hovered}
          hasCustomLabelColors={hasCustomLabelColors}
        />
      );
    }
  }