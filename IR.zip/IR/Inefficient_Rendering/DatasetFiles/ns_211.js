export const SQLPopover = (props: PopoverProps & { sqlExpression: string }) => {
    const theme = useTheme();
    return (
      <Popover
        content={
          <AceEditor
            mode="sql"
            value={props.sqlExpression}
            editorProps={{ $blockScrolling: true }}
            setOptions={{
              highlightActiveLine: false,
              highlightGutterLine: false,
            }}
            minLines={2}
            maxLines={6}
            readOnly
            wrapEnabled
            style={{
              border: `1px solid ${theme.colors.grayscale.light2}`,
              background: theme.colors.secondary.light5,
              maxWidth: theme.gridUnit * 100,
            }}
          />
        }
        placement="bottomLeft"
        arrowPointAtCenter
        title={t('SQL expression')}
        {...props}
      >
        <StyledCalculatorIcon />
      </Popover>
    );
  };