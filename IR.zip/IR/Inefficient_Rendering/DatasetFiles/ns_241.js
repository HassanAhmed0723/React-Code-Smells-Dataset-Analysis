export const InteractiveModalTrigger = (args: IModalTriggerProps) => (
    <ModalTrigger {...args} triggerNode={<span>Click me</span>} />
  );