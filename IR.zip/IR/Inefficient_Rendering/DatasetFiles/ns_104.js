export const yAxis2Format: CustomControlItem = {
    name: 'y_axis_2_format',
    config: {
      type: 'SelectControl',
      freeForm: true,
      label: t('Right Axis Format'),
      default: 'SMART_NUMBER',
      choices: D3_FORMAT_OPTIONS,
      description: D3_FORMAT_DOCS,
    },
  };