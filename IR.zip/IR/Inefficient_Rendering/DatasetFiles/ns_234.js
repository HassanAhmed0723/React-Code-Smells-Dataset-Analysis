export default function ImageLoader({
    src,
    fallback,
    isLoading,
    position,
    ...rest
  }: ImageLoaderProps) {
    const [imgSrc, setImgSrc] = useState<string>(fallback);
  
    useEffect(() => {
      if (src) {
        fetch(src)
          .then(response => response.blob())
          .then(blob => {
            if (/image/.test(blob.type)) {
              const imgURL = URL.createObjectURL(blob);
              setImgSrc(imgURL);
            }
          })
          .catch(errMsg => {
            logging.error(errMsg);
            setImgSrc(fallback);
          });
      }
  
      return () => {
        // theres a very brief period where isLoading is false and this component is about to unmount
        // where the stale imgSrc is briefly rendered. Setting imgSrc to fallback smoothes the transition.
        setImgSrc(fallback);
      };
    }, [src, fallback]);
  
    return (
      <ImageContainer
        src={isLoading ? fallback : imgSrc}
        {...rest}
        position={position}
      />
    );
  }