export const AsynchronousSelect = ({
    fetchOnlyOnSearch,
    withError,
    withInitialValue,
    responseTime,
    ...rest
  }: AsyncSelectProps & {
    withError: boolean;
    withInitialValue: boolean;
    responseTime: number;
  }) => {
    const [requests, setRequests] = useState<ReactNode[]>([]);
    const ref = useRef<AsyncSelectRef>(null);
  
    const getResults = (username?: string) => {
      let results: { label: string; value: string }[] = [];
  
      if (!username) {
        results = USERS.map(u => ({
          label: u,
          value: u,
        }));
      } else {
        const foundUsers = USERS.filter(u => u.toLowerCase().includes(username));
        if (foundUsers) {
          results = foundUsers.map(u => ({ label: u, value: u }));
        } else {
          results = [];
        }
      }
      return results;
    };

    const setRequestLog = (results: number, total: number, username?: string) => {
        const request = (
          <>
            Emulating network request with search <b>{username || 'empty'}</b> ...{' '}
            <b>
              {results}/{total}
            </b>{' '}
            results
          </>
        );
    
        setRequests(requests => [request, ...requests]);
      };
      const fetchUserListPage = useCallback(
        (
          search: string,
          page: number,
          pageSize: number,
        ): Promise<SelectOptionsTypePage> => {
          const username = search.trim().toLowerCase();
          return new Promise(resolve => {
            let results = getResults(username);
            const totalCount = results.length;
            const start = page * pageSize;
            const deleteCount =
              start + pageSize < totalCount ? pageSize : totalCount - start;
            results = results.splice(start, deleteCount);
            setRequestLog(start + results.length, totalCount, username);
            setTimeout(() => {
              resolve({ data: results, totalCount });
            }, responseTime * 1000);
          });
        },
        [responseTime],
      );
    
      const fetchUserListError = async (): Promise<SelectOptionsTypePage> =>
        new Promise((_, reject) => {
          reject(new Error('Error while fetching the names from the server'));
        });
    
      const initialValue = useMemo(
        () => ({ label: 'Valentina', value: 'Valentina' }),
        [],
      );
    
      return (
        <>
          <div
            style={{
              width: DEFAULT_WIDTH,
            }}
          >
            <AsyncSelect
              {...rest}
              ref={ref}
              fetchOnlyOnSearch={fetchOnlyOnSearch}
              options={withError ? fetchUserListError : fetchUserListPage}
              placeholder={fetchOnlyOnSearch ? 'Type anything' : 'AsyncSelect...'}
              value={withInitialValue ? initialValue : undefined}
            />
          </div>
          <div
            style={{
              position: 'absolute',
              top: 32,
              left: DEFAULT_WIDTH + 100,
              height: 400,
              width: 600,
              overflowY: 'auto',
              border: '1px solid #d9d9d9',
              padding: 20,
            }}
          >
            {requests.map((request, index) => (
              <p key={`request-${index}`}>{request}</p>
            ))}
          </div>
          <Button
            style={{
              position: 'absolute',
              top: 452,
              left: DEFAULT_WIDTH + 580,
            }}
            onClick={() => {
              ref.current?.clearCache();
              setRequests([]);
            }}
          >
            Clear cache
          </Button>
        </>
      );
    };