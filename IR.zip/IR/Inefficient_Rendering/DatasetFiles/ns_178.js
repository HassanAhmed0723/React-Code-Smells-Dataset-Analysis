export const SmallEmptyState = () => (
    <EmptyStateSmall
      image={<FilterImage />}
      title="Small empty state"
      description="This is an example of a small empty state"
    />
  );