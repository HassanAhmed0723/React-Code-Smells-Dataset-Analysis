export const LabelGallery = () => (
    <>
      <h4>Non-interactive</h4>
      {Object.values(options).map((opt: Type) => (
        <Label key={opt} type={opt}>
          {`style: "${opt}"`}
        </Label>
      ))}
      <br />
      <h4>Interactive</h4>
      {Object.values(options).map((opt: Type) => (
        <Label key={opt} type={opt} onClick={action('clicked')}>
          {`style: "${opt}"`}
        </Label>
      ))}
    </>
  );