export const Basic: ComponentStory<typeof ButtonCell> = args => (
    <ButtonCell {...args} />
  );
  
  Basic.args = {
    onClick: clickHandler,
    label: 'Primary',
    row: {
      key: 1,
      buttonCell: 'Click Me',
      textCell: 'Some text',
      euroCell: 45.5,
      dollarCell: 45.5,
    },
  };