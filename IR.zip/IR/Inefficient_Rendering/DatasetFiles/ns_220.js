export const withErrorBoundary = () => {
    const width = text('Vis width', '500');
    const height = text('Vis height', '300');
  
    return (
      <SuperChart
        chartType={ChartKeys.BUGGY}
        height={height}
        width={width}
        queriesData={[DEFAULT_QUERY_DATA]}
      />
    );
  };