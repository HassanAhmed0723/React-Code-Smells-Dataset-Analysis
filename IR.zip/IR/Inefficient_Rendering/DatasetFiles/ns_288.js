class Divider extends React.PureComponent {
    constructor(props) {
      super(props);
      this.handleDeleteComponent = this.handleDeleteComponent.bind(this);
    }
  
    handleDeleteComponent() {
      const { deleteComponent, id, parentId } = this.props;
      deleteComponent(id, parentId);
    }
  
    render() {
      const {
        component,
        depth,
        parentComponent,
        index,
        handleComponentDrop,
        editMode,
      } = this.props;
  
      return (
        <DragDroppable
          component={component}
          parentComponent={parentComponent}
          orientation="row"
          index={index}
          depth={depth}
          onDrop={handleComponentDrop}
          editMode={editMode}
        >
          {({ dropIndicatorProps, dragSourceRef }) => (
            <div ref={dragSourceRef}>
              {editMode && (
                <HoverMenu position="left">
                  <DeleteComponentButton onDelete={this.handleDeleteComponent} />
                </HoverMenu>
              )}
  
              <DividerLine className="dashboard-component dashboard-component-divider" />
  
              {dropIndicatorProps && <div {...dropIndicatorProps} />}
            </div>
          )}
        </DragDroppable>
      );
    }
  }