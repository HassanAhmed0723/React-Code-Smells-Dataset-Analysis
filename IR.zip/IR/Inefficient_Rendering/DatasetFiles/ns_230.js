export default function CrossLinksTooltip({
    children,
    crossLinks = [],
    moreItems = undefined,
    show = false,
  }: CrossLinksTooltipProps) {
    return (
      <Tooltip
        placement="top"
        data-test="crosslinks-tooltip"
        title={
          show && (
            <StyledLinkedTooltip>
              {crossLinks.map(link => (
                <Link
                  className="link"
                  key={link.to}
                  to={link.to}
                  target="_blank"
                  rel="noreferer noopener"
                >
                  {link.title}
                </Link>
              ))}
              {moreItems && (
                <span data-test="plus-more">{t('+ %s more', moreItems)}</span>
              )}
            </StyledLinkedTooltip>
          )
        }
      >
        {children}
      </Tooltip>
    );
  }
  