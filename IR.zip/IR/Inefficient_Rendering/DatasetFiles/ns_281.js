export default function FilterFieldTree({
    activeKey,
    nodes = [],
    checked = [],
    expanded = [],
    onClick,
    onCheck,
    onExpand,
  }) {
    return (
      <CheckboxTree
        showExpandAll
        showNodeIcon={false}
        expandOnClick
        nodes={renderFilterFieldTreeNodes({ nodes, activeKey })}
        checked={checked}
        expanded={expanded}
        onClick={onClick}
        onCheck={onCheck}
        onExpand={onExpand}
        icons={treeIcons}
      />
    );
  }