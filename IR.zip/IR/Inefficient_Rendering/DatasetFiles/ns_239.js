export const Basic = ({
    items,
    onClick,
  }: MetadataBarProps & {
    onClick: (type: string) => void;
  }) => {
    const { width, height, ref } = useResizeDetector();
    // eslint-disable-next-line no-param-reassign
    items[0].onClick = onClick;
    return (
      <div
        ref={ref}
        css={css`
          margin-top: 70px;
          margin-left: 80px;
          overflow: auto;
          min-width: ${168}px;
          max-width: ${740}px;
          resize: horizontal;
        `}
      >
        <MetadataBar items={items} />
        <span
          css={css`
            position: absolute;
            top: 150px;
            left: 115px;
          `}
        >{`${width}x${height}`}</span>
      </div>
    );
  };
  