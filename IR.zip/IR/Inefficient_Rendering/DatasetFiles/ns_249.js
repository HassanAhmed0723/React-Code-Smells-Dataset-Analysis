export const InteractivePopoverSection = (args: any) => (
    <PopoverSection {...args}>
      <div
        css={{
          display: 'flex',
          justifyContent: 'center',
          border: '1px solid',
          alignItems: 'center',
          width: 100,
          height: 100,
        }}
      >
        Content
      </div>
    </PopoverSection>
  );