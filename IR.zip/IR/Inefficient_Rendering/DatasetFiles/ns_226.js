export default function ActionsBar({ actions }: ActionsBarProps) {
    return (
      <StyledActions className="actions">
        {actions.map((action, index) => {
          const ActionIcon = Icons[action.icon];
          if (action.tooltip) {
            return (
              <Tooltip
                id={`${action.label}-tooltip`}
                title={action.tooltip}
                placement={action.placement}
                key={index}
              >
                <ActionWrapper
                  role="button"
                  tabIndex={0}
                  className="action-button"
                  data-test={action.label}
                  onClick={action.onClick}
                >
                  <ActionIcon />
                </ActionWrapper>
              </Tooltip>
            );
          }
          return (
            <ActionWrapper
              role="button"
              tabIndex={0}
              className="action-button"
              onClick={action.onClick}
              data-test={action.label}
              key={index}
            >
              <ActionIcon />
            </ActionWrapper>
          );
        })}
      </StyledActions>
    );
  }