export default function ToastPresenter({
    toasts,
    removeToast,
    position = 'bottom',
  }: ToastPresenterProps) {
    return (
      <>
        {toasts.length > 0 && (
          <StyledToastPresenter id="toast-presenter" position={position}>
            {toasts.map(toast => (
              <Toast key={toast.id} toast={toast} onCloseToast={removeToast} />
            ))}
          </StyledToastPresenter>
        )}
      </>
    );
  }