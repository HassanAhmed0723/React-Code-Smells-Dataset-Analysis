export const InteractiveSlider = (args: SliderSingleProps) => (
    <Slider {...args} style={{ width: 400, height: 400 }} />
  );