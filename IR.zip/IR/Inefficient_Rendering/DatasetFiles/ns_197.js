export const GenericLink = <S,>({
    to,
    component,
    replace,
    innerRef,
    children,
    ...rest
  }: React.PropsWithoutRef<LinkProps<S>> &
    React.RefAttributes<HTMLAnchorElement>) => {
    if (typeof to === 'string' && isUrlExternal(to)) {
      return (
        <a data-test="external-link" href={parseUrl(to)} {...rest}>
          {children}
        </a>
      );
    }
    return (
      <Link
        data-test="internal-link"
        to={to}
        component={component}
        replace={replace}
        innerRef={innerRef}
        {...rest}
      >
        {children}
      </Link>
    );
  };