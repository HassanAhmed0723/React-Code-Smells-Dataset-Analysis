export default function DragHandle({
    position = 'left',
    innerRef = null,
  }: DragHandleProps) {
    return (
      <DragHandleContainer ref={innerRef} position={position}>
        <Icons.Drag />
      </DragHandleContainer>
    );
  }