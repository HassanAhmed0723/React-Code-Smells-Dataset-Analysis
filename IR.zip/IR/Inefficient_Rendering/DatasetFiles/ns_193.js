export default function FormLabel({
    children,
    htmlFor,
    required = false,
    className,
  }: FormLabelProps) {
    const StyledLabel = required ? RequiredLabel : Label;
    return (
      <StyledLabel htmlFor={htmlFor} className={className}>
        {children}
      </StyledLabel>
    );
  }