function setTooltipContent(o: JsonObject) {
    return (
      <div className="deckgl-tooltip">
        <TooltipRow
          label={t('Centroid (Longitude and Latitude): ')}
          value={`(${o.coordinate[0]}, ${o.coordinate[1]})`}
        />
      </div>
    );
  }