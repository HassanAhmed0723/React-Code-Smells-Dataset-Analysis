export default function DraggableNewHeader() {
    return (
      <DraggableNewComponent
        id={NEW_HEADER_ID}
        type={HEADER_TYPE}
        label={t('Header')}
        className="fa fa-header"
      />
    );
  }