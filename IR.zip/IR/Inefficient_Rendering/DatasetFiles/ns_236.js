export const LoadingGallery = () => (
    <>
      {POSITIONS.map(position => (
        <div
          key={position}
          style={{
            marginBottom: 60,
            borderBottom: '1px solid #000',
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          <h4>{position}</h4>
          <Loading position={position} />
        </div>
      ))}
    </>
  );