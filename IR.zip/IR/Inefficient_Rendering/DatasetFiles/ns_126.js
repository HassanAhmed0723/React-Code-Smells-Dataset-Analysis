function DefaultSelectRenderer({
    current,
    options,
    onChange,
  }: SelectPageSizeRendererProps) {
    return (
      <span className="dt-select-page-size form-inline">
        {t('Show')}{' '}
        <select
          className="form-control input-sm"
          value={current}
          onBlur={() => {}}
          onChange={e => {
            onChange(Number((e.target as HTMLSelectElement).value));
          }}
        >
          {options.map(option => {
            const [size, text] = Array.isArray(option)
              ? option
              : [option, option];
            return (
              <option key={size} value={size}>
                {text}
              </option>
            );
          })}
        </select>{' '}
        {t('entries')}
      </span>
    );
  }