export const InteractiveTimezoneSelector = (args: TimezoneSelectorProps) => {
    const [{ timezone }, updateArgs] = useArgs();
    const onTimezoneChange = (value: string) => {
      updateArgs({ timezone: value });
    };
    return (
      <TimezoneSelector timezone={timezone} onTimezoneChange={onTimezoneChange} />
    );
  };