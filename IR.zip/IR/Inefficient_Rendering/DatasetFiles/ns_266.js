export const LineEditableTabs = Object.assign(StyledLineEditableTabs, {
    TabPane: StyledTabPane,
  });