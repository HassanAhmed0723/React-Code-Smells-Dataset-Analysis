export const container50pct = () => {
    const width = text('Vis width', '50%');
    const height = text('Vis height', '50%');
  
    return (
      <SuperChart
        chartType={ChartKeys.DILIGENT}
        width={width}
        height={height}
        queriesData={[DEFAULT_QUERY_DATA]}
        formData={{ hi: 1 }}
      />
    );
  };