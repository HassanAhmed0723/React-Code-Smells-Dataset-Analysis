function SafeMarkdown({
    source,
    htmlSanitization = true,
    htmlSchemaOverrides = {},
  }: SafeMarkdownProps) {
    const escapeHtml = isFeatureEnabled(FeatureFlag.ESCAPE_MARKDOWN_HTML);
  
    const rehypePlugins = useMemo(() => {
      const rehypePlugins: any = [];
      if (!escapeHtml) {
        rehypePlugins.push(rehypeRaw);
        if (htmlSanitization) {
          const schema = getOverrideHtmlSchema(
            defaultSchema,
            htmlSchemaOverrides,
          );
          rehypePlugins.push([rehypeSanitize, schema]);
        }
      }
      return rehypePlugins;
    }, [escapeHtml, htmlSanitization, htmlSchemaOverrides]);
  
    // React Markdown escapes HTML by default
    return (
      <ReactMarkdown
        rehypePlugins={rehypePlugins}
        remarkPlugins={[remarkGfm]}
        skipHtml={false}
      >
        {source}
      </ReactMarkdown>
    );
  }
  