const DeleteComponentButton: React.FC<DeleteComponentButtonProps> = ({
    onDelete,
  }) => <IconButton onClick={onDelete} icon={<Icons.Trash iconSize="xl" />} />;