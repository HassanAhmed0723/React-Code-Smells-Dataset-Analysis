function DatasetNotFoundErrorMessage({
    error,
    source = 'dashboard',
    subtitle,
  }: ErrorMessageComponentProps) {
    const { level, message } = error;
  
    return (
      <ErrorAlert
        title={t('Missing dataset')}
        subtitle={subtitle}
        level={level}
        source={source}
        copyText={message}
        body={null}
      />
    );
  }
  
  export default DatasetNotFoundErrorMessage;