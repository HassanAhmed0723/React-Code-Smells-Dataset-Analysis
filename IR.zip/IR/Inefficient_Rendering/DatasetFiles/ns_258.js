export const Basic: ComponentStory<typeof BooleanCell> = args => (
    <BooleanCell {...args} />
  );