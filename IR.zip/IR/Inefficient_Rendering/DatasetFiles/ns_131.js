export const SqlLabGlobalStyles = () => (
    <Global
      styles={theme => css`
        body {
          min-height: max(
            100vh,
            ${theme.gridUnit * 125}px
          ); // Set a min height so the gutter is always visible when resizing
          overflow: hidden;
        }
      `}
    />
  );