export default function CardCollection({
    bulkSelectEnabled,
    loading,
    prepareRow,
    renderCard,
    rows,
    showThumbnails,
  }: CardCollectionProps) {
    function handleClick(
      event: React.MouseEvent<HTMLDivElement, MouseEvent>,
      toggleRowSelected: Row['toggleRowSelected'],
    ) {
      if (bulkSelectEnabled) {
        event.preventDefault();
        event.stopPropagation();
        toggleRowSelected();
      }
    }
  
    if (!renderCard) return null;
    return (
      <CardContainer showThumbnails={showThumbnails}>
        {loading &&
          rows.length === 0 &&
          [...new Array(25)].map((e, i) => (
            <div key={i}>{renderCard({ loading })}</div>
          ))}
        {rows.length > 0 &&
          rows.map(row => {
            if (!renderCard) return null;
            prepareRow(row);
            return (
              <CardWrapper
                className={cx({
                  'card-selected': bulkSelectEnabled && row.isSelected,
                  'bulk-select': bulkSelectEnabled,
                })}
                key={row.id}
                onClick={e => handleClick(e, row.toggleRowSelected)}
                role="none"
              >
                {renderCard({ ...row.original, loading })}
              </CardWrapper>
            );
          })}
      </CardContainer>
    );
  }