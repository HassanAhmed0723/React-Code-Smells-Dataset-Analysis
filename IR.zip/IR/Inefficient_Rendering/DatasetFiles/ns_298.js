export default class HoverMenu extends React.PureComponent<HoverMenuProps> {
    static defaultProps = {
      position: 'left',
      innerRef: null,
      children: null,
    };
  
    render() {
      const { innerRef, position, children } = this.props;
      return (
        <HoverStyleOverrides className="hover-menu-container">
          <div
            ref={innerRef}
            className={cx(
              'hover-menu',
              position === 'left' && 'hover-menu--left',
              position === 'top' && 'hover-menu--top',
            )}
          >
            {children}
          </div>
        </HoverStyleOverrides>
      );
    }
  }