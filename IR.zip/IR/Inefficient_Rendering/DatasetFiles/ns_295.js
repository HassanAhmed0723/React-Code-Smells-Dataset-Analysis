export default function DraggableNewRow() {
    return (
      <DraggableNewComponent
        id={NEW_ROW_ID}
        type={ROW_TYPE}
        label={t('Row')}
        className="fa fa-long-arrow-right"
      />
    );
  }