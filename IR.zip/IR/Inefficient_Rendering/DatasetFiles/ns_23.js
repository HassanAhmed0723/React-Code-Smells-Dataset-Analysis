const ThemeDecorator = Story => (
    <ThemeProvider theme={supersetTheme}>{<Story />}</ThemeProvider>
  );