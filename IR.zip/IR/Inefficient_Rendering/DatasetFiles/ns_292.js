const DraggableNewDynamicComponent: FC<DraggableNewDynamicComponent> = ({
    componentKey,
    metadata,
  }) => (
    <DraggableNewComponent
      id={NEW_DYNAMIC_COMPONENT}
      type={DYNAMIC_TYPE}
      label={metadata.name}
      meta={{ metadata, componentKey }}
      className={`fa fa-${metadata.iconName}`}
    />
  );