const Community = () => {
    return (
      <Layout
        title="Community"
        description="Community website for Apache Supersetâ„¢, a data visualization and data exploration platform"
      >
        <main>
          <BlurredSection>
            <SectionHeader
              level="h1"
              title="Community"
              subtitle="Get involved in our welcoming, fast growing community!"
            />
          </BlurredSection>
          <StyledJoinCommunity>
            <List
              className="list"
              itemLayout="horizontal"
              dataSource={communityLinks}
              renderItem={({ url, title, description, image, ariaLabel }) => (
                <List.Item className="item">
                  <List.Item.Meta
                    avatar={
                      <a
                        className="title"
                        href={url}
                        target="_blank"
                        aria-label={ariaLabel}
                      >
                        <img className="icon" src={`/img/community/${image}`} />
                      </a>
                    }
                    title={
                      <a className="title" href={url} target="_blank">
                        {title}
                      </a>
                    }
                    description={<p className="description">{description}</p>}
                    role="group"
                    aria-label="Community link"
                  />
                </List.Item>
              )}
            />
          </StyledJoinCommunity>
          <BlurredSection>
            <SectionHeader
              level="h2"
              title="Superset Community Calendar"
              subtitle={
                <>
                  Join us for live demos, meetups, discussions, and more!
                  <br />
                  <StyledLink
                    href="https://calendar.google.com/calendar/u/0/r?cid=superset.committers@gmail.com"
                    target="_blank"
                  >
                    <img src="/img/calendar-icon.svg" alt="calendar-icon" />
                    Subscribe to the Superset Community Calendar
                  </StyledLink>
                </>
              }
            />
            <StyledCalendarIframe
              src="https://calendar.google.com/calendar/embed?src=superset.committers%40gmail.com&ctz=America%2FLos_Angeles"
              frameBorder="0"
              scrolling="no"
            />
          </BlurredSection>
          <BlurredSection>
            <SectionHeader level="h2" title="Newsletter Archive" />
            <StyledNewsletterIframe
              src="https://preset.io/embed/newsletter/"
              frameBorder="0"
              scrolling="no"
            />
          </BlurredSection>
        </main>
      </Layout>
    );
  };