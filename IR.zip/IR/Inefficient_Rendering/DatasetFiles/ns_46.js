export const manyBars = () => (
    <SuperChart
      chartType="dist-bar"
      width={400}
      height={400}
      datasource={dummyDatasource}
      queriesData={[{ data }]}
      formData={{
        colorScheme: 'd3Category10',
        showBarValue: false,
        showLegend: true,
        vizType: 'dist_bar',
        xTicksLayout: 'auto',
      }}
    />
  );