export const InteractiveIndeterminateCheckbox = (
    args: IndeterminateCheckboxProps,
  ) => <IndeterminateCheckbox {...args} />;