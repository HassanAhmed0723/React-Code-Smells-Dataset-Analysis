export const basic = function BasicCountryMapStory({ width, height }) {
    const theme = useTheme();
    const country = select('Country', Object.keys(countries!), 'france');
    const colorSchema = select<any>(
      'Color schema',
      SequentialD3,
      SequentialD3.find(x => x.id === 'schemeOranges'),
    );
    const [data, setData] = useState<JsonObject>();
  
    useEffect(() => {
      const controller = new AbortController();
      const { signal } = controller;
      fetch(countries[country], { signal })
        .then(resp => resp.json())
        .then(geojson => {
          setData(generateData(geojson));
        });
      return () => {
        controller.abort();
      };
    }, [country]);
  
    if (!data) {
      return (
        <div
          style={{
            color: theme.colors.grayscale.base,
            textAlign: 'center',
            padding: 20,
          }}
        >
          Loading...
        </div>
      );
    }
  
    return (
      <SuperChart
        chartType="country-map"
        width={width}
        height={height}
        queriesData={[{ data }]}
        formData={{
          linearColorScheme: colorSchema.id,
          numberFormat: '.3s',
          selectCountry: country,
        }}
      />
    );
  };