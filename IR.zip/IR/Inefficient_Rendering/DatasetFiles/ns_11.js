export const titleControls: ControlPanelSectionConfig = {
    label: t('Chart Title'),
    tabOverride: 'customize',
    expanded: true,
    controlSetRows: [
      [<ControlSubSectionHeader>{t('X Axis')}</ControlSubSectionHeader>],
      [
        {
          name: 'x_axis_title',
          config: {
            type: 'TextControl',
            label: t('X Axis Title'),
            renderTrigger: true,
            default: '',
            description: t('Changing this control takes effect instantly'),
          },
        },
      ],
      [
        {
          name: 'x_axis_title_margin',
          config: {
            type: 'SelectControl',
            freeForm: true,
            clearable: true,
            label: t('X AXIS TITLE BOTTOM MARGIN'),
            renderTrigger: true,
            default: TITLE_MARGIN_OPTIONS[0],
            choices: formatSelectOptions(TITLE_MARGIN_OPTIONS),
            description: t('Changing this control takes effect instantly'),
          },
        },
      ],
      [<ControlSubSectionHeader>{t('Y Axis')}</ControlSubSectionHeader>],
      [
        {
          name: 'y_axis_title',
          config: {
            type: 'TextControl',
            label: t('Y Axis Title'),
            renderTrigger: true,
            default: '',
            description: t('Changing this control takes effect instantly'),
          },
        },
      ],
      [
        {
          name: 'y_axis_title_margin',
          config: {
            type: 'SelectControl',
            freeForm: true,
            clearable: true,
            label: t('Y Axis Title Margin'),
            renderTrigger: true,
            default: TITLE_MARGIN_OPTIONS[0],
            choices: formatSelectOptions(TITLE_MARGIN_OPTIONS),
            description: t('Changing this control takes effect instantly'),
          },
        },
      ],
      [
        {
          name: 'y_axis_title_position',
          config: {
            type: 'SelectControl',
            freeForm: true,
            clearable: false,
            label: t('Y Axis Title Position'),
            renderTrigger: true,
            default: TITLE_POSITION_OPTIONS[0][0],
            choices: TITLE_POSITION_OPTIONS,
            description: t('Changing this control takes effect instantly'),
          },
        },
      ],
    ],
  };