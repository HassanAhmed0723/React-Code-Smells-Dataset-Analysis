export const InteractiveDatePicker = (args: DatePickerProps) => (
    <DatePicker {...args} />
  );