export default function EchartsGraph({
    echartOptions,
    height,
    refs,
    width,
  }: EchartsProps) {
    return (
      <Echart
        refs={refs}
        height={height}
        width={width}
        echartOptions={echartOptions}
      />
    );
  }