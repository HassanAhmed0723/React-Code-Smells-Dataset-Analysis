export const InteractiveTags = ({ tags, editable, maxTags }: TagsListProps) => (
    <TagsList tags={tags} editable={editable} maxTags={maxTags} />
  );