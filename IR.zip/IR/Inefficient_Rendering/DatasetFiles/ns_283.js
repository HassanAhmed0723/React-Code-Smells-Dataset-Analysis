export default function FilterScopeTree({
    nodes = [],
    checked = [],
    expanded = [],
    onCheck,
    onExpand,
    selectedChartId,
  }) {
    return (
      <CheckboxTree
        showExpandAll
        expandOnClick
        showNodeIcon={false}
        nodes={renderFilterScopeTreeNodes({ nodes, selectedChartId })}
        checked={checked}
        expanded={expanded}
        onCheck={onCheck}
        onExpand={onExpand}
        onClick={NOOP}
        icons={treeIcons}
      />
    );
  }