export const InteractiveTooltip = (args: TooltipProps) => (
    <Tooltip {...args}>
      <Button style={{ margin: '50px 100px' }}>Hover me</Button>
    </Tooltip>
  );