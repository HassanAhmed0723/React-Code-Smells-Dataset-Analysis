export const ModalFunctions = (props: ModalFuncProps) => (
    <div>
      <Button onClick={() => Modal.error(props)}>Error</Button>
      <Button onClick={() => Modal.warning(props)}>Warning</Button>
      <Button onClick={() => Modal.confirm(props)}>Confirm</Button>
    </div>
  );