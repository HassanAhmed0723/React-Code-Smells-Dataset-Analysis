export default function DraggableNewColumn() {
    return (
      <DraggableNewComponent
        id={NEW_COLUMN_ID}
        type={COLUMN_TYPE}
        label={t('Column')}
        className="fa fa-long-arrow-down"
      />
    );
  }