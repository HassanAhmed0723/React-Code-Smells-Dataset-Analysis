export const InteractiveProgressBar = (args: ProgressBarProps) => (
    <ProgressBar {...args} />
  );