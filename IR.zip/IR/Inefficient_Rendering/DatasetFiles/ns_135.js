export const AsyncAceEditor = (
    args: AsyncAceEditorOptions & { editorType: EditorType },
  ) => {
    const { editorType, ...props } = args;
    const Editor = parseEditorType(editorType);
    return <Editor {...props} />;
  };