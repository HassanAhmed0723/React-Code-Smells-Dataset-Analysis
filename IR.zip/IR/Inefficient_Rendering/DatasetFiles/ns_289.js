export default class DraggableNewComponent extends React.PureComponent {
    render() {
      const { label, id, type, className, meta } = this.props;
      return (
        <DragDroppable
          component={{ type, id, meta }}
          parentComponent={{
            id: NEW_COMPONENTS_SOURCE_ID,
            type: NEW_COMPONENT_SOURCE_TYPE,
          }}
          index={0}
          depth={0}
          editMode
        >
          {({ dragSourceRef }) => (
            <NewComponent ref={dragSourceRef} data-test="new-component">
              <NewComponentPlaceholder
                className={cx('new-component-placeholder', className)}
              />
              {label}
            </NewComponent>
          )}
        </DragDroppable>
      );
    }
  }