export const MediumEmptyStateWithButton = () => (
    <EmptyStateMedium
      image={<EmptyImage />}
      title="Medium empty state"
      description="This is an example of a medium empty state with a button"
      buttonAction={() => {}}
      buttonText="Click!"
    />
  );