export default (React.memo as <T>(fn: T) => T)(function GlobalFilter<
    D extends object,
  >({
    preGlobalFilteredRows,
    filterValue = '',
    searchInput,
    setGlobalFilter,
  }: GlobalFilterProps<D>) {
    const count = preGlobalFilteredRows.length;
    const [value, setValue] = useAsyncState(
      filterValue,
      (newValue: string) => {
        setGlobalFilter(newValue || undefined);
      },
      200,
    );
  
    const SearchInput = searchInput || DefaultSearchInput;
  
    return (
      <SearchInput
        count={count}
        value={value}
        onChange={e => {
          const target = e.target as HTMLInputElement;
          e.preventDefault();
          setValue(target.value);
        }}
      />
    );
  });