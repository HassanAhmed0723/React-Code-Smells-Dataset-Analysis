export const fixedWidth100height = () => {
    const width = text('Vis width', '500');
    const height = text('Vis height', '100%');
  
    return (
      <SuperChart
        chartType={ChartKeys.DILIGENT}
        height={height}
        width={width}
        queriesData={[DEFAULT_QUERY_DATA]}
      />
    );
  };