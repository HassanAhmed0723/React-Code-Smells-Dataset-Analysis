class IndexLabel extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        showSystemIndices: props.showSystemIndices,
      };
      this.toggleShowSystemIndicesState = this.toggleShowSystemIndicesState.bind(this);
    }
  
    toggleShowSystemIndicesState(e) {
      const isChecked = e.target.checked;
      this.setState({ showSystemIndices: isChecked });
      this.props.toggleShowSystemIndices(isChecked);
    }
  
    render() {
      return (
        <EuiFlexGroup>
          <EuiFlexItem grow={false}>
            <FormattedMessage
              id="xpack.monitoring.elasticsearch.shardAllocation.tableHead.indicesLabel"
              defaultMessage="Indices"
            />
          </EuiFlexItem>
          <EuiFlexItem>
            <EuiSwitch
              label={i18n.translate(
                'xpack.monitoring.elasticsearch.shardAllocation.tableHead.filterSystemIndices',
                {
                  defaultMessage: 'Filter for system indices',
                }
              )}
              onChange={this.toggleShowSystemIndicesState}
              checked={this.state.showSystemIndices}
              data-test-subj="shardShowSystemIndices"
            />
          </EuiFlexItem>
        </EuiFlexGroup>
      );
    }
  }
  