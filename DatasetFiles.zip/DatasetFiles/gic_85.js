class BaseScreenComponent extends React.Component {
    // ... common methods and logic ...
}

class SearchScreenComponent extends BaseScreenComponent {
    constructor() {
        super();
        this.state = {
            query: '',
            notes: [],
        };

        this.isMounted_ = false;
        this.styles_ = {};
        this.scheduleSearchTimer_ = null;

        this.clearButton_press = () => {
            // ... specific logic ...
        };

        this.searchTextInput_changeText = (text) => {
            // ... specific logic ...
        };
    }

    styles() {
        // ... styles specific to SearchScreenComponent ...
    }

    componentDidMount() {
        // ... specific logic ...
    }

    componentWillUnmount() {
        // ... specific logic ...
    }

    refreshSearch(query = null) {
        // ... specific logic ...
    }

    scheduleSearch() {
        // ... specific logic ...
    }

    render() {
        // ... specific rendering logic ...
    }
}
