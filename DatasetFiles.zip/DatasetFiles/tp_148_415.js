const SavedQueries = ({
    user,
    addDangerToast,
    addSuccessToast,
    mine,
    showThumbnails,
    featureFlag,
  }: SavedQueriesProps)