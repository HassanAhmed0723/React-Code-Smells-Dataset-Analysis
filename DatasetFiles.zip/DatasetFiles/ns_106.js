export const leftMargin: CustomControlItem = {
    name: 'left_margin',
    config: {
      type: 'SelectControl',
      freeForm: true,
      clearable: false,
      label: t('Left Margin'),
      choices: [
        ['auto', t('auto')],
        [50, '50'],
        [75, '75'],
        [100, '100'],
        [125, '125'],
        [150, '150'],
        [200, '200'],
      ],
      default: 'auto',
      renderTrigger: true,
      description: t(
        'Left margin, in pixels, allowing for more room for axis labels',
      ),
    },
  };