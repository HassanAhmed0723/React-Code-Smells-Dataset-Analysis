export class DeckGLContainer extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        viewport: props.viewport,
      };
    }
  
    render() {
      const { viewport } = this.state;
      return (
        <div>
          <DeckGL
            width={viewport.width}
            height={viewport.height}
            layers={this.props.layers}
            viewState={viewport}
            onViewStateChange={this.onViewStateChange}
          >
            <StaticMap
              mapStyle={this.props.mapStyle}
              mapboxApiAccessToken={this.props.mapboxApiAccessToken}
            />
          </DeckGL>
        </div>
      );
    }
  }
  