class DatasourceControl extends React.PureComponent {
    constructor(props) {
      super(props);
      this.state = {
        showEditDatasourceModal: false,
        showChangeDatasourceModal: false,
        showSaveDatasetModal: false,
      };
    }