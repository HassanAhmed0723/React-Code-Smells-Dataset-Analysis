class JobsList extends Component {
  constructor(props) {
    super(props);

    // Store the initial props directly in state (props in initial state smell)
    this.state = {
      ...props,
      itemIdToExpandedRowMap: {},
    };
  }

  static getDerivedStateFromProps(props, state) {
    const itemIdToExpandedRowMap = props.itemIdToExpandedRowMap;
    const jobsSummaryList = props.jobsSummaryList;
    
    // Update only the necessary properties in state when props change
    if (
      itemIdToExpandedRowMap !== state.itemIdToExpandedRowMap ||
      jobsSummaryList !== state.jobsSummaryList
    ) {
      return {
        itemIdToExpandedRowMap,
        jobsSummaryList,
      };
    }

    return null;
  }

  onTableChange = ({ page = {}, sort = {} }) => {
    const { index: pageIndex, size: pageSize } = page;
    const { field: sortField, direction: sortDirection } = sort;

    this.props.onJobsViewStateUpdate({
      pageIndex,
      pageSize,
      sortField,
      sortDirection,
    });
  };

  toggleRow = (item) => {
    this.props.toggleRow(item.id);
  };

  getJobIdLink(id) {
    // Don't allow link to job if ML is not enabled in the current space
    if (this.props.isMlEnabledInSpace === false) {
      return id;
    }

    return <AnomalyDetectionJobIdLink key={id} id={id} />;
  }

  getPageOfJobs(index, size, sortField, sortDirection) {
    let list = this.state.jobsSummaryList;
    list = sortBy(this.state.jobsSummaryList, (item) => item[sortField]);
    list = sortDirection === 'asc' ? list : list.reverse();
    const listLength = list.length;

    let pageStart = index * size;
    if (pageStart >= listLength && listLength !== 0) {
      // if the page start is larger than the number of items due to
      // filters being applied or jobs being deleted, calculate a new page start
      pageStart = Math.floor((listLength - 1) / size) * size;
      // set the state out of the render cycle
      setTimeout(() => {
        this.props.onJobsViewStateUpdate({
          pageIndex: pageStart / size,
        });
      }, 0);
    }
    return {
      pageOfItems: list.slice(pageStart, pageStart + size),
      totalItemCount: listLength,
    };
  }

  render() {
    const { loading } = this.props;
    const selectionControls = {
      selectable: (job) => job.blocked === undefined,
      selectableMessage: (selectable, rowItem) =>
        selectable === false
          ? i18n.translate('xpack.ml.jobsList.cannotSelectRowForJobMessage', {
              defaultMessage: 'Cannot select job ID {jobId}',
              values: {
                jobId: rowItem.id,
              },
            })
          : i18n.translate('xpack.ml.jobsList.selectRowForJobMessage', {
              defaultMessage: 'Select the row for job ID {jobId}',
              values: {
                jobId: rowItem.id,
              },
            }),
      onSelectionChange: this.props.selectJobChange,
    };

    // Rest of the component's code

    return (
      <EuiBasicTable
        // Rest of the table props
      />
    );
  }
}

JobsList.propTypes = {
  // Prop types
};

JobsList.defaultProps = {
  // Default props
};

export default JobsList;
