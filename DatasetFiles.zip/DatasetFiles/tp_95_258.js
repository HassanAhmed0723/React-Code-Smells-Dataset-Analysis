const FilterValue: React.FC<FilterControlProps> = ({
    dataMaskSelected,
    filter,
    onFilterSelectionChange,
    inView = true,
    showOverflow,
    parentRef,
    setFilterActive,
    orientation = FilterBarOrientation.VERTICAL,
    overflow = false,
  })