class FuelSource {
    ignite() {
        // Ignite the fuel source
    }

    extinguish() {
        // Extinguish the fuel source
    }
}

class GasolineSource extends FuelSource {
    ignite() {
        console.log("Gasoline ignited");
    }

    extinguish() {
        console.log("Gasoline extinguished");
    }
}

class ElectricSource extends FuelSource {
    ignite() {
        console.log("Electricity ignited");
    }

    extinguish() {
        console.log("Electricity extinguished");
    }
}

class Appliance {
    constructor(fuelSource) {
        this.fuelSource = fuelSource;
    }

    ignite() {
        this.fuelSource.ignite();
    }

    extinguish() {
        this.fuelSource.extinguish();
    }
}

class GasStove extends Appliance {
    constructor() {
        super(new GasolineSource());
    }
}

class ElectricOven extends Appliance {
    constructor() {
        super(new ElectricSource());
    }
}

const gasStove = new GasStove();
gasStove.ignite();      // Ignite the gasoline source in the gas stove
gasStove.extinguish();  // Extinguish the gasoline source in the gas stove

const electricOven = new ElectricOven();
electricOven.ignite();  // Ignite the electricity source in the electric oven
electricOven.extinguish();  // Extinguish the electricity source in the electric oven
