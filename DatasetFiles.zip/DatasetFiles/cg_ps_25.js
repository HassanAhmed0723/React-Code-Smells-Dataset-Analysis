class CustomTeamDetails extends React.PureComponent {
  static propTypes = {
    team: PropTypes.shape({
      display_name: PropTypes.string,
      id: PropTypes.string,
      group_constrained: PropTypes.bool,
      allow_open_invite: PropTypes.bool,
      allowed_domains: PropTypes.string,
      delete_at: PropTypes.number,
    }),
    groups: PropTypes.arrayOf(PropTypes.object),
    totalGroups: PropTypes.number,
    teamID: PropTypes.string,
    actions: PropTypes.shape({
      getTeam: PropTypes.func,
      getGroups: PropTypes.func,
      patchTeam: PropTypes.func,
      patchGroupSyncable: PropTypes.func,
      unlinkGroupSyncable: PropTypes.func,
      linkGroupSyncable: PropTypes.func,
      deleteTeam: PropTypes.func,
      unarchiveTeam: PropTypes.func,
      membersMinusGroupMembers: PropTypes.func,
      addUserToTeam: PropTypes.func,
      removeUserFromTeam: PropTypes.func,
      updateTeamMemberSchemeRoles: PropTypes.func,
      setNavigationBlocked: PropTypes.func,
    }),
    isLicensedForLDAPGroups: PropTypes.bool,
    allGroups: PropTypes.objectOf(PropTypes.object),
    isDisabled: PropTypes.bool,
  };

  static defaultProps = {
    team: { display_name: '', id: '', group_constrained: false, allow_open_invite: false, allowed_domains: '', delete_at: 0 },
  };

  constructor(props) {
    super(props);

    const team = props.team;
    this.state = {
      groups: props.groups,
      syncChecked: Boolean(team.group_constrained),
      allAllowedChecked: team.allow_open_invite,
      allowedDomainsChecked: Boolean(team.allowed_domains && team.allowed_domains !== ''),
      allowedDomains: team.allowed_domains || '',
      saving: false,
      showRemoveConfirmation: false,
      usersToRemoveCount: 0,
      usersToRemove: {},
      usersToAdd: {},
      rolesToUpdate: {},
      totalGroups: props.totalGroups,
      saveNeeded: false,
      serverError: undefined,
      previousServerError: undefined,
      isLocalArchived: team.delete_at > 0,
      showArchiveConfirmModal: false,
    };
  }

  render = () => {
    const {
      team,
      isLicensedForLDAPGroups,
      groups,
      removedGroups,
      totalGroups,
      allGroups,
      teamID,
      isDisabled,
    } = this.props;
    const {
      saving,
      saveNeeded,
      serverError,
      syncChecked,
      allAllowedChecked,
      allowedDomainsChecked,
      allowedDomains,
      showRemoveConfirmation,
      usersToRemoveCount,
      isLocalArchived,
      showArchiveConfirmModal,
    } = this.state;

    const missingGroup = (og) => !groups.find((g) => g.id === og.id);
    const removedGroups = this.props.groups.filter(missingGroup);
    const nonArchivedContent = (
      {/* Render non-archived content */}
    );

    return (
      <div className="wrapper--fixed">
        {/* Render the rest of the component */}
      </div>
    );
  };
}

