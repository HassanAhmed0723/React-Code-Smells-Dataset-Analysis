export const InteractiveAlert = (args: AlertProps) => (
    <>
      <Alert {...args} />
      Some content to test the `roomBelow` prop
    </>
  );
  
  InteractiveAlert.args = {
    closable: true,
    roomBelow: false,
    type: 'info',
    message: smallText,
    description: bigText,
    showIcon: true,
  };
  
  InteractiveAlert.argTypes = {
    onClose: { action: 'onClose' },
    type: {
      control: { type: 'select', options: types },
    },
  };
  
  InteractiveAlert.story = {
    parameters: {
      knobs: {
        disable: true,
      },
    },
  };