class CustomSetting extends React.Component {
  static propTypes = {
    id: PropTypes.string.isRequired,
    label: PropTypes.node.isRequired,
    helpText: PropTypes.node,
    initialValue: PropTypes.string.isRequired,
    onSubmit: PropTypes.func.isRequired,
    disabled: PropTypes.bool,
    error: PropTypes.string,
  };

  constructor(props) {
    super(props);

    this.state = {
      value: props.initialValue,
      serverError: props.error,
      submitting: false,
    };
  }

  handleChange = (e) => {
    this.setState({ value: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    this.setState({ submitting: true });
    this.props.onSubmit(this.props.id, this.state.value, (error) => {
      this.setState({ submitting: false });
      if (error) {
        // Handle error if needed
      }
    });
  };

  render() {
    let serverError;
    if (this.state.serverError) {
      serverError = <div className='form-group has-error'><label className='control-label'>{this.state.serverError}</label></div>;
    }

    let btnClass = 'btn';
    if (this.state.value) {
      btnClass = 'btn btn-primary';
    }

    return (
      <div>
        <div className='custom-setting'>
          <input
            type='text'
            value={this.state.value}
            disabled={this.props.disabled}
            onChange={this.handleChange}
          />
          <button
            type='button'
            className={btnClass}
            onClick={this.handleSubmit}
            disabled={this.state.submitting || this.props.disabled}
          >
            Submit
          </button>
        </div>
        {serverError}
      </div>
    );
  }
}

