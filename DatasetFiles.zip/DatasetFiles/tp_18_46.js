export const WithNegativeNumbers = ({ width, height }) => (
    <SuperChart
      chartType="mixed-timeseries"
      width={width}
      height={height}
      queriesData={[
        {
          data: negativeNumData,
          colnames: ['__timestamp'],
          coltypes: [2],
        },
        {
          data: negativeNumData.map(({ __timestamp, Boston }) => ({
            __timestamp,
            avgRate: Boston / 100,
          })),
        },
      ]}
      formData={{
        contributionMode: undefined,
        colorScheme: 'supersetColors',
        seriesType: select(
          'Line type',
          ['line', 'scatter', 'smooth', 'bar', 'start', 'middle', 'end'],
          'line',
        ),
        xAxisTimeFormat: 'smart_date',
        yAxisFormat: select(
          'y-axis format',
          {
            'Original value': '~g',
            'Smart number': 'SMART_NUMBER',
            '(12345.432 => $12,345.43)': '$,.2f',
          },
          '$,.2f',
        ),
        stack: true,
        showValue: boolean('Query 1: Show Value', true),
        showValueB: boolean('Query 2: Show Value', false),
        showLegend: true,
        markerEnabledB: true,
        yAxisIndexB: select(
          'Query 2: Y Axis',
          {
            Primary: 0,
            Secondary: 1,
          },
          1,
        ),
      }}
    />
  );