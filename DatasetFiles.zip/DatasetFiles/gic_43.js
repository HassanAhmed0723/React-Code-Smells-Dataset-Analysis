class Report {
    constructor(content) {
        this.content = content;
    }

    generate() {
        console.log("Generating report:", this.content);
    }
}

class ExcelReport extends Report {
    constructor(content) {
        super(content);
    }

    generate() {
        console.log("Generating Excel report:", this.content);
    }
}

class PDFReport extends Report {
    constructor(content) {
        super(content);
    }

    generate() {
        console.log("Generating PDF report:", this.content);
    }
}

const excelReport = new ExcelReport("Monthly sales data");
excelReport.generate(); // Output: Generating Excel report: Monthly sales data

const pdfReport = new PDFReport("Quarterly financial summary");
pdfReport.generate();   // Output: Generating PDF report: Quarterly financial summary
