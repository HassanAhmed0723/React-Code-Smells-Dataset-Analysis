class ExampleComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      field: props.field,
      refreshNonce: Math.random().toString(),
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.field !== prevState.field) {
      return {
        field: nextProps.field,
        refreshNonce: Math.random().toString(),
      };
    }

    return null;
  }

  render() {
    const { field } = this.state;
    const { label, helpText } = this.props;

    return (
      <div className='form-group'>
        {label && <label>{label}</label>}
        <React.Fragment key={this.state.refreshNonce}>
        </React.Fragment>
        <div className='help-text'>{helpText}</div>
      </div>
    );
  }
}
