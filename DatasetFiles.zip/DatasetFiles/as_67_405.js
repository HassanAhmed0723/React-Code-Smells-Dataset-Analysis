const Loader = (inline: string) => (
  <div className="loading-container">
    <Loading position="inline" />
    <p>{inline}</p>
  </div>
);


