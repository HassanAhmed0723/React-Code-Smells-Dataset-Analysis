export const WeekdayPie = ({ width, height }) => (
    <SuperChart
      chartType="echarts-pie"
      width={width}
      height={height}
      queriesData={[{ data: weekday }]}
      formData={{
        colorScheme: 'supersetColors',
        groupby: ['Day'],
        metric: 'SUM(AIR_TIME)',
        numberFormat: 'SMART_NUMBER',
        donut: boolean('Donut', false),
        innerRadius: number('Inner Radius', 30),
        outerRadius: number('Outer Radius', 70),
        labelsOutside: boolean('Labels outside', true),
        labelLine: boolean('Label line', true),
        showLabels: boolean('Show labels', true),
        showLegend: boolean('Show legend', false),
        labelType: select(
          'Pie label type',
          [
            'key',
            'value',
            'percent',
            'key_value',
            'key_percent',
            'key_value_percent',
          ],
          'key',
        ),
      }}
    />
  );