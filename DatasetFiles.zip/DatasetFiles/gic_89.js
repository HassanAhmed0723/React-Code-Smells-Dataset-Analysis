function createSaveQueryConflictError() {
    const message = (
        <>
            <div className="m-b-5">It seems like the query has been modified by another user.</div>
            <div>Please copy/backup your changes and reload this page.</div>
        </>
    );

    return createSaveQueryError('Changes not saved', message);
}

// Usage example
const saveQueryConflictError = createSaveQueryConflictError();

console.log(saveQueryConflictError.message);
console.log(saveQueryConflictError.detailedMessage);
