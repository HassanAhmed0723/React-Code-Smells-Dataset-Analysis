export const SelectGallery = ({ value }: { value: OptionTypeBase }) => (
    <>
      <h4>With default value</h4>
      <Select
        value={OPTIONS[0]}
        ignoreAccents={false}
        name="select-datasource"
        onChange={() => {}}
        options={OPTIONS}
        placeholder="choose one"
        width={600}
      />
      <hr />
      <h4>With no value</h4>
      <Select
        ignoreAccents={false}
        name="select-datasource"
        onChange={() => {}}
        options={OPTIONS}
        placeholder="choose one"
        width={600}
        value={value}
      />
      <hr />
      <h4>Multi select</h4>
      <Select
        ignoreAccents={false}
        name="select-datasource"
        onChange={() => {}}
        options={OPTIONS}
        placeholder="choose one or more values"
        width={600}
        value={[OPTIONS[0]]}
        multi
      />
    </>
  );
  