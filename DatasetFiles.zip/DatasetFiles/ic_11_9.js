export class WideNoChartLayout extends BigValueLayout {
    constructor(props: Props) {
      super(props);
  
      const valueWidthPercent = this.titleToAlignTo?.length ? 0.3 : 1.0;
  
      if (this.valueToAlignTo.length) {
        // initial value size
        this.valueFontSize = calculateFontSize(
          this.valueToAlignTo,
          this.maxTextWidth * valueWidthPercent,
          this.maxTextHeight,
          LINE_HEIGHT,
          undefined,
          VALUE_FONT_WEIGHT
        );
      }
  
      if (this.titleToAlignTo?.length) {
        // How big can we make the title and still have it fit
        this.titleFontSize = calculateFontSize(
          this.titleToAlignTo,
          this.maxTextWidth * 0.6,
          this.maxTextHeight,
          LINE_HEIGHT,
          MAX_TITLE_SIZE
        );
  
        // make sure it's a bit smaller than valueFontSize
        this.titleFontSize = Math.min(this.valueFontSize * 0.7, this.titleFontSize);
      }
    }
  
    getValueAndTitleContainerStyles() {
      const styles = super.getValueAndTitleContainerStyles();
      styles.flexDirection = 'row';
      styles.alignItems = 'center';
      styles.flexGrow = 1;
  
      if (!this.justifyCenter) {
        styles.justifyContent = 'space-between';
      }
  
      return styles;
    }
  
    renderChart(): JSX.Element | null {
      return null;
    }
  
    getPanelStyles() {
      const panelStyles = super.getPanelStyles();
      panelStyles.alignItems = 'center';
      return panelStyles;
    }
  }