function createSaveQueryError(message, detailedMessage = null) {
    return {
        message: message,
        detailedMessage: detailedMessage,
        isError: true,
    };
}

// Usage example
const saveQueryError = createSaveQueryError('Error while saving query', 'Detailed error information');

console.log(saveQueryError.message);
console.log(saveQueryError.detailedMessage);
