export default class SelectControl extends React.PureComponent {
    constructor(props) {
      super(props);
      this.state = {
        options: this.getOptions(props),
      };
      this.onChange = this.onChange.bind(this);
      this.handleFilterOptions = this.handleFilterOptions.bind(this);
    }
  
    UNSAFE_componentWillReceiveProps(nextProps) {
      if (
        !isEqualArray(nextProps.choices, this.props.choices) ||
        !isEqualArray(nextProps.options, this.props.options)
      ) {
        const options = this.getOptions(nextProps);
        this.setState({ options });
      }
    }
  
    // Beware: This is acting like an on-click instead of an on-change
    // (firing every time user chooses vs firing only if a new option is chosen).
    onChange(val) {
      // will eventually call `exploreReducer`: SET_FIELD_VALUE
      const { valueKey } = this.props;
      let onChangeVal = val;
  
      if (Array.isArray(val)) {
        const values = val.map(v =>
          v?.[valueKey] !== undefined ? v[valueKey] : v,
        );
        onChangeVal = values;
      }
      if (typeof val === 'object' && val?.[valueKey] !== undefined) {
        onChangeVal = val[valueKey];
      }
      this.props.onChange(onChangeVal, []);
    }
  
    getOptions(props) {
      const { choices, optionRenderer, valueKey } = props;
      let options = [];
      if (props.options) {
        options = props.options.map(o => ({
          ...o,
          value: o[valueKey],
          label: o.label || o[valueKey],
          customLabel: optionRenderer ? optionRenderer(o) : undefined,
        }));
      } else if (choices) {
        // Accepts different formats of input
        options = choices.map(c => {
          if (Array.isArray(c)) {
            const [value, label] = c.length > 1 ? c : [c[0], c[0]];
            return {
              value,
              label,
            };
          }
          if (Object.is(c)) {
            return {
              ...c,
              value: c[valueKey],
              label: c.label || c[valueKey],
            };
          }
          return { value: c, label: c };
        });
      }
      return options;
    }
  
    handleFilterOptions(text, option) {
      const { filterOption } = this.props;
      return filterOption({ data: option }, text);
    }
  
    render() {
      const {
        ariaLabel,
        autoFocus,
        clearable,
        disabled,
        filterOption,
        freeForm,
        isLoading,
        isMulti,
        label,
        multi,
        name,
        notFoundContent,
        onFocus,
        onSelect,
        onDeselect,
        placeholder,
        showHeader,
        tokenSeparators,
        value,
        // ControlHeader props
        description,
        renderTrigger,
        rightNode,
        leftNode,
        validationErrors,
        onClick,
        hovered,
        tooltipOnClick,
        warning,
        danger,
      } = this.props;
  
      const headerProps = {
        name,
        label,
        description,
        renderTrigger,
        rightNode,
        leftNode,
        validationErrors,
        onClick,
        hovered,
        tooltipOnClick,
        warning,
        danger,
      };
  
      const getValue = () => {
        const currentValue =
          value ||
          (this.props.default !== undefined ? this.props.default : undefined);
  
        // safety check - the value is intended to be undefined but null was used
        if (
          currentValue === null &&
          !this.state.options.find(o => o.value === null)
        ) {
          return undefined;
        }
        return currentValue;
      };
  
      const selectProps = {
        allowNewOptions: freeForm,
        autoFocus,
        ariaLabel:
          ariaLabel || (typeof label === 'string' ? label : t('Select ...')),
        allowClear: clearable,
        disabled,
        filterOption:
          filterOption && typeof filterOption === 'function'
            ? this.handleFilterOptions
            : true,
        header: showHeader && <ControlHeader {...headerProps} />,
        loading: isLoading,
        mode: this.props.mode || (isMulti || multi ? 'multiple' : 'single'),
        name: `select-${name}`,
        onChange: this.onChange,
        onFocus,
        onSelect,
        onDeselect,
        options: this.state.options,
        placeholder,
        sortComparator: this.props.sortComparator,
        value: getValue(),
        tokenSeparators,
        notFoundContent,
      };
  
      return (
        <div
          css={theme => css`
            .type-label {
              margin-right: ${theme.gridUnit * 2}px;
            }
            .Select__multi-value__label > span,
            .Select__option > span,
            .Select__single-value > span {
              display: flex;
              align-items: center;
            }
          `}
        >
          <Select {...selectProps} />
        </div>
      );
    }
  }
  