class BaseScreenComponent extends React.Component {
    componentDidMount() {
        console.log("BaseScreenComponent componentDidMount");
    }

    render() {
        return (
            <div>
                Base Screen Component
            </div>
        );
    }
}

class ConfigScreenComponent extends BaseScreenComponent {
    componentDidMount() {
        super.componentDidMount();
        console.log("ConfigScreenComponent componentDidMount");
    }

    render() {
        return (
            <div>
                Config Screen Component
            </div>
        );
    }
}

ReactDOM.render(<ConfigScreenComponent />, document.getElementById("root"));
