class PaymentProcessor {
    processPayment(amount) {
        // Logic to process payment
    }
}

class CreditCardPaymentProcessor extends PaymentProcessor {
    processPayment(amount) {
        // Logic to process credit card payment
    }
}

class PayPalPaymentProcessor extends PaymentProcessor {
    processPayment(amount) {
        // Logic to process PayPal payment
    }
}

class Order {
    constructor(paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }

    checkout(amount) {
        this.paymentProcessor.processPayment(amount);
    }
}

class CreditCardOrder extends Order {
    constructor() {
        super(new CreditCardPaymentProcessor());
    }
}

class PayPalOrder extends Order {
    constructor() {
        super(new PayPalPaymentProcessor());
    }
}

const creditCardOrder = new CreditCardOrder();
creditCardOrder.checkout(100);  // Process credit card payment

const payPalOrder = new PayPalOrder();
payPalOrder.checkout(50);       // Process PayPal payment
