export function CustomModalSuggestionList(props: CustomModalSuggestionListProps) {
    const container = React.useRef<HTMLDivElement>(null);
    const suggestionList = React.useRef<any>(null);
    const [scroll, setScroll] = React.useState(0);
    const [modalBounds, setModalBounds] = React.useState({top: 0, bottom: 0});
    const [inputBounds, setInputBounds] = React.useState({top: 0, bottom: 0, width: 0});
    const [position, setPosition] = React.useState(props.position);

    const latestHeight = React.useRef(0);

    const calculateInputRect = React.useCallback(() => {
        if (props.inputRef.current) {
            const rect = props.inputRef.current.getBoundingClientRect();
            return {top: rect.top, bottom: rect.bottom, width: rect.width};
        }
        return {top: 0, bottom: 0, width: 0};
    }, [props.inputRef]);

    const onModalScroll = React.useCallback((e: Event) => {
        const eventTarget = e.target as HTMLElement;
        if (scroll !== eventTarget.scrollTop && latestHeight.current !== 0) {
            setScroll(eventTarget.scrollTop);
        }
    }, [scroll]);

    const updateInputBounds = React.useCallback(() => {
        const inputBounds = calculateInputRect();
        if (inputBounds.top !== inputBounds.top || inputBounds.bottom !== inputBounds.bottom || inputBounds.width !== inputBounds.width) {
            setInputBounds(inputBounds);
        }
        return inputBounds;
    }, [calculateInputRect]);

    const updatePosition = React.useCallback((newInputBounds: { top: number; bottom: number; width: number}) => {
        let inputBounds = newInputBounds;
        if (!newInputBounds) {
            inputBounds = inputBounds;
        }

        if (!container.current) {
            return;
        }

        latestHeight.current = suggestionList.current?.getContent()?.[0]?.getBoundingClientRect().height || 0;

        let newPosition = props.position;
        if (window.innerHeight < inputBounds.bottom + latestHeight.current) {
            newPosition = 'top';
        }
        if (inputBounds.top - latestHeight.current < 0) {
            newPosition = 'bottom';
        }

        if (position !== newPosition) {
            setPosition(newPosition);
        }
    }, [position, props.position]);

    const updateModalBounds = React.useCallback(() => {
        if (!container.current) {
            return;
        }

        const modalContainer = getClosestParent(container.current, '.modal-content');
        const modalBounds = modalContainer?.getBoundingClientRect();

        if (modalBounds) {
            if (modalBounds.top !== modalBounds.top || modalBounds.bottom !== modalBounds.bottom) {
                setModalBounds({top: modalBounds.top, bottom: modalBounds.bottom});
            }
        }
    }, []);

    React.useEffect(() => {
        if (container.current) {
            const modalBodyContainer = getClosestParent(container.current, '.modal-body');
            modalBodyContainer?.addEventListener('scroll', onModalScroll);
        }
        window.addEventListener('resize', updateModalBounds);

        return () => {
            if (container.current) {
                const modalBodyContainer = getClosestParent(container.current, '.modal-body');
                modalBodyContainer?.removeEventListener('scroll', onModalScroll);
            }
            window.removeEventListener('resize', updateModalBounds);
        };
    }, [onModalScroll, updateModalBounds]);

    React.useEffect(() => {
        if (!props.open || props.cleared) {
            return;
        }

        if (!props.open || props.cleared || scroll !== scroll || modalBounds.top !== modalBounds.top || modalBounds.bottom !== modalBounds.bottom) {
            const newInputBounds = updateInputBounds();
            updatePosition(newInputBounds);

            if (container.current) {
                const modalBodyRect = getClosestParent(container.current, '.modal-body')?.getBoundingClientRect();
                if (modalBodyRect && ((newInputBounds.bottom < modalBodyRect.top) || (newInputBounds.top > modalBodyRect.bottom))) {
                    props.onLoseVisibility();
                    return;
                }
            }

            updateModalBounds();
        }
    }, [props, scroll, modalBounds, updateInputBounds, updatePosition, updateModalBounds]);

    const positionStyle = position === 'top' ? {bottom: modalBounds.bottom - inputBounds.top} : {top: inputBounds.bottom - modalBounds.top};

    return (
        <div style={{position: 'fixed', zIndex: 101, width: inputBounds.width, ...positionStyle}} ref={container}>
            <CustomSuggestionList {...props} position={position} ref={suggestionList} />
        </div>
    );
}
