export const PopulationPie = ({ width, height }) => (
    <SuperChart
      chartType="echarts-pie"
      width={width}
      height={height}
      queriesData={[{ data: population }]}
      formData={{
        colorScheme: 'supersetColors',
        groupby: ['Country'],
        metric: 'Population',
        numberFormat: 'SMART_NUMBER',
        donut: boolean('Donut', false),
        innerRadius: number('Inner Radius', 30),
        outerRadius: number('Outer Radius', 70),
        labelsOutside: boolean('Labels outside', false),
        labelLine: boolean('Label line', true),
        showLabels: boolean('Show labels', true),
        showLegend: boolean('Show legend', false),
        labelType: select(
          'Pie label type',
          [
            'key',
            'value',
            'percent',
            'key_value',
            'key_percent',
            'key_value_percent',
          ],
          'key',
        ),
      }}
    />
  );