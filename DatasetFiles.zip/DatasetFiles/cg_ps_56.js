class SampleErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorTriggered: !!props.asError,
      previousPathname: props.pathname,
    };
  }

  static getDerivedStateFromError(error) {
    if (error?.code === 'SOME_ERROR_CODE') {
      return { errorTriggered: true };
    }
    // Re-throw if error is not the specific error we're looking for
    throw error;
  }

  static getDerivedStateFromProps(props, state) {
    /**
     * Handles reset of the error boundary when a navigation happens.
     * Ensures the error boundary does not stay enabled when navigating to a new page.
     * Approach of setState in render is safe as it checks the previous pathname and then overrides
     * it as outlined in https://react.dev/reference/react/useState#storing-information-from-previous-renders
     */
    if (props.pathname !== state.previousPathname && state.errorTriggered) {
      return {
        errorTriggered: false,
        previousPathname: props.pathname,
      };
    }
    return {
      errorTriggered: state.errorTriggered,
      previousPathname: props.pathname,
    };
  }

  render() {
    if (this.state.errorTriggered) {
      return (
        <>
          {/* Some custom error handling */}
          {this.props.errorMessage}
        </>
      );
    }

    return this.props.children;
  }
}

export default SampleErrorBoundary;
