class AnnotationLayer extends React.PureComponent {
    constructor(props) {
      super(props);
      const {
        name,
        annotationType,
        sourceType,
        color,
        opacity,
        style,
        width,
        showMarkers,
        hideLine,
        value,
        overrides,
        show,
        showLabel,
        titleColumn,
        descriptionColumns,
        timeColumn,
        intervalEndColumn,
        vizType,
      } = props;