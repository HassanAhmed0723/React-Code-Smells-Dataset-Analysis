class ExampleComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      data: props.initialData,
    };
  }

  static getDerivedStateFromProps(props, state) {
    if (props.initialData !== state.data) {
      return {
        data: props.initialData,
      };
    }

    return null;
  }

  render() {
    const { data } = this.state;

    return (
      <div>
        <h1>Example Component</h1>
        <p>Data from props: {data}</p>
      </div>
    );
  }
}
