class SaveQueryConflictError extends SaveQueryError {
    constructor() {
      super(
        "Changes not saved",
        <React.Fragment>
          <div className="m-b-5">It seems like the query has been modified by another user.</div>
          <div>Please copy/backup your changes and reload this page.</div>
        </React.Fragment>
      );
    }
  }