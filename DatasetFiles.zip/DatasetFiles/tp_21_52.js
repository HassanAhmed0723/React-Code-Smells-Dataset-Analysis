export const Timeseries = ({ width, height }) => {
    const forecastEnabled = boolean('Enable forecast', true);
    const queryData = data
      .map(row =>
        forecastEnabled
          ? row
          : {
              // eslint-disable-next-line no-underscore-dangle
              __timestamp: row.__timestamp,
              Boston: row.Boston,
              California: row.California,
              WestTexNewMexico: row.WestTexNewMexico,
            },
      )
      .filter(row => forecastEnabled || !!row.Boston);
    return (
      <SuperChart
        chartType="echarts-timeseries"
        width={width}
        height={height}
        queriesData={[
          { data: queryData, colnames: ['__timestamp'], coltypes: [2] },
        ]}
        formData={{
          forecastEnabled,
          color_scheme: 'supersetColors',
          seriesType: select(
            'Line type',
            ['line', 'scatter', 'smooth', 'bar', 'start', 'middle', 'end'],
            'line',
          ),
          logAxis: boolean('Log axis', false),
          y_axis_format: 'SMART_NUMBER',
          stack: boolean('Stack', false),
          show_value: boolean('Show Values', false),
          only_total: boolean('Only Total', false),
          percentage_threshold: number('Percentage Threshold', 0),
          area: boolean('Area chart', false),
          markerEnabled: boolean('Enable markers', false),
          markerSize: number('Marker Size', 6),
          minorSplitLine: boolean('Minor splitline', false),
          opacity: number('Opacity', 0.2),
          zoomable: boolean('Zoomable', false),
          x_axis: '__timestamp',
        }}
      />
    );
  };