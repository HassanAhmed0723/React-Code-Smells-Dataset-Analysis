export default class WithPopoverMenu extends React.PureComponent<
  WithPopoverMenuProps,
  WithPopoverMenuState
> {
  container: ShouldFocusContainer;

  static defaultProps = {
    children: null,
    disableClick: false,
    onChangeFocus: null,
    menuItems: [],
    isFocused: false,
    shouldFocus: (event: any, container: ShouldFocusContainer) =>
      container?.contains(event.target) ||
      event.target.id === 'menu-item' ||
      event.target.parentNode?.id === 'menu-item',
    style: null,
  };

  constructor(props: WithPopoverMenuProps) {
    super(props);
    this.state = {
      isFocused: props.isFocused!,
    };
    this.setRef = this.setRef.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps: WithPopoverMenuProps) {
    if (nextProps.editMode && nextProps.isFocused && !this.state.isFocused) {
      document.addEventListener('click', this.handleClick);
      document.addEventListener('drag', this.handleClick);
      this.setState({ isFocused: true });
    } else if (this.state.isFocused && !nextProps.editMode) {
      document.removeEventListener('click', this.handleClick);
      document.removeEventListener('drag', this.handleClick);
      this.setState({ isFocused: false });
    }
  }

  componentWillUnmount() {
    document.removeEventListener('click', this.handleClick);
    document.removeEventListener('drag', this.handleClick);
  }

  setRef(ref: ShouldFocusContainer) {
    this.container = ref;
  }

  handleClick(event: any) {
    if (!this.props.editMode) {
      return;
    }
    const {
      onChangeFocus,
      shouldFocus: shouldFocusFunc,
      disableClick,
    } = this.props;

    const shouldFocus = shouldFocusFunc(event, this.container);

    if (!disableClick && shouldFocus && !this.state.isFocused) {
      // if not focused, set focus and add a window event listener to capture outside clicks
      // this enables us to not set a click listener for ever item on a dashboard
      document.addEventListener('click', this.handleClick);
      document.addEventListener('drag', this.handleClick);
      this.setState(() => ({ isFocused: true }));
      if (onChangeFocus) {
        onChangeFocus(true);
      }
    } else if (!shouldFocus && this.state.isFocused) {
      document.removeEventListener('click', this.handleClick);
      document.removeEventListener('drag', this.handleClick);
      this.setState(() => ({ isFocused: false }));
      if (onChangeFocus) {
        onChangeFocus(false);
      }
    }
  }

  render() {
    const { children, menuItems, editMode, style } = this.props;
    const { isFocused } = this.state;

    return (
      <WithPopoverMenuStyles
        ref={this.setRef}
        onClick={this.handleClick}
        role="none"
        className={cx(
          'with-popover-menu',
          editMode && isFocused && 'with-popover-menu--focused',
        )}
        style={style}
      >
        {children}
        {editMode && isFocused && (menuItems?.length ?? 0) > 0 && (
          <PopoverMenuStyles>
            {menuItems.map((node: React.ReactNode, i: Number) => (
              <div className="menu-item" key={`menu-item-${i}`}>
                {node}
              </div>
            ))}
          </PopoverMenuStyles>
        )}
      </WithPopoverMenuStyles>
    );
  }
}


