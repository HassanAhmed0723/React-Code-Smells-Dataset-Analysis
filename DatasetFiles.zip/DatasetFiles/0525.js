export class ParameterMappingInput extends React.Component {
    static propTypes = {
      mapping: PropTypes.object, // eslint-disable-line react/forbid-prop-types
      existingParamNames: PropTypes.arrayOf(PropTypes.string),
      onChange: PropTypes.func,
      inputError: PropTypes.string,
    };
  
    static defaultProps = {
      mapping: {},
      existingParamNames: [],
      onChange: () => {},
      inputError: null,
    };
  
    formItemProps = {
      labelCol: { span: 5 },
      wrapperCol: { span: 16 },
      className: "form-item",
    };
  
    updateSourceType = type => {
      let {
        mapping: { mapTo },
      } = this.props;
      const { existingParamNames } = this.props;
  
      // if mapped name doesn't already exists
      // default to first select option
      if (type === MappingType.DashboardMapToExisting && !includes(existingParamNames, mapTo)) {
        mapTo = existingParamNames[0];
      }
  
      this.updateParamMapping({ type, mapTo });
    };
  
    updateParamMapping = update => {
      const { onChange, mapping } = this.props;
      const newMapping = extend({}, mapping, update);
      if (newMapping.value !== mapping.value) {
        newMapping.param = cloneParameter(newMapping.param);
        newMapping.param.setValue(newMapping.value);
      }
      if (has(update, "type")) {
        if (update.type === MappingType.StaticValue) {
          newMapping.value = newMapping.param.value;
        } else {
          newMapping.value = null;
        }
      }
      onChange(newMapping);
    };
  
    renderMappingTypeSelector() {
      const noExisting = isEmpty(this.props.existingParamNames);
      return (
        <Radio.Group value={this.props.mapping.type} onChange={e => this.updateSourceType(e.target.value)}>
          <Radio className="radio" value={MappingType.DashboardAddNew} data-test="NewDashboardParameterOption">
            New dashboard parameter
          </Radio>
          <Radio className="radio" value={MappingType.DashboardMapToExisting} disabled={noExisting}>
            Existing dashboard parameter{" "}
            {noExisting ? (
              <Tooltip title="There are no dashboard parameters corresponding to this data type">
                <QuestionCircleFilledIcon />
              </Tooltip>
            ) : null}
          </Radio>
          <Radio className="radio" value={MappingType.WidgetLevel} data-test="WidgetParameterOption">
            Widget parameter
          </Radio>
          <Radio className="radio" value={MappingType.StaticValue} data-test="StaticValueOption">
            Static value
          </Radio>
        </Radio.Group>
      );
    }
  
    renderDashboardAddNew() {
      const {
        mapping: { mapTo },
      } = this.props;
      return (
        <Input
          value={mapTo}
          aria-label="Parameter name (key)"
          onChange={e => this.updateParamMapping({ mapTo: e.target.value })}
        />
      );
    }
  
    renderDashboardMapToExisting() {
      const { mapping, existingParamNames } = this.props;
      const options = map(existingParamNames, paramName => ({ label: paramName, value: paramName }));
  
      return <Select value={mapping.mapTo} onChange={mapTo => this.updateParamMapping({ mapTo })} options={options} />;
    }
  
    renderStaticValue() {
      const { mapping } = this.props;
      return (
        <ParameterValueInput
          type={mapping.param.type}
          value={mapping.param.normalizedValue}
          enumOptions={mapping.param.enumOptions}
          queryId={mapping.param.queryId}
          parameter={mapping.param}
          onSelect={value => this.updateParamMapping({ value })}
        />
      );
    }
  
    renderInputBlock() {
      const { mapping } = this.props;
      switch (mapping.type) {
        case MappingType.DashboardAddNew:
          return ["Key", "Enter a new parameter keyword", this.renderDashboardAddNew()];
        case MappingType.DashboardMapToExisting:
          return ["Key", "Select from a list of existing parameters", this.renderDashboardMapToExisting()];
        case MappingType.StaticValue:
          return ["Value", null, this.renderStaticValue()];
        default:
          return [];
      }
    }
  
    render() {
      const { inputError } = this.props;
      const [label, help, input] = this.renderInputBlock();
  
      return (
        <Form layout="horizontal">
          <Form.Item label="Source" {...this.formItemProps}>
            {this.renderMappingTypeSelector()}
          </Form.Item>
          <Form.Item
            style={{ height: 60, visibility: input ? "visible" : "hidden" }}
            label={label}
            {...this.formItemProps}
            validateStatus={inputError ? "error" : ""}
            help={inputError || help} // empty space so line doesn't collapse
          >
            {input}
          </Form.Item>
        </Form>
      );
    }
  }
  
  class MappingEditor extends React.Component {
    static propTypes = {
      mapping: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
      existingParamNames: PropTypes.arrayOf(PropTypes.string).isRequired,
      onChange: PropTypes.func.isRequired,
    };
  
    constructor(props) {
      super(props);
      this.state = {
        visible: false,
        mapping: clone(this.props.mapping),
        inputError: null,
      };
    }
  
    onVisibleChange = visible => {
      if (visible) this.show();
      else this.hide();
    };
  
    onChange = mapping => {
      let inputError = null;
  
      if (mapping.type === MappingType.DashboardAddNew) {
        if (isEmpty(mapping.mapTo)) {
          inputError = "Keyword must have a value";
        } else if (includes(this.props.existingParamNames, mapping.mapTo)) {
          inputError = "A parameter with this name already exists";
        }
      }
  
      this.setState({ mapping, inputError });
    };
  
    save = () => {
      this.props.onChange(this.props.mapping, this.state.mapping);
      this.hide();
    };
  
    show = () => {
      this.setState({
        visible: true,
        mapping: clone(this.props.mapping), // restore original state
      });
    };
  
    hide = () => {
      this.setState({ visible: false });
    };
  
    renderContent() {
      const { mapping, inputError } = this.state;
  
      return (
        <div className="parameter-mapping-editor" data-test="EditParamMappingPopover">
          <header>
            Edit Source and Value <HelpTrigger type="VALUE_SOURCE_OPTIONS" />
          </header>
          <ParameterMappingInput
            mapping={mapping}
            existingParamNames={this.props.existingParamNames}
            onChange={this.onChange}
            inputError={inputError}
          />
          <footer>
            <Button onClick={this.hide}>Cancel</Button>
            <Button onClick={this.save} disabled={!!inputError} type="primary">
              OK
            </Button>
          </footer>
        </div>
      );
    }
  
    render() {
      const { visible, mapping } = this.state;
      return (
        <Popover
          placement="left"
          trigger="click"
          content={this.renderContent()}
          visible={visible}
          onVisibleChange={this.onVisibleChange}>
          <Button size="small" type="dashed" data-test={`EditParamMappingButton-${mapping.param.name}`}>
            <EditOutlinedIcon />
          </Button>
        </Popover>
      );
    }
  }
  