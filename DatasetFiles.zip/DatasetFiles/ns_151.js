export const useDrillByBreadcrumbs = (
    breadcrumbsData: DrillByBreadcrumb[],
    onBreadcrumbClick: (
      breadcrumb: DrillByBreadcrumb,
      index: number,
    ) => void = noOp,
  ) =>
    useMemo(() => {
      // the last breadcrumb is not clickable
      const isClickable = (index: number) => index < breadcrumbsData.length - 1;
      const getBreadcrumbText = (breadcrumb: DrillByBreadcrumb) =>
        `${ensureIsArray(breadcrumb.groupby)
          .map(column => column.verbose_name || column.column_name)
          .join(', ')} ${
          breadcrumb.filters
            ? `(${breadcrumb.filters
                .map(filter => filter.formattedVal || filter.val)
                .join(', ')})`
            : ''
        }`;
      return (
        <AntdBreadcrumb
          css={(theme: SupersetTheme) => css`
            margin: ${theme.gridUnit * 2}px 0 ${theme.gridUnit * 4}px;
          `}
        >
          {breadcrumbsData.map((breadcrumb, index) => (
            <BreadcrumbItem
              key={index}
              isClickable={isClickable(index)}
              onClick={
                isClickable(index)
                  ? () => onBreadcrumbClick(breadcrumb, index)
                  : noOp
              }
              data-test="drill-by-breadcrumb-item"
            >
              {getBreadcrumbText(breadcrumb)}
            </BreadcrumbItem>
          ))}
        </AntdBreadcrumb>
      );
    }, [breadcrumbsData, onBreadcrumbClick]);