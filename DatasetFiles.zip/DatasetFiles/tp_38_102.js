export const CodeEditor: FC<CodeEditorProps> = ({
    mode,
    theme,
    name,
    width,
    height,
    value,
    ...rest
  }: CodeEditorProps)