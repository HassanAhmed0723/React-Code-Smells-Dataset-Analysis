export const handlebarsTemplateControlSetItem: ControlSetItem = {
    name: 'handlebarsTemplate',
    config: {
      ...sharedControls.entity,
      type: HandlebarsTemplateControl,
      label: t('Handlebars Template'),
      description: t('A handlebars template that is applied to the data'),
      default: `<ul class="data-list">
    {{#each data}}
      <li>{{stringify this}}</li>
    {{/each}}
  </ul>`,
      isInt: false,
      renderTrigger: true,
  
      validators: [validateNonEmpty],
      mapStateToProps: ({ controls }) => ({
        value: controls?.handlebars_template?.value,
      }),
    },
  };