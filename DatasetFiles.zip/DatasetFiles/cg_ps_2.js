class CssEditor extends React.PureComponent {
    constructor(props) {
      super(props);
      this.state = {
        css: props.initialCss,
      };
      this.handleChange = this.handleChange.bind(this);
    }
  
    handleChange(event) {
      this.setState({ css: event.target.value });
    }
  
    render() {
      return (
        <div>
          <textarea
            value={this.state.css}
            onChange={this.handleChange}
          />
        </div>
      );
    }
  }
  