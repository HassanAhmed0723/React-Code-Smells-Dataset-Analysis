const FilterableTable = ({
    orderedColumnKeys,
    data,
    height,
    filterText = '',
    expandedColumns = [],
  }: FilterableTableProps)