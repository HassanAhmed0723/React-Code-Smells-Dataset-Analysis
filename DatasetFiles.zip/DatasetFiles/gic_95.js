class Vehicle {
    constructor(make, model) {
      this.make = make;
      this.model = model;
    }
  
    startEngine() {
      console.log(`Starting the engine of ${this.make} ${this.model}`);
    }
  }
  
  class Car extends Vehicle {
    constructor(make, model, numDoors) {
      super(make, model);
      this.numDoors = numDoors;
    }
  
    startEngine() {
      console.log(`Starting the car's engine`);
      super.startEngine();
    }
  }
  
  class Motorcycle extends Vehicle {
    constructor(make, model) {
      super(make, model);
    }
  
    startEngine() {
      console.log(`Starting the motorcycle's engine`);
      super.startEngine();
    }
  }
  
  const car = new Car('Toyota', 'Camry', 4);
  const motorcycle = new Motorcycle('Harley-Davidson', 'Sportster');
  
  car.startEngine();
  motorcycle.startEngine();
  