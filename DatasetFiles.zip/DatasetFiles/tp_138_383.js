function PropertiesModal({
    slice,
    onHide,
    onSave,
    show,
    addSuccessToast,
  }: PropertiesModalProps)