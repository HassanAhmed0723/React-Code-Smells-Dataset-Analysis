class PolyfilledComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  static getDerivedStateFromProps() {
    return null;
  }

  render() {
    return null;
  }
}
