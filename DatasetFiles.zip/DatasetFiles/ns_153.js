export default function DrillDetailModal({
    chartId,
    formData,
    initialFilters,
    showModal,
    onHideModal,
  }: DrillDetailModalProps) {
    const theme = useTheme();
    const history = useHistory();
    const dashboardPageId = useContext(DashboardPageIdContext);
    const { slice_name: chartName } = useSelector(
      (state: { sliceEntities: { slices: Record<number, Slice> } }) =>
        state.sliceEntities.slices[chartId],
    );
  
    const exploreUrl = useMemo(
      () => `/explore/?dashboard_page_id=${dashboardPageId}&slice_id=${chartId}`,
      [chartId, dashboardPageId],
    );
  
    const exploreChart = useCallback(() => {
      history.push(exploreUrl);
    }, [exploreUrl, history]);
  
    return (
      <Modal
        show={showModal}
        onHide={onHideModal ?? (() => null)}
        css={css`
          .ant-modal-body {
            display: flex;
            flex-direction: column;
          }
        `}
        title={t('Drill to detail: %s', chartName)}
        footer={<ModalFooter exploreChart={exploreChart} />}
        responsive
        resizable
        resizableConfig={{
          minHeight: theme.gridUnit * 128,
          minWidth: theme.gridUnit * 128,
          defaultSize: {
            width: 'auto',
            height: '75vh',
          },
        }}
        draggable
        destroyOnClose
        maskClosable={false}
      >
        <DrillDetailPane formData={formData} initialFilters={initialFilters} />
      </Modal>
    );
  }
  