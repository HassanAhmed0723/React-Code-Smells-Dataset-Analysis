class Shape {
    constructor() {
        this.name = "Shape";
    }

    draw() {
        console.log(`Drawing a ${this.name}`);
    }
}

class Circle extends Shape {
    constructor() {
        super();
        this.name = "Circle";
    }
}

class Square extends Shape {
    constructor() {
        super();
        this.name = "Square";
    }
}

const circle = new Circle();
circle.draw();  // Output: Drawing a Circle

const square = new Square();
square.draw();  // Output: Drawing a Square
