class UIComponent extends React.Component {
    render() {
        return (
            <div>
                {this.renderHeader()}
                {this.renderContent()}
                {this.renderFooter()}
            </div>
        );
    }

    renderHeader() {
        return <h1>{this.props.title}</h1>;
    }

    renderContent() {
        return <p>{this.props.content}</p>;
    }

    renderFooter() {
        return <small>{this.props.footer}</small>;
    }
}

class HomePage extends UIComponent {
    renderHeader() {
        return <h1>Welcome to our website</h1>;
    }

    renderContent() {
        return <p>Explore our products and services.</p>;
    }

    renderFooter() {
        return <small>&copy; 2023 Our Company</small>;
    }
}

class AboutPage extends UIComponent {
    renderHeader() {
        return <h1>About Us</h1>;
    }

    renderContent() {
        return <p>Learn more about our history and mission.</p>;
    }

    renderFooter() {
        return <small>&copy; 2023 Our Company</small>;
    }
}

class App extends React.Component {
    render() {
        return (
            <div>
                <HomePage title="Home" content="Welcome content" footer="Home footer" />
                <AboutPage title="About" content="About content" footer="About footer" />
            </div>
        );
    }
}

ReactDOM.render(<App />, document.getElementById("root"));
