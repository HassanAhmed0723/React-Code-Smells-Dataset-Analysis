export default class Accordion extends React.PureComponent<Props, State> {
    constructor(props: Props) {
        super(props);

        this.state = {
            expandedKey: props.defaultExpandedKey,
        };
    }

    setExpanded = (expandedKey: string) => {
        this.setState({expandedKey});
    };

    render() {
        return (
            <div
                className={'Accordion'}
            >
                {this.props.children(this.setExpanded, this.state.expandedKey)}
            </div>
