export const Timeseries = ({ width, height }) => {
    const forecastEnabled = boolean('Enable forecast', true);
    const queryData = data
      .map(row =>
        forecastEnabled
          ? row
          : {
              // eslint-disable-next-line no-underscore-dangle
              __timestamp: row.__timestamp,
              Boston: row.Boston,
              California: row.California,
              WestTexNewMexico: row.WestTexNewMexico,
            },
      )
      .filter(row => forecastEnabled || !!row.Boston);
    return (
      <SuperChart
        chartType="echarts_area"
        width={width}
        height={height}
        queriesData={[{ data: queryData }]}
        formData={{
          area: true,
          contributionMode: undefined,
          forecastEnabled,
          colorScheme: 'supersetColors',
          seriesType: select(
            'Line type',
            ['line', 'scatter', 'smooth', 'bar', 'start', 'middle', 'end'],
            'line',
          ),
          show_extra_controls: boolean('Extra Controls', false),
          logAxis: boolean('Log axis', false),
          yAxisFormat: 'SMART_NUMBER',
          stack: boolean('Stack', false),
          showValue: boolean('Show Values', false),
          onlyTotal: boolean('Only Total', false),
          percentageThreshold: number('Percentage Threshold', 0),
          markerEnabled: boolean('Enable markers', false),
          markerSize: number('Marker Size', 6),
          minorSplitLine: boolean('Minor splitline', false),
          opacity: number('Opacity', 0.2),
          zoomable: boolean('Zoomable', false),
        }}
      />
    );
  };
  