class RoleStore extends Emitter<{
	change: { [_id: string]: IRole };
}> {
	roles: { [_id: string]: IRole } = {};
}