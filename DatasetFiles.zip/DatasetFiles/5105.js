class WizardBase extends React.Component {
    static Page = ({ children }) => children;
  
    constructor(props) {
      super(props);
      this.state = {
        values: props.initialValues,
      };
    }
  
    next = values => {
      const { location, history } = this.props;
      this.setState(() => ({ values }));
  
      // withRouter provides current location and history.push() to go to next page
      const nextPath = locations.indexOf(location.pathname) + 1;
      history.push(locations[nextPath]);
    };
  
    previous = () => {
      const { location, history } = this.props;
  
      const prevPath = locations.indexOf(location.pathname) - 1;
      history.push(locations[prevPath]);
    };
  
    validate = values => {
      const { location, children } = this.props;
  
      const page = locations.indexOf(location.pathname);
      const activePage = React.Children.toArray(children)[page];
      return activePage.props.validate ? activePage.props.validate(values) : {};
    };
  
    handleSubmit = (values, bag) => {
      const { children, onSubmit, location } = this.props;
      const page = locations.indexOf(location.pathname);
      const isLastPage = page === React.Children.count(children) - 1;
      if (isLastPage) {
        return onSubmit(values, bag);
      }
      // otherwise update values from page
      bag.setTouched({});
      bag.setSubmitting(false);
      this.next(values);
    };
  
    render() {
      const { children, location } = this.props;
      const { values } = this.state;
      // current page is determined by matching path in locations
      const page = locations.indexOf(location.pathname);
  
      const activePage = React.Children.toArray(children)[page];
      const isLastPage = page === React.Children.count(children) - 1;
      return (
        <Formik
          initialValues={values}
          enableReinitialize={false}
          validate={this.validate}
          onSubmit={this.handleSubmit}
          render={({ values, handleSubmit, isSubmitting, handleReset }) => (
            <form onSubmit={handleSubmit}>
              {activePage}
              <div className="buttons">
                {page > 0 && (
                  <button
                    type="button"
                    className="secondary"
                    onClick={this.previous}
                  >
                    « Previous
                  </button>
                )}
  
                {!isLastPage && <button type="submit">Next »</button>}
                {isLastPage && (
                  <button type="submit" disabled={isSubmitting}>
                    Submit
                  </button>
                )}
              </div>
  
              <Debug />
            </form>
          )}
        />
      );
    }
  }