export const ScopingModal = ({
    initialChartId,
    isVisible,
    closeModal,
  }: ScopingModalProps) 