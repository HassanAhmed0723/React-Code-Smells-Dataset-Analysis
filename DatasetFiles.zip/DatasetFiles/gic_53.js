export class LazyChartPlugin extends ChartPlugin<QueryFormData> {
    constructor() {
      super({
        metadata: new ChartMetadata({
          name: ChartKeys.LAZY,
          thumbnail: '',
        }),
        // this mirrors `() => import(module)` syntax
        loadChart: () => Promise.resolve({ default: TestComponent }),
        // promise without .default
        loadTransformProps: () => Promise.resolve(identity),
      });
    }
  }