const DatasourceModal: FunctionComponent<DatasourceModalProps> = ({
    addSuccessToast,
    datasource,
    onDatasourceSave,
    onHide,
    show,
  })