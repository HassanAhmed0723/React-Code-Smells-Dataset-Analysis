const PanelHeader = () => (
    <span data-test="collapsible-control-panel-header">
      <span
        css={(theme: SupersetTheme) => css`
          font-size: ${theme.typography.sizes.m}px;
          line-height: 1.3;
        `}
      >
        {label}
      </span>{' '}
      {description && (
        <Tooltip id={sectionId} title={description}>
          <Icons.InfoCircleOutlined css={iconStyles} />
        </Tooltip>
      )}
      {hasErrors && (
        <Tooltip
          id={`${kebabCase('validation-errors')}-tooltip`}
          title={t('This section contains validation errors')}
        >
          <Icons.InfoCircleOutlined
            css={css`
              ${iconStyles};
              color: ${errorColor};
            `}
          />
        </Tooltip>
      )}
    </span>
  );

  return (
    <Collapse.Panel
      css={theme => css`
        margin-bottom: 0;
        box-shadow: none;

        &:last-child {
          padding-bottom: ${theme.gridUnit * 16}px;
          border-bottom: 0;
        }

        .panel-body {
          margin-left: ${theme.gridUnit * 4}px;
          padding-bottom: 0;
        }

        span.label {
          display: inline-block;
        }
        ${!section.label &&
        `
          .ant-collapse-header {
            display: none;
          }
        `}
      `}
      header={<PanelHeader />}
      key={sectionId}
    >
      {section.controlSetRows.map((controlSets, i) => {
        const renderedControls = controlSets
          .map(controlItem => {
            if (!controlItem) {
              // When the item is invalid
              return null;
            }
            if (React.isValidElement(controlItem)) {
              // When the item is a React element
              return controlItem;
            }
            if (
              controlItem.name &&
              controlItem.config &&
              controlItem.name !== 'datasource'
            ) {
              return renderControl(controlItem);
            }
            return null;
          })
          .filter(x => x !== null);
        // don't show the row if it is empty
        if (renderedControls.length === 0) {
          return null;
        }
        return (
          <ControlRow
            key={`controlsetrow-${i}`}
            controls={renderedControls}
          />
        );
      })}
    </Collapse.Panel>
  );