export const lineInterpolation: CustomControlItem = {
    name: 'line_interpolation',
    config: {
      type: 'SelectControl',
      label: t('Line Style'),
      renderTrigger: true,
      choices: [
        ['linear', t('linear')],
        ['basis', t('basis')],
        ['cardinal', t('cardinal')],
        ['monotone', t('monotone')],
        ['step-before', t('step-before')],
        ['step-after', t('step-after')],
      ],
      default: 'linear',
      description: t('Line interpolation as defined by d3.js'),
    },
  };