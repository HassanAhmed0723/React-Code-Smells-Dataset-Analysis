const ChartContextMenu = (
    {
      id,
      formData,
      onSelection,
      onClose,
      displayedItems = ContextMenuItem.All,
      additionalConfig,
    }: ChartContextMenuProps,
    ref: RefObject<ChartContextMenuRef>,
  ) => {
    const theme = useTheme();
    const dispatch = useDispatch();
    const canExplore = useSelector((state: RootState) =>
      findPermission('can_explore', 'Superset', state.user?.roles),
    );
    const crossFiltersEnabled = useSelector<RootState, boolean>(
      ({ dashboardInfo }) => dashboardInfo.crossFiltersEnabled,
    );
  
    const isDisplayed = (item: ContextMenuItem) =>
      displayedItems === ContextMenuItem.All ||
      ensureIsArray(displayedItems).includes(item);
  
    const [{ filters, clientX, clientY }, setState] = useState<{
      clientX: number;
      clientY: number;
      filters?: ContextMenuFilters;
    }>({ clientX: 0, clientY: 0 });
  
    const menuItems = [];
  
    const showDrillToDetail =
      isFeatureEnabled(FeatureFlag.DRILL_TO_DETAIL) &&
      canExplore &&
      isDisplayed(ContextMenuItem.DrillToDetail);
  
    const showDrillBy =
      isFeatureEnabled(FeatureFlag.DRILL_BY) &&
      canExplore &&
      isDisplayed(ContextMenuItem.DrillBy);
  
    const showCrossFilters =
      isFeatureEnabled(FeatureFlag.DASHBOARD_CROSS_FILTERS) &&
      isDisplayed(ContextMenuItem.CrossFilter);
  
    const isCrossFilteringSupportedByChart = getChartMetadataRegistry()
      .get(formData.viz_type)
      ?.behaviors?.includes(Behavior.INTERACTIVE_CHART);
  
    let itemsCount = 0;
    if (showCrossFilters) {
      itemsCount += 1;
    }
    if (showDrillToDetail) {
      itemsCount += 2; // Drill to detail always has 2 top-level menu items
    }
    if (showDrillBy) {
      itemsCount += 1;
    }
    if (itemsCount === 0) {
      itemsCount = 1; // "No actions" appears if no actions in menu
    }
  
    if (showCrossFilters) {
      const isCrossFilterDisabled =
        !isCrossFilteringSupportedByChart ||
        !crossFiltersEnabled ||
        !filters?.crossFilter;
  
      let crossFilteringTooltipTitle: ReactNode = null;
      if (!isCrossFilterDisabled) {
        crossFilteringTooltipTitle = (
          <>
            <div>
              {t(
                'Cross-filter will be applied to all of the charts that use this dataset.',
              )}
            </div>
            <div>
              {t('You can also just click on the chart to apply cross-filter.')}
            </div>
          </>
        );
      } else if (!crossFiltersEnabled) {
        crossFilteringTooltipTitle = (
          <>
            <div>{t('Cross-filtering is not enabled for this dashboard.')}</div>
          </>
        );
      } else if (!isCrossFilteringSupportedByChart) {
        crossFilteringTooltipTitle = (
          <>
            <div>
              {t('This visualization type does not support cross-filtering.')}
            </div>
          </>
        );
      } else if (!filters?.crossFilter) {
        crossFilteringTooltipTitle = (
          <>
            <div>{t(`You can't apply cross-filter on this data point.`)}</div>
          </>
        );
      }
      menuItems.push(
        <>
          <Menu.Item
            key="cross-filtering-menu-item"
            disabled={isCrossFilterDisabled}
            onClick={() => {
              if (filters?.crossFilter) {
                dispatch(updateDataMask(id, filters.crossFilter.dataMask));
              }
            }}
          >
            {filters?.crossFilter?.isCurrentValueSelected ? (
              t('Remove cross-filter')
            ) : (
              <div>
                {t('Add cross-filter')}
                <MenuItemTooltip
                  title={crossFilteringTooltipTitle}
                  color={
                    !isCrossFilterDisabled
                      ? theme.colors.grayscale.base
                      : undefined
                  }
                />
              </div>
            )}
          </Menu.Item>
          {itemsCount > 1 && <Menu.Divider />}
        </>,
      );
    }
    if (showDrillToDetail) {
      menuItems.push(
        <DrillDetailMenuItems
          chartId={id}
          formData={formData}
          filters={filters?.drillToDetail}
          isContextMenu
          contextMenuY={clientY}
          onSelection={onSelection}
          submenuIndex={showCrossFilters ? 2 : 1}
          {...(additionalConfig?.drillToDetail || {})}
        />,
      );
    }
    if (showDrillBy) {
      let submenuIndex = 0;
      if (showCrossFilters) {
        submenuIndex += 1;
      }
      if (showDrillToDetail) {
        submenuIndex += 2;
      }
      menuItems.push(
        <DrillByMenuItems
          drillByConfig={filters?.drillBy}
          onSelection={onSelection}
          formData={formData}
          contextMenuY={clientY}
          submenuIndex={submenuIndex}
          {...(additionalConfig?.drillBy || {})}
        />,
      );
    }
  
    const open = useCallback(
      (clientX: number, clientY: number, filters?: ContextMenuFilters) => {
        const adjustedY = getMenuAdjustedY(clientY, itemsCount);
        setState({
          clientX,
          clientY: adjustedY,
          filters,
        });
  
        // Since Ant Design's Dropdown does not offer an imperative API
        // and we can't attach event triggers to charts SVG elements, we
        // use a hidden span that gets clicked on when receiving click events
        // from the charts.
        document.getElementById(`hidden-span-${id}`)?.click();
      },
      [id, itemsCount],
    );
  
    useImperativeHandle(
      ref,
      () => ({
        open,
      }),
      [open],
    );
  
    return ReactDOM.createPortal(
      <Dropdown
        overlay={
          <Menu className="chart-context-menu" data-test="chart-context-menu">
            {menuItems.length ? (
              menuItems
            ) : (
              <Menu.Item disabled>No actions</Menu.Item>
            )}
          </Menu>
        }
        trigger={['click']}
        onVisibleChange={value => !value && onClose()}
      >
        <span
          id={`hidden-span-${id}`}
          css={{
            visibility: 'hidden',
            position: 'fixed',
            top: clientY,
            left: clientX,
            width: 1,
            height: 1,
          }}
        />
      </Dropdown>,
      document.body,
    );
  };