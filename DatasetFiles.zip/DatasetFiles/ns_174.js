export const InteractiveDropdown = ({
    overlayType,
    ...rest
  }: DropdownProps & { overlayType: string }) => (
    <Dropdown
      {...rest}
      overlay={overlayType === 'custom' ? customOverlay : menu}
    />
  );