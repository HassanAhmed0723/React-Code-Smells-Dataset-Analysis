class CustomDashboardCloneModal extends React.Component<Props, State> {
    private isMounted = false;
  
    constructor(props: Props) {
      super(props);
  
      this.state = {
        newDashboardName: props.title,
        isTitleDuplicateConfirmed: false,
        hasTitleDuplicate: false,
        isLoading: false,
      };
    }
    
    componentDidMount() {
      this.isMounted = true;
    }
  
    componentWillUnmount() {
      this.isMounted = false;
    }
  
    onTitleDuplicate = () => {
      this.setState({
        isTitleDuplicateConfirmed: true,
        hasTitleDuplicate: true,
      });
    };
  
    cloneDashboard = async () => {
      this.setState({
        isLoading: true,
      });
  
      await this.props.onClone(
        this.state.newDashboardName,
        this.state.isTitleDuplicateConfirmed,
        this.onTitleDuplicate
      );
  
      if (this.isMounted) {
        this.setState({
          isLoading: false,
        });
      }
    };
  
    onInputChange = (event: any) => {
      this.setState({
        newDashboardName: event.target.value,
        isTitleDuplicateConfirmed: false,
        hasTitleDuplicate: false,
      });
    };
}
