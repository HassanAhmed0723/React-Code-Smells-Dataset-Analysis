export default function windowed<OptionType extends OptionTypeBase>(
    SelectComponent: ComponentType<SelectProps<OptionType>>,
  ): WindowedSelectComponentType<OptionType> {
    const WindowedSelect = forwardRef(
      (
        props: WindowedSelectProps<OptionType>,
        ref: React.RefObject<Select<OptionType>>,
      ) => {
        const { components: components_ = {}, ...restProps } = props;
        const components = { ...components_, MenuList };
        return (
          <SelectComponent components={components} ref={ref} {...restProps} />
        );
      },
    );
    return WindowedSelect;
  }