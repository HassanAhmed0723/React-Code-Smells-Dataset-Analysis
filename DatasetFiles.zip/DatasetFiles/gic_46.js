class Media {
    constructor(title) {
        this.title = title;
    }

    play() {
        console.log(`Playing ${this.title}`);
    }
}

class Song extends Media {
    constructor(title, artist) {
        super(title);
        this.artist = artist;
    }

    play() {
        console.log(`Playing song "${this.title}" by ${this.artist}`);
    }
}

class Movie extends Media {
    constructor(title, director) {
        super(title);
        this.director = director;
    }

    play() {
        console.log(`Playing movie "${this.title}" directed by ${this.director}`);
    }
}

const mySong = new Song("Bohemian Rhapsody", "Queen");
mySong.play(); // Output: Playing song "Bohemian Rhapsody" by Queen

const myMovie = new Movie("Inception", "Christopher Nolan");
myMovie.play(); // Output: Playing movie "Inception" directed by Christopher Nolan
