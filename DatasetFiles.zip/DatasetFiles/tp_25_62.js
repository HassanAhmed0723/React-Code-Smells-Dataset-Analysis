class MapBox extends React.Component {
    constructor(props) {
      super(props);
  
      const { width, height, bounds } = this.props;
      // Get a viewport that fits the given bounds, which all marks to be clustered.
      // Derive lat, lon and zoom from this viewport. This is only done on initial
      // render as the bounds don't update as we pan/zoom in the current design.
      const mercator = new ViewportMercator({
        width,
        height,
      }).fitBounds(bounds);
      const { latitude, longitude, zoom } = mercator;
  
      this.state = {
        viewport: {
          longitude,
          latitude,
          zoom,
        },
      };
      this.handleViewportChange = this.handleViewportChange.bind(this);
    }
  
    handleViewportChange(viewport) {
      this.setState({ viewport });
      const { onViewportChange } = this.props;
      onViewportChange(viewport);
    }
  
    render() {
      const {
        width,
        height,
        aggregatorName,
        clusterer,
        globalOpacity,
        mapStyle,
        mapboxApiKey,
        pointRadius,
        pointRadiusUnit,
        renderWhileDragging,
        rgb,
        hasCustomMetric,
        bounds,
      } = this.props;
      const { viewport } = this.state;
      const isDragging =
        viewport.isDragging === undefined ? false : viewport.isDragging;
  
      // Compute the clusters based on the original bounds and current zoom level. Note when zoom/pan
      // to an area outside of the original bounds, no additional queries are made to the backend to
      // retrieve additional data.
      // add this variable to widen the visible area
      const offsetHorizontal = (width * 0.5) / 100;
      const offsetVertical = (height * 0.5) / 100;
      const bbox = [
        bounds[0][0] - offsetHorizontal,
        bounds[0][1] - offsetVertical,
        bounds[1][0] + offsetHorizontal,
        bounds[1][1] + offsetVertical,
      ];
      const clusters = clusterer.getClusters(bbox, Math.round(viewport.zoom));
  
      return (
        <MapGL
          {...viewport}
          mapStyle={mapStyle}
          width={width}
          height={height}
          mapboxApiAccessToken={mapboxApiKey}
          onViewportChange={this.handleViewportChange}
          preserveDrawingBuffer
        >
          <ScatterPlotGlowOverlay
            {...viewport}
            isDragging={isDragging}
            locations={clusters}
            dotRadius={pointRadius}
            pointRadiusUnit={pointRadiusUnit}
            rgb={rgb}
            globalOpacity={globalOpacity}
            compositeOperation="screen"
            renderWhileDragging={renderWhileDragging}
            aggregation={hasCustomMetric ? aggregatorName : null}
            lngLatAccessor={location => {
              const { coordinates } = location.geometry;
  
              return [coordinates[0], coordinates[1]];
            }}
          />
        </MapGL>
      );
    }
  }
  