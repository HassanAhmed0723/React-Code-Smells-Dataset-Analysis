const TableView = ({
    columns,
    data,
    pageSize: initialPageSize,
    totalCount = data.length,
    initialPageIndex,
    initialSortBy = [],
    loading = false,
    withPagination = true,
    emptyWrapperType = EmptyWrapperType.Default,
    noDataText,
    showRowCount = true,
    serverPagination = false,
    columnsForWrapText,
    onServerPagination = () => {},
    scrollTopOnPagination = false,
    ...props
  }: TableViewProps)