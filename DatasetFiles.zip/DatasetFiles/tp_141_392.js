const AnnotationModal: FunctionComponent<AnnotationModalProps> = ({
    addDangerToast,
    addSuccessToast,
    annotationLayerId,
    annotation = null,
    onAnnotationAdd,
    onHide,
    show,
  })