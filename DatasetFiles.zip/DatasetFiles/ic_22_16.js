class AppLayoutSubscription extends Emitter<{ update: void }> {
	private descriptor: AppLayoutDescriptor = null;

	getSnapshot = (): AppLayoutDescriptor => this.descriptor;

	subscribe = (onStoreChange: () => void): (() => void) => this.on('update', onStoreChange);

	setCurrentValue(descriptor: AppLayoutDescriptor): void {
		this.descriptor = descriptor;
		this.emit('update');
	}

	render(element: ReactElement): void {
		this.setCurrentValue(
			<>
				<ConnectionStatusBar />
				<BannerRegion />
				{element}
				<PortalsWrapper />
				<ModalRegion />
			</>,
		);
	}

	renderStandalone(element: ReactElement): void {
		this.setCurrentValue(element);
	}
}