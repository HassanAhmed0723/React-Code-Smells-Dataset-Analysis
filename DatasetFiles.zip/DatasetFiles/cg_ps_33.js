export default class CustomModal extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      show: true,
      showBannerWarning: props.showBannerWarning,
    };
  }

  componentDidUpdate(prevProps) {
    if (this.props.showBannerWarning !== prevProps.showBannerWarning) {
      this.updateBannerWarning(this.props.showBannerWarning);
    }
  }

  doHide = () => {
    this.setState({ show: false });
  };

  updateBannerWarning = (showBannerWarning) => {
    this.setState({ showBannerWarning });
  };

  hideBannerWarning = () => {
    this.updateBannerWarning(false);
  };

  render() {
    const { showBannerWarning } = this.state;
    const { isCloud, currentUser } = this.props;

    return (
      <div className='custom-modal'>
        {/* Render your custom modal content */}
        {showBannerWarning && (
          <div className='banner-warning'>
            {/* Render the banner warning */}
          </div>
        )}
      </div>
    );
  }
}
