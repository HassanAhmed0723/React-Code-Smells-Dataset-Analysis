const initialState = {
  selectedItems: [],
  filteredAutoFollowPatterns: [],
};

export class AnotherComponent extends PureComponent {
  static propTypes = {
    autoFollowPatterns: PropTypes.array,
    selectAutoFollowPattern: PropTypes.func.isRequired,
    pauseAutoFollowPattern: PropTypes.func.isRequired,
    resumeAutoFollowPattern: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);

    this.state = {
      ...initialState,
      prevAutoFollowPatterns: props.autoFollowPatterns,
      queryText: '',
    };
  }

  static getDerivedStateFromProps(props, state) {
    const { autoFollowPatterns } = props;
    const { prevAutoFollowPatterns, queryText } = state;

    // If an auto-follow pattern gets deleted, we need to recreate the cached filtered auto-follow patterns.
    if (prevAutoFollowPatterns !== autoFollowPatterns) {
      return {
        prevAutoFollowPatterns: autoFollowPatterns,
        filteredAutoFollowPatterns: getFilteredPatterns(autoFollowPatterns, queryText),
      };
    }

    return null;
  }

  // ... Rest of the component's code
}
