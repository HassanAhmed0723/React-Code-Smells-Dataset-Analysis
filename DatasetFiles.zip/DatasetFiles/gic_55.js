export class BuggyChartPlugin extends ChartPlugin<QueryFormData> {
    constructor() {
      super({
        metadata: new ChartMetadata({
          name: ChartKeys.BUGGY,
          thumbnail: '',
        }),
        Chart: () => {
          throw new Error('The component is too buggy to render.');
        },
        transformProps: x => x,
      });
    }
  }