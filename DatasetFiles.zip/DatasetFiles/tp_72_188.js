export const AsynchronousSelect = ({
    fetchOnlyOnSearch,
    withError,
    withInitialValue,
    responseTime,
    ...rest
  }: AsyncSelectProps & {
    withError: boolean;
    withInitialValue: boolean;
    responseTime: number;
  })