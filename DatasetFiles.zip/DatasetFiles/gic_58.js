class MainPreset extends Preset {
    constructor() {
      super({
        name: 'Legacy charts',
        plugins: [
          new LineChartPlugin().configure({ key: 'line' }),
          new TableChartPlugin().configure({ key: 'table' }),
          new BigNumberTotalChartPlugin().configure({ key: 'big_number_total' }),
          new EchartsTimeseriesLineChartPlugin().configure({
            key: 'echarts_timeseries_line',
          }),
          new EchartsAreaChartPlugin().configure({
            key: 'echarts_area',
          }),
          new EchartsTimeseriesBarChartPlugin().configure({
            key: 'echarts_timeseries_bar',
          }),
          new EchartsPieChartPlugin().configure({ key: 'pie' }),
          new EchartsTimeseriesChartPlugin().configure({
            key: 'echarts_timeseries',
          }),
          new TimeTableChartPlugin().configure({ key: 'time_table' }),
          new EchartsMixedTimeseriesChartPlugin().configure({
            key: 'mixed_timeseries',
          }),
        ],
      });
    }
  }