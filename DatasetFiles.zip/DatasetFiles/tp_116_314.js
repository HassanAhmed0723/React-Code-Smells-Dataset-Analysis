const ColumnSelectPopover = ({
    columns,
    editedColumn,
    onChange,
    onClose,
    setDatasetModal,
    setLabel,
    getCurrentTab,
    label,
    isTemporal,
  }: ColumnSelectPopoverProps)