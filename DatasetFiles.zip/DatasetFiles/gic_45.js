class Furniture {
    constructor(material) {
        this.material = material;
    }

    describe() {
        console.log(`This furniture is made of ${this.material}.`);
    }
}

class Chair extends Furniture {
    constructor(material) {
        super(material);
    }

    sit() {
        console.log(`Sitting on the ${this.material} chair.`);
    }
}

class Table extends Furniture {
    constructor(material) {
        super(material);
    }

    placeItems() {
        console.log(`Placing items on the ${this.material} table.`);
    }
}

const woodenChair = new Chair("wood");
woodenChair.describe(); // Output: This furniture is made of wood.
woodenChair.sit();      // Output: Sitting on the wood chair.

const glassTable = new Table("glass");
glassTable.describe();  // Output: This furniture is made of glass.
glassTable.placeItems(); // Output: Placing items on the glass table.
