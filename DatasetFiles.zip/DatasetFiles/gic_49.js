class Widget extends React.Component {
    render() {
        return <div>{this.props.title}: {this.renderContent()}</div>;
    }

    renderContent() {
        return "Default content";
    }
}

class TodoListWidget extends Widget {
    renderContent() {
        return (
            <ul>
                <li>Task 1</li>
                <li>Task 2</li>
                <li>Task 3</li>
            </ul>
        );
    }
}

class NewsFeedWidget extends Widget {
    renderContent() {
        return (
            <div>
                <h2>Latest News</h2>
                <p>News article 1</p>
                <p>News article 2</p>
            </div>
        );
    }
}

class App extends React.Component {
    render() {
        return (
            <div>
                <Widget title="Generic Widget" />
                <TodoListWidget title="Todo List" />
                <NewsFeedWidget title="News Feed" />
            </div>
        );
    }
}

ReactDOM.render(<App />, document.getElementById("root"));
