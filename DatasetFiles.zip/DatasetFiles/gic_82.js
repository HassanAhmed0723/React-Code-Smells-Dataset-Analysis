class BaseScreenComponent {
    constructor() {
        this.state = {};
    }

    componentWillMount() {
        console.log("BaseScreenComponent will mount");
    }

    refreshData() {
        console.log("BaseScreenComponent refreshData");
    }

    toggleFeature() {
        console.log("BaseScreenComponent toggleFeature");
    }

    // ... other common methods ...
}

class LogScreenComponent extends BaseScreenComponent {
    constructor() {
        super();

        this.state = {
            logEntries: [],
            showErrorsOnly: false,
        };
        this.styles_ = {};
    }

    componentWillMount() {
        console.log("LogScreenComponent will mount");
        this.refreshData();
    }

    refreshData() {
        console.log("LogScreenComponent refreshData");
        // ... specific logic ...
    }

    toggleFeature() {
        console.log("LogScreenComponent toggleFeature");
        // ... specific logic ...
    }

    render() {
        const renderRow = ({ item }) => {
            // ... renderRow logic ...
        };

        return (
            <View>
                {/* ... rest of the JSX ... */}
                <FlatList
                    data={this.state.logEntries}
                    renderItem={renderRow}
                    keyExtractor={item => `${item.id}`}
                />
                <View style={{ flexDirection: 'row' }}>
                    <View style={{ flex: 1, marginRight: 5 }}>
                        <Button
                            title="Refresh"
                            onPress={() => {
                                this.refreshData();
                            }}
                        />
                    </View>
                    <View style={{ flex: 1 }}>
                        <Button
                            title={this.state.showErrorsOnly ? "Show all" : "Errors only"}
                            onPress={() => {
                                this.toggleFeature();
                            }}
                        />
                    </View>
                </View>
                {/* ... rest of the JSX ... */}
            </View>
        );
    }
}
