export class StackedWithNoChartLayout extends BigValueLayout {
    constructor(props: Props) {
      super(props);
  
      const { height } = props;
      const titleHeightPercent = 0.15;
      let titleHeight = 0;
  
      if (this.titleToAlignTo?.length) {
        this.titleFontSize = calculateFontSize(
          this.titleToAlignTo,
          this.maxTextWidth,
          height * titleHeightPercent,
          LINE_HEIGHT,
          MAX_TITLE_SIZE
        );
  
        titleHeight = this.titleFontSize * LINE_HEIGHT;
      }
  
      if (this.valueToAlignTo.length) {
        this.valueFontSize = calculateFontSize(
          this.valueToAlignTo,
          this.maxTextWidth,
          this.maxTextHeight - titleHeight,
          LINE_HEIGHT,
          undefined,
          VALUE_FONT_WEIGHT
        );
      }
  
      if (this.titleToAlignTo?.length) {
        // make title fontsize it's a bit smaller than valueFontSize
        this.titleFontSize = Math.min(this.valueFontSize * 0.7, this.titleFontSize);
      }
    }
  
    getValueAndTitleContainerStyles() {
      const styles = super.getValueAndTitleContainerStyles();
      styles.flexDirection = 'column';
      styles.flexGrow = 1;
      return styles;
    }
  
    renderChart(): JSX.Element | null {
      return null;
    }
  
    getPanelStyles() {
      const styles = super.getPanelStyles();
      styles.alignItems = 'center';
      return styles;
    }
  }