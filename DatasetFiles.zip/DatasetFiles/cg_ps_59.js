interface CustomComponentProps {
  initialValue: number;
}

interface CustomComponentState {
  value: number;
}

class CustomComponent extends Component<CustomComponentProps, CustomComponentState> {
  constructor(props: CustomComponentProps) {
    super(props);
    this.state = {
      value: props.initialValue,
    };
  }

  handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(event.target.value, 10);
    this.setState({ value: newValue });
  };

  render() {
    const { value } = this.state;

    return (
      <div>
        <input
          type="number"
          value={value}
          onChange={this.handleChange}
        />
        <p>Current value: {value}</p>
      </div>
    );
  }
}
