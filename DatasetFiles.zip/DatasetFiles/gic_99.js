class Vehicle {
    constructor(make, model) {
      this.make = make;
      this.model = model;
    }
  
    getInfo() {
      return `${this.make} ${this.model}`;
    }
  }
  
  class Car extends Vehicle {
    constructor(make, model, numDoors) {
      super(make, model);
      this.numDoors = numDoors;
    }
  
    getInfo() {
      return `${super.getInfo()}, ${this.numDoors} doors`;
    }
  
    start() {
      console.log(`${this.getInfo()} is starting.`);
    }
  }
  
  class Bicycle extends Vehicle {
    constructor(make, model, type) {
      super(make, model);
      this.type = type;
    }
  
    getInfo() {
      return `${super.getInfo()}, ${this.type} type`;
    }
  
    pedal() {
      console.log(`${this.getInfo()} is being pedaled.`);
    }
  }
  
  const car = new Car('Toyota', 'Camry', 4);
  const bicycle = new Bicycle('Trek', 'Mountain Bike', 'Mountain');
  
  console.log(car.getInfo());
  car.start();
  
  console.log(bicycle.getInfo());
  bicycle.pedal();
  