export default class TimeSeriesColumnControl extends React.Component {
    constructor(props) {
      super(props);
  
      this.onSave = this.onSave.bind(this);
      this.onClose = this.onClose.bind(this);
      this.resetState = this.resetState.bind(this);
      this.initialState = this.initialState.bind(this);
      this.onPopoverVisibleChange = this.onPopoverVisibleChange.bind(this);
  
      this.state = this.initialState();
    }
  
    initialState() {
      return {
        label: this.props.label,
        tooltip: this.props.tooltip,
        colType: this.props.colType,
        width: this.props.width,
        height: this.props.height,
        timeLag: this.props.timeLag || 0,
        timeRatio: this.props.timeRatio,
        comparisonType: this.props.comparisonType,
        showYAxis: this.props.showYAxis,
        yAxisBounds: this.props.yAxisBounds,
        bounds: this.props.bounds,
        d3format: this.props.d3format,
        dateFormat: this.props.dateFormat,
        popoverVisible: false,
      };
    }
  
    resetState() {
      const initialState = this.initialState();
      this.setState({ ...initialState });
    }
  
    onSave() {
      this.props.onChange(this.state);
      this.setState({ popoverVisible: false });
    }
  
    onClose() {
      this.resetState();
    }
  
    onSelectChange(attr, opt) {
      this.setState({ [attr]: opt });
    }
  
    onTextInputChange(attr, event) {
      this.setState({ [attr]: event.target.value });
    }
  
    onCheckboxChange(attr, value) {
      this.setState({ [attr]: value });
    }
  
    onBoundsChange(bounds) {
      this.setState({ bounds });
    }
  
    onPopoverVisibleChange(popoverVisible) {
      if (popoverVisible) {
        this.setState({ popoverVisible });
      } else {
        this.resetState();
      }
    }
  
    onYAxisBoundsChange(yAxisBounds) {
      this.setState({ yAxisBounds });
    }
  
    textSummary() {
      return `${this.props.label}`;
    }
  
    formRow(label, tooltip, ttLabel, control) {
      return (
        <StyledRow>
          <StyledCol xs={24} md={11}>
            {label}
            <StyledTooltip placement="top" tooltip={tooltip} label={ttLabel} />
          </StyledCol>
          <Col xs={24} md={13}>
            {control}
          </Col>
        </StyledRow>
      );
    }
  
    renderPopover() {
      return (
        <div id="ts-col-popo" style={{ width: 320 }}>
          {this.formRow(
            t('Label'),
            t('The column header label'),
            'time-lag',
            <Input
              value={this.state.label}
              onChange={this.onTextInputChange.bind(this, 'label')}
              placeholder={t('Label')}
            />,
          )}
          {this.formRow(
            t('Tooltip'),
            t('Column header tooltip'),
            'col-tooltip',
            <Input
              value={this.state.tooltip}
              onChange={this.onTextInputChange.bind(this, 'tooltip')}
              placeholder={t('Tooltip')}
            />,
          )}
          {this.formRow(
            t('Type'),
            t('Type of comparison, value difference or percentage'),
            'col-type',
            <Select
              ariaLabel={t('Type')}
              value={this.state.colType || undefined}
              onChange={this.onSelectChange.bind(this, 'colType')}
              options={colTypeOptions}
            />,
          )}
          <hr />
          {this.state.colType === 'spark' &&
            this.formRow(
              t('Width'),
              t('Width of the sparkline'),
              'spark-width',
              <Input
                value={this.state.width}
                onChange={this.onTextInputChange.bind(this, 'width')}
                placeholder={t('Width')}
              />,
            )}
          {this.state.colType === 'spark' &&
            this.formRow(
              t('Height'),
              t('Height of the sparkline'),
              'spark-width',
              <Input
                value={this.state.height}
                onChange={this.onTextInputChange.bind(this, 'height')}
                placeholder={t('Height')}
              />,
            )}
          {['time', 'avg'].indexOf(this.state.colType) >= 0 &&
            this.formRow(
              t('Time lag'),
              t('Number of periods to compare against'),
              'time-lag',
              <Input
                value={this.state.timeLag}
                onChange={this.onTextInputChange.bind(this, 'timeLag')}
                placeholder={t('Time Lag')}
              />,
            )}
          {['spark'].indexOf(this.state.colType) >= 0 &&
            this.formRow(
              t('Time ratio'),
              t('Number of periods to ratio against'),
              'time-ratio',
              <Input
                value={this.state.timeRatio}
                onChange={this.onTextInputChange.bind(this, 'timeRatio')}
                placeholder={t('Time Ratio')}
              />,
            )}
          {this.state.colType === 'time' &&
            this.formRow(
              t('Type'),
              t('Type of comparison, value difference or percentage'),
              'comp-type',
              <Select
                ariaLabel={t('Type')}
                value={this.state.comparisonType || undefined}
                onChange={this.onSelectChange.bind(this, 'comparisonType')}
                options={comparisonTypeOptions}
              />,
            )}
          {this.state.colType === 'spark' &&
            this.formRow(
              t('Show Y-axis'),
              t(
                'Show Y-axis on the sparkline. Will display the manually set min/max if set or min/max values in the data otherwise.',
              ),
              'show-y-axis-bounds',
              <CheckboxControl
                value={this.state.showYAxis}
                onChange={this.onCheckboxChange.bind(this, 'showYAxis')}
              />,
            )}
          {this.state.colType === 'spark' &&
            this.formRow(
              t('Y-axis bounds'),
              t('Manually set min/max values for the y-axis.'),
              'y-axis-bounds',
              <BoundsControl
                value={this.state.yAxisBounds}
                onChange={this.onYAxisBoundsChange.bind(this)}
              />,
            )}
          {this.state.colType !== 'spark' &&
            this.formRow(
              t('Color bounds'),
              t(`Number bounds used for color encoding from red to blue.
                 Reverse the numbers for blue to red. To get pure red or blue,
                 you can enter either only min or max.`),
              'bounds',
              <BoundsControl
                value={this.state.bounds}
                onChange={this.onBoundsChange.bind(this)}
              />,
            )}
          {this.formRow(
            t('Number format'),
            t('Optional d3 number format string'),
            'd3-format',
            <Input
              value={this.state.d3format}
              onChange={this.onTextInputChange.bind(this, 'd3format')}
              placeholder={t('Number format string')}
            />,
          )}
          {this.state.colType === 'spark' &&
            this.formRow(
              t('Date format'),
              t('Optional d3 date format string'),
              'date-format',
              <Input
                value={this.state.dateFormat}
                onChange={this.onTextInputChange.bind(this, 'dateFormat')}
                placeholder={t('Date format string')}
              />,
            )}
          <ButtonBar>
            <Button buttonSize="small" onClick={this.onClose} cta>
              {t('Close')}
            </Button>
            <Button
              buttonStyle="primary"
              buttonSize="small"
              onClick={this.onSave}
              cta
            >
              {t('Save')}
            </Button>
          </ButtonBar>
        </div>
      );
    }
  
    render() {
      return (
        <span>
          {this.textSummary()}{' '}
          <ControlPopover
            trigger="click"
            content={this.renderPopover()}
            title={t('Column Configuration')}
            visible={this.state.popoverVisible}
            onVisibleChange={this.onPopoverVisibleChange}
          >
            <InfoTooltipWithTrigger
              icon="edit"
              className="text-primary"
              label="edit-ts-column"
            />
          </ControlPopover>
        </span>
      );
    }
  }