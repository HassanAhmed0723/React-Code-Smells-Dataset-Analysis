function DefaultSearchInput({ count, value, onChange }: SearchInputProps) {
    return (
      <span className="dt-global-filter">
        Search{' '}
        <input
          className="form-control input-sm"
          placeholder={`${count} records...`}
          value={value}
          onChange={onChange}
        />
      </span>
    );
  }