class InputWidget extends BaseWidget<InputWidgetProps, WidgetState> {
    constructor(props: InputWidgetProps) {
      super(props);
      this.state = {
        text: props.text,
      };
    }
  
    static getAutocompleteDefinitions(): AutocompletionDefinitions {
      return {
        "!doc":
          "An input text field is used to capture a users textual input such as their names, numbers, emails etc. Inputs are used in forms and can have custom validations.",
        "!url": "https://docs.appsmith.com/widget-reference/input",
        text: {
          "!type": "string",
          "!doc": "The text value of the input",
          "!url": "https://docs.appsmith.com/widget-reference/input",
        },
        isValid: "bool",
        isVisible: DefaultAutocompleteDefinitions.isVisible,
        isDisabled: "bool",
        countryCode: {
          "!type": "string",
          "!doc": "Selected country code for Phone Number type input",
        },
        currencyCountryCode: {
          "!type": "string",
          "!doc": "Selected country code for Currency type input",
        },
      };
    }
  
    static getPropertyPaneConfig() {
      return [
        {
          sectionName: "General",
          children: [
            {
              helpText: "Changes the type of data captured in the input",
              propertyName: "inputType",
              label: "Data type",
              controlType: "DROP_DOWN",
              options: [
                {
                  label: "Text",
                  value: "TEXT",
                },
                {
                  label: "Number",
                  value: "NUMBER",
                },
                {
                  label: "Password",
                  value: "PASSWORD",
                },
                {
                  label: "Email",
                  value: "EMAIL",
                },
                {
                  label: "Currency",
                  value: "CURRENCY",
                },
                {
                  label: "Phone Number",
                  value: "PHONE_NUMBER",
                },
              ],
              isBindProperty: false,
              isTriggerProperty: false,
            },
            {
              propertyName: "allowCurrencyChange",
              label: "Allow currency change",
              helpText: "Search by currency or country",
              controlType: "SWITCH",
              isJSConvertible: false,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
              hidden: (props: InputWidgetProps) => {
                return props.inputType !== InputTypes.CURRENCY;
              },
              dependencies: ["inputType"],
            },
            {
              helpText: "Changes the country code",
              propertyName: "phoneNumberCountryCode",
              label: "Default country code",
              enableSearch: true,
              dropdownHeight: "195px",
              controlType: "DROP_DOWN",
              searchPlaceholderText: "Search by code or country name",
              options: ISDCodeDropdownOptions,
              hidden: (props: InputWidgetProps) => {
                return props.inputType !== InputTypes.PHONE_NUMBER;
              },
              dependencies: ["inputType"],
              isBindProperty: false,
              isTriggerProperty: false,
            },
            {
              helpText: "Changes the type of currency",
              propertyName: "currencyCountryCode",
              label: "Currency",
              enableSearch: true,
              dropdownHeight: "195px",
              controlType: "DROP_DOWN",
              searchPlaceholderText: "Search by code or name",
              options: CurrencyDropdownOptions,
              hidden: (props: InputWidgetProps) => {
                return props.inputType !== InputTypes.CURRENCY;
              },
              dependencies: ["inputType"],
              isBindProperty: false,
              isTriggerProperty: false,
            },
            {
              helpText: "No. of decimals in currency input",
              propertyName: "decimalsInCurrency",
              label: "Decimals",
              controlType: "DROP_DOWN",
              options: [
                {
                  label: "1",
                  value: 1,
                },
                {
                  label: "2",
                  value: 2,
                },
              ],
              hidden: (props: InputWidgetProps) => {
                return props.inputType !== InputTypes.CURRENCY;
              },
              dependencies: ["inputType"],
              isBindProperty: false,
              isTriggerProperty: false,
            },
            {
              helpText: "Sets maximum allowed text length",
              propertyName: "maxChars",
              label: "Max Chars",
              controlType: "INPUT_TEXT",
              placeholderText: "255",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.NUMBER },
              hidden: (props: InputWidgetProps) => {
                return !checkInputTypeTextByProps(props);
              },
              dependencies: ["inputType"],
            },
            {
              helpText:
                "Sets the default text of the widget. The text is updated if the default text changes",
              propertyName: "defaultText",
              label: "Default Text",
              controlType: "INPUT_TEXT",
              placeholderText: "John Doe",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: {
                type: ValidationTypes.FUNCTION,
                params: {
                  fn: defaultValueValidation,
                  expected: {
                    type: "string or number",
                    example: `John | 123`,
                    autocompleteDataType: AutocompleteDataType.STRING,
                  },
                },
              },
              dependencies: ["inputType"],
            },
            {
              helpText:
                "Adds a validation to the input which displays an error on failure",
              propertyName: "regex",
              label: "Regex",
              controlType: "INPUT_TEXT",
              placeholderText: "^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$",
              inputType: "TEXT",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.REGEX },
            },
            {
              helpText: "Sets the input validity based on a JS expression",
              propertyName: "validation",
              label: "Valid",
              controlType: "INPUT_TEXT",
              placeholderText: "{{ Input1.text.length > 0 }}",
              inputType: "TEXT",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              helpText:
                "The error message to display if the regex or valid property check fails",
              propertyName: "errorMessage",
              label: "Error message",
              controlType: "INPUT_TEXT",
              placeholderText: "Not a valid email!",
              inputType: "TEXT",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              helpText: "Sets a placeholder text for the input",
              propertyName: "placeholderText",
              label: "Placeholder",
              controlType: "INPUT_TEXT",
              placeholderText: "Placeholder",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              helpText: "Show help text or details about current input",
              propertyName: "tooltip",
              label: "Tooltip",
              controlType: "INPUT_TEXT",
              placeholderText: "Passwords must be atleast 6 chars",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              propertyName: "isRequired",
              label: "Required",
              helpText: "Makes input to the widget mandatory",
              controlType: "SWITCH",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              helpText: "Controls the visibility of the widget",
              propertyName: "isVisible",
              label: "Visible",
              controlType: "SWITCH",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              helpText: "Disables input to this widget",
              propertyName: "isDisabled",
              label: "Disabled",
              controlType: "SWITCH",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              propertyName: "animateLoading",
              label: "Animate loading",
              controlType: "SWITCH",
              helpText: "Controls the loading of the widget",
              defaultValue: true,
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              helpText: "Clears the input value after submit",
              propertyName: "resetOnSubmit",
              label: "Reset on submit",
              controlType: "SWITCH",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              helpText: "Focus input automatically on load",
              propertyName: "autoFocus",
              label: "Auto focus",
              controlType: "SWITCH",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
            },
            {
              propertyName: "isSpellCheck",
              label: "Spellcheck",
              helpText:
                "Defines whether the text input may be checked for spelling errors",
              controlType: "SWITCH",
              isJSConvertible: false,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.BOOLEAN },
              hidden: (props: InputWidgetProps) => {
                return !checkInputTypeTextByProps(props);
              },
              dependencies: ["inputType"],
            },
          ],
        },
        {
          sectionName: "Label",
          children: [
            {
              helpText: "Sets the label text of the widget",
              propertyName: "label",
              label: "Text",
              controlType: "INPUT_TEXT",
              placeholderText: "Name:",
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              helpText: "Sets the label position of the widget",
              propertyName: "labelPosition",
              label: "Position",
              controlType: "DROP_DOWN",
              options: [
                { label: "Left", value: LabelPosition.Left },
                { label: "Top", value: LabelPosition.Top },
                { label: "Auto", value: LabelPosition.Auto },
              ],
              defaultValue: LabelPosition.Top,
              isBindProperty: false,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              helpText: "Sets the label alignment of the widget",
              propertyName: "labelAlignment",
              label: "Alignment",
              controlType: "LABEL_ALIGNMENT_OPTIONS",
              fullWidth: false,
              options: [
                {
                  startIcon: "align-left",
                  value: Alignment.LEFT,
                },
                {
                  startIcon: "align-right",
                  value: Alignment.RIGHT,
                },
              ],
              isBindProperty: false,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
              hidden: (props: InputWidgetProps) =>
                props.labelPosition !== LabelPosition.Left,
              dependencies: ["labelPosition"],
            },
            {
              helpText:
                "Sets the label width of the widget as the number of columns",
              propertyName: "labelWidth",
              label: "Width (in columns)",
              controlType: "NUMERIC_INPUT",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              min: 0,
              validation: {
                type: ValidationTypes.NUMBER,
                params: {
                  natural: true,
                },
              },
              hidden: (props: InputWidgetProps) =>
                props.labelPosition !== LabelPosition.Left,
              dependencies: ["labelPosition"],
            },
          ],
        },
        {
          sectionName: "Events",
          children: [
            {
              helpText: "when the text is changed",
              propertyName: "onTextChanged",
              label: "onTextChanged",
              controlType: "ACTION_SELECTOR",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: true,
            },
            {
              helpText: "on submit (when the enter key is pressed)",
              propertyName: "onSubmit",
              label: "onSubmit",
              controlType: "ACTION_SELECTOR",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: true,
            },
          ],
        },
        {
          sectionName: "Label styles",
          children: [
            {
              propertyName: "labelTextColor",
              label: "Text color",
              controlType: "COLOR_PICKER",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: {
                type: ValidationTypes.TEXT,
                params: {
                  regex: /^(?![<|{{]).+/,
                },
              },
            },
            {
              propertyName: "labelTextSize",
              label: "Text size",
              controlType: "DROP_DOWN",
              defaultValue: "0.875rem",
              options: [
                {
                  label: "S",
                  value: "0.875rem",
                  subText: "0.875rem",
                },
                {
                  label: "M",
                  value: "1rem",
                  subText: "1rem",
                },
                {
                  label: "L",
                  value: "1.25rem",
                  subText: "1.25rem",
                },
                {
                  label: "XL",
                  value: "1.875rem",
                  subText: "1.875rem",
                },
                {
                  label: "XXL",
                  value: "3rem",
                  subText: "3rem",
                },
                {
                  label: "3XL",
                  value: "3.75rem",
                  subText: "3.75rem",
                },
              ],
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              propertyName: "labelStyle",
              label: "Label Font Style",
              controlType: "BUTTON_GROUP",
              options: [
                {
                  startIcon: "text-bold",
                  value: "BOLD",
                },
                {
                  startIcon: "text-italic",
                  value: "ITALIC",
                },
              ],
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
          ],
        },
        {
          sectionName: "Icon Options",
          hidden: (props: InputWidgetProps) => {
            const { inputType } = props;
            return inputType === "CURRENCY" || inputType === "PHONE_NUMBER";
          },
          dependencies: ["inputType"],
          children: [
            {
              propertyName: "iconName",
              label: "Icon",
              helpText: "Sets the icon to be used in input field",
              controlType: "ICON_SELECT",
              isBindProperty: false,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
            {
              propertyName: "iconAlign",
              label: "Icon alignment",
              helpText: "Sets the icon alignment of input field",
              controlType: "ICON_TABS",
              defaultValue: "left",
              options: [
                {
                  startIcon: "align-left",
                  value: "left",
                },
                {
                  startIcon: "align-right",
                  value: "right",
                },
              ],
              isBindProperty: false,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
              hidden: (props: InputWidgetProps) => !props.iconName,
              dependencies: ["iconName"],
            },
          ],
        },
        {
          sectionName: "Styles",
          children: [
            {
              propertyName: "backgroundColor",
              helpText: "Sets the background color of the widget",
              label: "Background color",
              controlType: "COLOR_PICKER",
              isJSConvertible: true,
              isBindProperty: true,
              isTriggerProperty: false,
              validation: { type: ValidationTypes.TEXT },
            },
          ],
        },
      ];
    }
  
    static getDerivedPropertiesMap(): DerivedPropertiesMap {
      return {
        isValid: `{{
          (function(){
            if (!this.isRequired && !this.text) {
              return true
            }
            if(this.isRequired && !this.text){
              return false
            }
            if (typeof this.validation === "boolean" && !this.validation) {
              return false;
            }
            let parsedRegex = null;
            if (this.regex) {
              /*
              * break up the regexp pattern into 4 parts: given regex, regex prefix , regex pattern, regex flags
              * Example /test/i will be split into ["/test/gi", "/", "test", "gi"]
              */
              const regexParts = this.regex.match(/(\\/?)(.+)\\1([a-z]*)/i);
  
              if (!regexParts) {
                parsedRegex = new RegExp(this.regex);
              } else {
                /*
                * if we don't have a regex flags (gmisuy), convert provided string into regexp directly
                /*
                if (regexParts[3] && !/^(?!.*?(.).*?\\1)[gmisuy]+$/.test(regexParts[3])) {
                  parsedRegex = RegExp(this.regex);
                }
                /*
                * if we have a regex flags, use it to form regexp
                */
                parsedRegex = new RegExp(regexParts[2], regexParts[3]);
              }
            }
            if (this.inputType === "EMAIL") {
              const emailRegex = new RegExp(/^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$/);
              return emailRegex.test(this.text);
            }
            else if (
              this.inputType === "NUMBER" ||
              this.inputType === "INTEGER" ||
              this.inputType === "CURRENCY" ||
              this.inputType === "PHONE_NUMBER"
            ) {
              let value = this.text.split(",").join("");
              if (parsedRegex) {
                return parsedRegex.test(value);
              }
              if (this.isRequired) {
                return !(value === '' || isNaN(value));
              }
  
              return (value === '' || !isNaN(value || ''));
            }
            else if (this.isRequired) {
              if(this.text && this.text.length) {
                if (parsedRegex) {
                  return parsedRegex.test(this.text)
                } else {
                  return true;
                }
              } else {
                return false;
              }
            }
            if (parsedRegex) {
              return parsedRegex.test(this.text)
            } else {
              return true;
            }
          })()
        }}`,
        value: `{{this.text}}`,
      };
    }
  
    static getDefaultPropertiesMap(): Record<string, string> {
      return {
        text: "defaultText",
      };
    }
  
    static getMetaPropertiesMap(): Record<string, any> {
      return {
        text: undefined,
        isFocused: false,
        isDirty: false,
        selectedCurrencyType: undefined,
        selectedCountryCode: undefined,
      };
    }
  
    static getStylesheetConfig(): Stylesheet {
      return {
        accentColor: "{{appsmith.theme.colors.primaryColor}}",
        borderRadius: "{{appsmith.theme.borderRadius.appBorderRadius}}",
        boxShadow: "none",
      };
    }
  
    onValueChange = (value: string) => {
      this.props.updateWidgetMetaProperty("text", value, {
        triggerPropertyName: "onTextChanged",
        dynamicString: this.props.onTextChanged,
        event: {
          type: EventType.ON_TEXT_CHANGE,
        },
      });
      if (!this.props.isDirty) {
        this.props.updateWidgetMetaProperty("isDirty", true);
      }
    };
  
    onCurrencyTypeChange = (code?: string) => {
      const currencyCountryCode = code;
      if (this.props.renderMode === RenderModes.CANVAS) {
        super.updateWidgetProperty("currencyCountryCode", currencyCountryCode);
      } else {
        this.props.updateWidgetMetaProperty(
          "selectedCurrencyCountryCode",
          currencyCountryCode,
        );
      }
    };
  
    onISDCodeChange = (code?: string) => {
      const countryCode = code;
      if (this.props.renderMode === RenderModes.CANVAS) {
        super.updateWidgetProperty("phoneNumberCountryCode", countryCode);
      } else {
        this.props.updateWidgetMetaProperty(
          "selectedPhoneNumberCountryCode",
          countryCode,
        );
      }
    };
  
    handleFocusChange = (focusState: boolean) => {
      /**
       * Reason for disabling drag on focusState: true:
       * 1. In Firefox, draggable="true" property on the parent element
       *    or <input /> itself, interferes with some <input /> element's events
       *    Bug Ref - https://bugzilla.mozilla.org/show_bug.cgi?id=800050
       *              https://bugzilla.mozilla.org/show_bug.cgi?id=1189486
       *
       *  Eg - input with draggable="true", double clicking the text; won't highlight the text
       *
       * 2. Dragging across the text (for text selection) in input won't cause the widget to drag.
       */
      this.props.updateWidgetMetaProperty("dragDisabled", focusState);
      this.props.updateWidgetMetaProperty("isFocused", focusState);
    };
  
    onSubmitSuccess = (result: ExecutionResult) => {
      if (result.success && this.props.resetOnSubmit) {
        this.props.updateWidgetMetaProperty("text", "", {
          triggerPropertyName: "onSubmit",
          dynamicString: this.props.onTextChanged,
          event: {
            type: EventType.ON_TEXT_CHANGE,
          },
        });
      }
    };
  
    handleKeyDown = (
      e:
        | React.KeyboardEvent<HTMLTextAreaElement>
        | React.KeyboardEvent<HTMLInputElement>,
    ) => {
      const { isValid, onSubmit } = this.props;
      const isEnterKey = e.key === "Enter" || e.keyCode === 13;
      if (isEnterKey && onSubmit && isValid) {
        super.executeAction({
          triggerPropertyName: "onSubmit",
          dynamicString: onSubmit,
          event: {
            type: EventType.ON_SUBMIT,
            callback: this.onSubmitSuccess,
          },
        });
      }
    };
  
    getFormattedText = () => {
      if (this.props.isFocused || this.props.inputType !== InputTypes.CURRENCY) {
        return this.props.text !== undefined ? this.props.text : "";
      }
      if (this.props.text === "" || this.props.text === undefined) return "";
      const valueToFormat = String(this.props.text);
  
      const locale = getLocale();
      const decimalSeparator = getDecimalSeparator(locale);
      return formatCurrencyNumber(
        this.props.decimalsInCurrency,
        valueToFormat,
        decimalSeparator,
      );
    };
  
    getPageView() {
      const value = this.getFormattedText();
      let isInvalid =
        "isValid" in this.props && !this.props.isValid && !!this.props.isDirty;
      const currencyCountryCode = this.props.selectedCurrencyCountryCode
        ? this.props.selectedCurrencyCountryCode
        : this.props.currencyCountryCode;
      const phoneNumberCountryCode = this.props.selectedPhoneNumberCountryCode
        ? this.props.selectedPhoneNumberCountryCode
        : this.props.phoneNumberCountryCode;
      const conditionalProps: Partial<InputComponentProps> = {};
      conditionalProps.errorMessage = this.props.errorMessage;
      if (this.props.isRequired && value.length === 0) {
        conditionalProps.errorMessage = createMessage(FIELD_REQUIRED_ERROR);
      }
      if (this.props.inputType === "TEXT" && this.props.maxChars) {
        // pass maxChars only for Text type inputs, undefined for other types
        conditionalProps.maxChars = this.props.maxChars;
        if (
          this.props.defaultText &&
          this.props.defaultText.toString().length > this.props.maxChars
        ) {
          isInvalid = true;
          conditionalProps.errorMessage = createMessage(
            INPUT_DEFAULT_TEXT_MAX_CHAR_ERROR,
            this.props.maxChars,
          );
        }
      }
      if (this.props.maxNum) conditionalProps.maxNum = this.props.maxNum;
      if (this.props.minNum) conditionalProps.minNum = this.props.minNum;
      const minInputSingleLineHeight =
        this.props.label || this.props.tooltip
          ? // adjust height for label | tooltip extra div
            GRID_DENSITY_MIGRATION_V1 + 4
          : // GRID_DENSITY_MIGRATION_V1 used to adjust code as per new scaled canvas.
            GRID_DENSITY_MIGRATION_V1;
  
      return (
        <InputComponent
          accentColor={this.props.accentColor}
          allowCurrencyChange={this.props.allowCurrencyChange}
          autoFocus={this.props.autoFocus}
          backgroundColor={this.props.backgroundColor}
          borderRadius={this.props.borderRadius}
          boxShadow={this.props.boxShadow}
          // show label and Input side by side if true
          compactMode={
            !(
              (this.props.bottomRow - this.props.topRow) /
                GRID_DENSITY_MIGRATION_V1 >
              1
            )
          }
          currencyCountryCode={currencyCountryCode}
          decimalsInCurrency={this.props.decimalsInCurrency}
          defaultValue={this.props.defaultText}
          disableNewLineOnPressEnterKey={!!this.props.onSubmit}
          disabled={this.props.isDisabled}
          iconAlign={this.props.iconAlign}
          iconName={this.props.iconName}
          inputType={this.props.inputType}
          isInvalid={isInvalid}
          isLoading={this.props.isLoading}
          label={this.props.label}
          labelAlignment={this.props.labelAlignment}
          labelPosition={this.props.labelPosition}
          labelStyle={this.props.labelStyle}
          labelTextColor={this.props.labelTextColor}
          labelTextSize={this.props.labelTextSize}
          labelWidth={(this.props.labelWidth || 0) * this.props.parentColumnSpace}
          multiline={
            (this.props.bottomRow - this.props.topRow) /
              minInputSingleLineHeight >
              1 && this.props.inputType === "TEXT"
          }
          onCurrencyTypeChange={this.onCurrencyTypeChange}
          onFocusChange={this.handleFocusChange}
          onISDCodeChange={this.onISDCodeChange}
          onKeyDown={this.handleKeyDown}
          onValueChange={this.onValueChange}
          phoneNumberCountryCode={phoneNumberCountryCode}
          placeholder={this.props.placeholderText}
          showError={!!this.props.isFocused}
          spellCheck={!!this.props.isSpellCheck}
          stepSize={1}
          tooltip={this.props.tooltip}
          value={value}
          widgetId={this.props.widgetId}
          {...conditionalProps}
        />
      );
    }
  
    static getWidgetType(): WidgetType {
      return "INPUT_WIDGET";
    }
  }