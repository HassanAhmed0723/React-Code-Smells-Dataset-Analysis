const plugin = new ChartPlugin({
    metadata,
    Chart: FakeChart,
  });