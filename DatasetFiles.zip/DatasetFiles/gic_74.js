class BaseScreenComponent {
    constructor() {
        this.state = {};
    }

    componentWillMount() {
        console.log("BaseScreenComponent will mount");
    }

    isModified() {
        console.log("BaseScreenComponent isModified");
        return false;
    }

    saveButton_press() {
        console.log("BaseScreenComponent saveButton_press");
    }

    // ... other common methods ...
}

class FolderScreenComponent extends BaseScreenComponent {
    constructor() {
        super();
        this.state = {
            folder: Folder.new(),
            lastSavedFolder: null,
        };
    }

    componentWillMount() {
        console.log("FolderScreenComponent will mount");
        // ... specific logic ...
    }

    isModified() {
        console.log("FolderScreenComponent isModified");
        // ... specific logic ...
    }

    saveButton_press() {
        console.log("FolderScreenComponent saveButton_press");
        // ... specific logic ...
    }

    render() {
        const saveButtonDisabled = !this.isModified() || !this.state.folder.title;

        return (
            <View>
                {/* ... rest of the JSX ... */}
                <ScreenHeader
                    // ... props ...
                    onSaveButtonPress={() => this.saveButton_press()}
                />
                {/* ... rest of the JSX ... */}
            </View>
        );
    }
}
