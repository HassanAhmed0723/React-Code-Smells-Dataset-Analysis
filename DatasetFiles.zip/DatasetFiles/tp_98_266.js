const FiltersConfigForm = (
    {
      filterId,
      filterToEdit,
      removedFilters,
      form,
      getAvailableFilters,
      activeFilterPanelKeys,
      restoreFilter,
      handleActiveFilterPanelChange,
      setErroredFilters,
      validateDependencies,
      getDependencySuggestion,
      isActive,
    }: FiltersConfigFormProps,
    ref: React.RefObject<any>,
  )