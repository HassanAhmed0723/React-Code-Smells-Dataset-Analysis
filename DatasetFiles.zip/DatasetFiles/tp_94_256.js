const FilterControls: FC<FilterControlsProps> = ({
    dataMaskSelected,
    onFilterSelectionChange,
  })