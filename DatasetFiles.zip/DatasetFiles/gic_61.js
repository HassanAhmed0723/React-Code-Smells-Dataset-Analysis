class WideNoChartLayout extends BigValueLayout {
    constructor(props) {
        super(props);

        // ... additional constructor logic ...
    }

    getValueAndTitleContainerStyles() {
        const styles = super.getValueAndTitleContainerStyles();
        // ... additional styles modification ...
        return styles;
    }

    renderChart() {
        return null;
    }

    getPanelStyles() {
        const panelStyles = super.getPanelStyles();
        // ... additional panel styles modification ...
        return panelStyles;
    }

    render() {
        return (
            <div>
                {/* ... render content using inherited methods ... */}
            </div>
        );
    }
}
