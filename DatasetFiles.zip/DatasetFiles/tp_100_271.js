function FiltersConfigModal({
    isOpen,
    initialFilterId,
    createNewOnOpen,
    onSave,
    onCancel,
  }: FiltersConfigModalProps)