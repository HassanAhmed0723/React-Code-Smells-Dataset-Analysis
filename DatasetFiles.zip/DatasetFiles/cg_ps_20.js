class CustomComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: props.initialData,
      count: props.initialCount,
    };
  }

  render() {
    const { data, count } = this.state;

    return (
      <div>
        <h1>Data: {data}</h1>
        <h2>Count: {count}</h2>
      </div>
    );
  }
}
