export default class CustomPostView extends React.PureComponent {
  constructor(props) {
    super(props);
    const shouldStartFromBottomWhenUnread = this.props.unreadScrollPosition === Preferences.UNREAD_SCROLL_POSITION_START_FROM_NEWEST;
    this.state = {
      unreadChunkTimeStamp: props.lastViewedAt,
      shouldStartFromBottomWhenUnread,
      loaderForChangeOfPostsChunk: false,
      channelLoading: props.channelLoading,
    };
  }

  static getDerivedStateFromProps(props, state) {
    if (state.unreadChunkTimeStamp === null && props.lastViewedAt) {
      return {
        unreadChunkTimeStamp: props.lastViewedAt,
      };
    }
    if (props.channelLoading !== state.channelLoading) {
      return {
        unreadChunkTimeStamp: props.lastViewedAt,
        channelLoading: props.channelLoading,
      };
    }

    return null;
  }

  changeUnreadChunkTimeStamp = (unreadChunkTimeStamp) => {
    this.setState({
      unreadChunkTimeStamp,
      loaderForChangeOfPostsChunk: true,
    }, () => {
      window.requestAnimationFrame(() => {
        this.setState({
          loaderForChangeOfPostsChunk: false,
        });
      });
    });
  };

  toggleShouldStartFromBottomWhenUnread = () => {
    this.setState((state) => ({
      loaderForChangeOfPostsChunk: true,
      shouldStartFromBottomWhenUnread: !state.shouldStartFromBottomWhenUnread,
    }), () => {
      window.requestAnimationFrame(() => {
        this.setState({
          loaderForChangeOfPostsChunk: false,
        });
      });
    });
  };

  render() {
    if (this.state.channelLoading || this.state.loaderForChangeOfPostsChunk) {
      return (
        <div id='post-list'>
          <LoadingScreen centered={true} />
        </div>
      );
    }

    return (
      <div
        id='post-list'
        role='main'
      >
        <PostList
          unreadChunkTimeStamp={this.state.unreadChunkTimeStamp}
          channelId={this.props.channelId}
          changeUnreadChunkTimeStamp={this.changeUnreadChunkTimeStamp}
          shouldStartFromBottomWhenUnread={this.state.shouldStartFromBottomWhenUnread}
          toggleShouldStartFromBottomWhenUnread={this.toggleShouldStartFromBottomWhenUnread}
          focusedPostId={this.props.focusedPostId}
        />
      </div>
    );
  }
}
