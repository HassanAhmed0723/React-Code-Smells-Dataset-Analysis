class SampleTable extends Component {
  static propTypes = {
    data: PropTypes.array,
    fetchData: PropTypes.func.isRequired,
  };

  static defaultProps = {
    data: [],
  };

  static getDerivedStateFromProps(props, state) {
    const { data } = props;
    const { prevData, queryText } = state;

    // If the data changes, update the filtered data.
    if (prevData !== data) {
      return {
        prevData: data,
        filteredData: getFilteredData(data, queryText),
      };
    }

    return null;
  }

  constructor(props) {
    super(props);

    this.state = {
      prevData: props.data,
      selectedItems: [],
      filteredData: props.data,
      queryText: '',
    };
  }

  onSearch = ({ query }) => {
    // There's no need to update the state if there are no search params
    if (!query) {
      return;
    }

    const { data } = this.props;
    const { text } = query;

    // Cache the filtered data to avoid recalculating during render.
    this.setState({
      queryText: text,
      filteredData: getFilteredData(data, text),
    });
  };

  render() {
    const { selectedItems, filteredData } = this.state;
    const columns = [
      // Define your columns here...
    ];

    const sorting = {
      // Define your sorting options here...
    };

    const search = {
      // Define your search options here...
    };

    const pagination = {
      // Define your pagination options here...
    };

    const selection = {
      // Define your selection options here...
    };

    return (
      <EuiInMemoryTable
        items={filteredData}
        itemId="id"
        columns={columns}
        search={search}
        pagination={pagination}
        sorting={sorting}
        selection={selection}
        isSelectable={true}
        data-test-subj="sampleDataTable"
      />
    );
  }
}
