class ExampleComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: props.data,
      loading: true,
    };
  }

  static getDerivedStateFromProps(props) {
    const { data } = props;
    return {
      data,
      loading: true,
    };
  }

  componentDidMount() {
    // Simulate API call or some asynchronous operation
    setTimeout(() => {
      // Update the state to indicate that the loading is complete
      this.setState({ loading: false });
    }, 2000);
  }

  render() {
    const { data, loading } = this.state;

    return (
      <div>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <ul>
            {data.map((item) => (
              <li key={item.id}>{item.name}</li>
            ))}
          </ul>
        )}
      </div>
    );
  }
}

ExampleComponent.propTypes = {
  data: PropTypes.array.isRequired,
};

ExampleComponent.defaultProps = {
  data: [],
};
