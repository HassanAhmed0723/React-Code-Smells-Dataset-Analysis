class BaseScreenComponent {
    constructor() {
        this.styles_ = {};

        this.shared_ = new Shared(this);
    }

    componentWillMount() {
        this.shared_.refreshUrl();
    }

    styles() {
        // ... same implementation ...
    }
}

class DropboxLoginScreenComponent extends BaseScreenComponent {
    constructor() {
        super();
    }

    render() {
        const theme = themeStyle(this.props.themeId);

        return (
            <View style={this.styles().screen}>
                <ScreenHeader title={_('Login with Dropbox')} />

                <ScrollView style={this.styles().container}>
                    {/* ... rest of the JSX ... */}
                </ScrollView>

                <DialogBox
                    ref={dialogbox => {
                        this.dialogbox = dialogbox;
                    }}
                />
            </View>
        );
    }
}
