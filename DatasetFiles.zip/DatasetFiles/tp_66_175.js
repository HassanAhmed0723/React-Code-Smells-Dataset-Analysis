export default function Label(props: LabelProps) {
    const theme = useTheme();
    const { colors, transitionTiming } = theme;
    const { type = 'default', onClick, children, ...rest } = props;
    const {
      alert,
      primary,
      secondary,
      grayscale,
      success,
      warning,
      error,
      info,
    } = colors;
  
    let backgroundColor = grayscale.light3;
    let backgroundColorHover = onClick ? primary.light2 : grayscale.light3;
    let borderColor = onClick ? grayscale.light2 : 'transparent';
    let borderColorHover = onClick ? primary.light1 : 'transparent';
    let color = grayscale.dark1;
  
    if (type !== 'default') {
      color = grayscale.light4;
  
      let baseColor;
      if (type === 'alert') {
        color = grayscale.dark1;
        baseColor = alert;
      } else if (type === 'success') {
        baseColor = success;
      } else if (type === 'warning') {
        baseColor = warning;
      } else if (type === 'danger') {
        baseColor = error;
      } else if (type === 'info') {
        baseColor = info;
      } else if (type === 'secondary') {
        baseColor = secondary;
      } else {
        baseColor = primary;
      }
  
      backgroundColor = baseColor.base;
      backgroundColorHover = onClick ? baseColor.dark1 : baseColor.base;
      borderColor = onClick ? baseColor.dark1 : 'transparent';
      borderColorHover = onClick ? baseColor.dark2 : 'transparent';
    }
  
    return (
      <Tag
        onClick={onClick}
        {...rest}
        css={{
          transition: `background-color ${transitionTiming}s`,
          whiteSpace: 'nowrap',
          cursor: onClick ? 'pointer' : 'default',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          backgroundColor,
          borderColor,
          borderRadius: 21,
          padding: '0.35em 0.8em',
          lineHeight: 1,
          color,
          maxWidth: '100%',
          '&:hover': {
            backgroundColor: backgroundColorHover,
            borderColor: borderColorHover,
            opacity: 1,
          },
        }}
      >
        {children}
      </Tag>
    );
  }
  