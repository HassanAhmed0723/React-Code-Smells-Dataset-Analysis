export default class CustomInput extends React.PureComponent {
  constructor(props) {
    super(props);

    this.inputRef = React.createRef();

    this.state = {
      value: props.value,
    };
  }

  static getDerivedStateFromProps(props, state) {
    if (props.value !== state.value) {
      return {
        value: props.value,
      };
    }

    return null;
  }

  handleChange = (event) => {
    const value = event.target.value;

    this.setState({ value });

    if (this.props.onChange) {
      this.props.onChange(value);
    }
  };

  render() {
    const { id, isDisabled } = this.props;
    const { value } = this.state;

    return (
      <div className='custom-input'>
        <input
          id={`${id}-input`}
          ref={this.inputRef}
          className='form-control'
          type='text'
          value={value}
          onChange={this.handleChange}
          disabled={isDisabled}
        />
      </div>
    );
  }
}
