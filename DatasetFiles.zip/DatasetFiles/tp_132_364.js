class TextAreaControl extends React.Component {
    onControlChange(event) {
      const { value } = event.target;
      this.props.onChange(value);
    }
  
    onAreaEditorChange(value) {
      this.props.onChange(value);
    }
  
    renderEditor(inModal = false) {
      const minLines = inModal ? 40 : this.props.minLines || 12;
      if (this.props.language) {
        const style = {
          border: `1px solid ${this.props.theme.colors.grayscale.light1}`,
          minHeight: `${minLines}em`,
          width: 'auto',
          ...this.props.textAreaStyles,
        };
        if (this.props.resize) {
          style.resize = this.props.resize;
        }
        if (this.props.readOnly) {
          style.backgroundColor = '#f2f2f2';
        }
  
        return (
          <TextAreaEditor
            mode={this.props.language}
            style={style}
            minLines={minLines}
            maxLines={inModal ? 1000 : this.props.maxLines}
            editorProps={{ $blockScrolling: true }}
            defaultValue={this.props.initialValue}
            readOnly={this.props.readOnly}
            key={this.props.name}
            {...this.props}
            onChange={this.onAreaEditorChange.bind(this)}
          />
        );
      }
      return (
        <TextArea
          placeholder={t('textarea')}
          onChange={this.onControlChange.bind(this)}
          defaultValue={this.props.initialValue}
          disabled={this.props.readOnly}
          style={{ height: this.props.height }}
        />
      );
    }
  
    renderModalBody() {
      return (
        <>
          <div>{this.props.aboveEditorSection}</div>
          {this.renderEditor(true)}
        </>
      );
    }
  
    render() {
      const controlHeader = <ControlHeader {...this.props} />;
      return (
        <div>
          {controlHeader}
          {this.renderEditor()}
          {this.props.offerEditInModal && (
            <ModalTrigger
              modalTitle={controlHeader}
              triggerNode={
                <Button buttonSize="small" className="m-t-5">
                  {t('Edit')} <strong>{this.props.language}</strong>{' '}
                  {t('in modal')}
                </Button>
              }
              modalBody={this.renderModalBody(true)}
              responsive
            />
          )}
        </div>
      );
    }
  }
  