class MainPreset extends Preset {
    constructor() {
      super({
        name: 'Legacy charts',
        plugins: [
          new TimeFilterPlugin().configure({ key: 'filter_time' }),
          new SelectFilterPlugin().configure({ key: 'filter_select' }),
        ],
      });
    }
  }