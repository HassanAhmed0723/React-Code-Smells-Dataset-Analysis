export default class TooltipTable extends PureComponent<Props, {}> {
    static defaultProps = defaultProps;
  
    render() {
      const { className, data } = this.props;
  
      return (
        <table className={className}>
          <tbody>
            {data.map(({ key, keyColumn, keyStyle, valueColumn, valueStyle }) => (
              <tr key={key}>
                <td style={keyStyle}>{keyColumn ?? key}</td>
                <td
                  style={
                    valueStyle
                      ? { ...VALUE_CELL_STYLE, ...valueStyle }
                      : VALUE_CELL_STYLE
                  }
                >
                  {valueColumn}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }
  }