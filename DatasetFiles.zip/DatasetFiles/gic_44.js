class Employee {
    constructor(name, role) {
        this.name = name;
        this.role = role;
    }

    introduce() {
        console.log(`Hi, I'm ${this.name} and I'm a ${this.role}.`);
    }

    work() {
        console.log(`${this.name} is working.`);
    }
}

class Manager extends Employee {
    constructor(name) {
        super(name, "Manager");
    }

    manage() {
        console.log(`${this.name} is managing employees.`);
    }
}

class Developer extends Employee {
    constructor(name) {
        super(name, "Developer");
    }

    code() {
        console.log(`${this.name} is writing code.`);
    }
}

const manager = new Manager("Alice");
manager.introduce(); // Output: Hi, I'm Alice and I'm a Manager.
manager.work();      // Output: Alice is working.
manager.manage();    // Output: Alice is managing employees.

const developer = new Developer("Bob");
developer.introduce(); // Output: Hi, I'm Bob and I'm a Developer.
developer.work();      // Output: Bob is working.
developer.code();      // Output: Bob is writing code.
