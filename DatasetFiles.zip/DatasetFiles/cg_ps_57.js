interface CustomSearchProps {
  onSearch: (value: any) => void;
  placeholder: string;
  value: string;
  className?: string;
  autoFocus?: boolean;
}

const SearchWrapper = styled.div`
  position: relative;
  width: 100%;
`;

const ClearIconWrapper = styled.div`
  width: 20px;
  height: 20px;
  position: absolute;
  cursor: pointer;
  top: 5px;
  right: 5px;
  .clear-icon {
    width: 10px;
    height: 10px;
    position: absolute;
    top: 5px;
    left: 5px;
  }
`;

const CustomSearchComponent: React.FC<CustomSearchProps> = ({
  onSearch,
  placeholder,
  value,
  className,
  autoFocus,
}) => {
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSearch(e.target.value);
  };

  const handleClearClick = () => {
    onSearch('');
  };

  return (
    <SearchWrapper className={className}>
      <input
        type="text"
        value={value}
        onChange={handleSearchChange}
        placeholder={placeholder}
        autoFocus={autoFocus}
      />
      {value && (
        <ClearIconWrapper onClick={handleClearClick}>
          <div className="clear-icon">X</div>
        </ClearIconWrapper>
      )}
    </SearchWrapper>
  );
};
