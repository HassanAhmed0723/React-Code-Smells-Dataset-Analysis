export default function Field<V>({
    fieldKey,
    value,
    label,
    description = null,
    control,
    onChange = () => {},
    compact = false,
    inline,
  }: FieldProps<V>) {
    const onControlChange = useCallback(
      newValue => {
        onChange(fieldKey, newValue);
      },
      [onChange, fieldKey],
    );
  
    const hookedControl = React.cloneElement(control, {
      value,
      onChange: onControlChange,
    });
    return (
      <FormItem
        label={
          <FormLabel className="m-r-5">
            {label || fieldKey}
            {compact && description && (
              <Tooltip id="field-descr" placement="right" title={description}>
                <i className="fa fa-info-circle m-l-5" />
              </Tooltip>
            )}
          </FormLabel>
        }
        css={inline && formItemInlineCss}
      >
        {hookedControl}
        {!compact && description && (
          <div
            css={(theme: SupersetTheme) => ({
              color: theme.colors.grayscale.base,
              [inline ? 'marginLeft' : 'marginTop']: theme.gridUnit,
            })}
          >
            {description}
          </div>
        )}
      </FormItem>
    );
  }