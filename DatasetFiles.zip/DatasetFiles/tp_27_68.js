export default class AnimatableDeckGLContainer extends React.PureComponent {
    containerRef = React.createRef();
  
    setTooltip = tooltip => {
      const { current } = this.containerRef;
      if (current) {
        current.setTooltip(tooltip);
      }
    };
  
    render() {
      const {
        start,
        end,
        getStep,
        disabled,
        aggregation,
        children,
        getLayers,
        values,
        onValuesChange,
        viewport,
        setControlValue,
        mapStyle,
        mapboxApiAccessToken,
        height,
        width,
      } = this.props;
      const layers = getLayers(values);
  
      return (
        <div>
          <DeckGLContainerStyledWrapper
            ref={this.containerRef}
            viewport={viewport}
            layers={layers}
            setControlValue={setControlValue}
            mapStyle={mapStyle}
            mapboxApiAccessToken={mapboxApiAccessToken}
            bottomMargin={disabled ? 0 : PLAYSLIDER_HEIGHT}
            width={width}
            height={height}
          />
          {!disabled && (
            <PlaySlider
              start={start}
              end={end}
              step={getStep(start)}
              values={values}
              range={!aggregation}
              onChange={onValuesChange}
            />
          )}
          {children}
        </div>
      );
    }
  }