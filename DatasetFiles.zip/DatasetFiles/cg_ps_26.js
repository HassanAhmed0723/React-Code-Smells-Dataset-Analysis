class CustomChatComponent extends React.PureComponent {
  static propTypes = {
    currentChannel: PropTypes.object,
    draft: PropTypes.shape({
      message: PropTypes.string,
    }),
    actions: PropTypes.shape({
      setShowPreview: PropTypes.func,
      clearDraftUploads: PropTypes.func,
      searchAssociatedGroupsForReference: PropTypes.func,
      getChannelMemberCountsByGroup: PropTypes.func,
      setShowPreview: PropTypes.func,
    }),
    isFormattingBarHidden: PropTypes.bool,
    useLDAPGroupMentions: PropTypes.bool,
    useCustomGroupMentions: PropTypes.bool,
    isTimezoneEnabled: PropTypes.bool,
    currentTeamId: PropTypes.string,
    shouldShowPreview: PropTypes.bool,
  };

  constructor(props) {
    super(props);

    this.state = {
      message: props.draft.message,
      caretPosition: props.draft.message.length,
      submitting: false,
      showEmojiPicker: false,
      uploadsProgressPercent: {},
      renderScrollbar: false,
      scrollbarWidth: 0,
      currentChannel: props.currentChannel,
      errorClass: null,
      serverError: null,
      showFormat: false,
      isFormattingBarHidden: props.isFormattingBarHidden,
      showPostPriorityPicker: false,
    };

    this.topDiv = React.createRef();
    this.textboxRef = React.createRef();
    this.fileUploadRef = React.createRef();
  }

  componentDidMount() {
    const { actions } = this.props;
    this.onOrientationChange();
    actions.setShowPreview(false);
    actions.clearDraftUploads();
    this.focusTextbox();
    document.addEventListener('paste', this.pasteHandler);
    document.addEventListener('keydown', this.documentKeyHandler);
    window.addEventListener('beforeunload', this.unloadHandler);
    this.setOrientationListeners();
    this.getChannelMemberCountsByGroup();
  }

  componentDidUpdate(prevProps, prevState) {
    const { currentChannel, actions } = this.props;
    if (prevProps.currentChannel.id !== currentChannel.id) {
      this.lastChannelSwitchAt = Date.now();
      this.focusTextbox();
      this.saveDraftWithShow(prevProps);
      this.getChannelMemberCountsByGroup();
    }

    if (currentChannel.id !== prevProps.currentChannel.id) {
      actions.setShowPreview(false);
    }

    // Focus on textbox when emoji picker is closed
    if (prevState.showEmojiPicker && !this.state.showEmojiPicker) {
      this.focusTextbox();
    }

    // Focus on textbox when returned from preview mode
    if (prevProps.shouldShowPreview && !this.props.shouldShowPreview) {
      this.focusTextbox();
    }
  }

  componentWillUnmount() {
    document.removeEventListener('paste', this.pasteHandler);
    document.removeEventListener('keydown', this.documentKeyHandler);
    window.removeEventListener('beforeunload', this.unloadHandler);
    this.removeOrientationListeners();
    this.saveDraftWithShow();
  }

  getChannelMemberCountsByGroup = () => {
    const {
      useLDAPGroupMentions,
      useCustomGroupMentions,
      currentChannel,
      isTimezoneEnabled,
      actions,
      draft,
    } = this.props;

    if ((useLDAPGroupMentions || useCustomGroupMentions) && currentChannel.id) {
      const mentions = mentionsMinusSpecialMentionsInText(draft.message);

      if (mentions.length === 1) {
        actions.searchAssociatedGroupsForReference(
          mentions[0],
          this.props.currentTeamId,
          currentChannel.id
        );
      } else if (mentions.length > 1) {
        actions.getChannelMemberCountsByGroup(currentChannel.id, isTimezoneEnabled);
      }
    }
  };

  unloadHandler = () => {
    this.saveDraftWithShow();
  };

  saveDraftWithShow = (props = this.props) => {
    if (this.saveDraftFrame && props.currentChannel) {
      const channelId = props.currentChannel.id;
      const draft = this.draftsForChannel[channelId];

      if (draft) {
        this.draftsForChannel[channelId] = {
          ...draft,
          show: !isDraftEmpty(draft),
        };
      }
    }

    this.saveDraft(props, true);
  };

}
