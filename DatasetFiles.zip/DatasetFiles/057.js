
const propTypes = {
    series: PropTypes.array,
    visualizationIsClickable: PropTypes.func,
    onVisualizationClick: PropTypes.func,
    onSortingChange: PropTypes.func,
    onRemoveRow: PropTypes.func,
    settings: PropTypes.object,
    isSortable: PropTypes.bool,
    sorting: PropTypes.shape({
      column: PropTypes.string.isRequired,
      isAscending: PropTypes.bool.isRequired,
    }),
    isSelectable: PropTypes.bool,
    rowChecked: PropTypes.object,
    onAllSelectClick: PropTypes.func,
    onRowSelectClick: PropTypes.func,
  };
  
  const ROW_ID_IDX = 0;
  
  export default class AuditTableVisualization extends React.Component {
    static identifier = "audit-table";
    static noHeader = true;
    static hidden = true;
  
    // copy Table's settings and columnSettings
    static settings = Table.settings;
    static columnSettings = Table.columnSettings;
  
    state = {
      rerender: {},
    };
  
    constructor(props) {
      super(props);
    }
  
    handleColumnHeaderClick = column => {
      const { isSortable, onSortingChange, sorting } = this.props;
  
      if (!isSortable || !onSortingChange) {
        return;
      }
  
      const columnName = getColumnName(column);
  
      onSortingChange({
        column: columnName,
        isAscending: columnName !== sorting.column || !sorting.isAscending,
      });
    };
  
    handleAllSelectClick = (e, rows) => {
      const { onAllSelectClick } = this.props;
      this.setState({ rerender: {} });
      onAllSelectClick({ ...e, rows });
    };
  
    handleRowSelectClick = (e, row, rowIndex) => {
      const { onRowSelectClick } = this.props;
      this.setState({ rerender: {} });
      onRowSelectClick({ ...e, row: row, rowIndex: rowIndex });
    };
  
    handleRemoveRowClick = (row, cols) => {
      const rowData = getRowValuesByColumns(row, cols);
      this.props.onRemoveRow(rowData);
    };
  
    render() {
      const {
        series: [
          {
            data: { cols, rows },
          },
        ],
        sorting,
        visualizationIsClickable,
        onVisualizationClick,
        settings,
        isSortable,
        isSelectable,
        rowChecked,
        onRemoveRow,
      } = this.props;
  
      const canRemoveRows = !!onRemoveRow;
      const columnIndexes = settings["table.columns"]
        .filter(({ enabled }) => enabled)
        .map(({ name }) => _.findIndex(cols, col => col.name === name));
  
      if (rows.length === 0) {
        return (
          <EmptyState
            title={t`No results`}
            illustrationElement={<img src={NoResults} />}
          />
        );
      }
      return (
        <table className="ContentTable">
          <thead>
            <tr>
              {isSelectable && (
                <th>
                  <CheckBox
                    checked={Object.values(rowChecked).some(elem => elem)}
                    onChange={e => this.handleAllSelectClick(e, rows)}
                  />
                </th>
              )}
              {columnIndexes.map(colIndex => {
                const column = cols[colIndex];
                const isSortedByColumn =
                  sorting && sorting.column === getColumnName(column);
  
                return (
                  <th
                    key={colIndex}
                    onClick={() => this.handleColumnHeaderClick(column)}
                    className={cx("text-nowrap", {
                      "text-right": isColumnRightAligned(column),
                      "text-brand": isSortedByColumn,
                      "cursor-pointer text-brand-hover": isSortable,
                    })}
                  >
                    {formatColumn(cols[colIndex])}
                    {isSortedByColumn && (
                      <Icon
                        className="ml1"
                        name={sorting.isAscending ? "chevronup" : "chevrondown"}
                        size={10}
                      />
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
  