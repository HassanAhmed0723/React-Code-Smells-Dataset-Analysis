export function CustomFrame(props: FrameComponentProps) {
    const { customRange, matchedFlag } = customTimeRangeDecode(props.value);
    if (!matchedFlag) {
      props.onChange(customTimeRangeEncode(customRange));
    }
    const {
      sinceDatetime,
      sinceMode,
      sinceGrain,
      sinceGrainValue,
      untilDatetime,
      untilMode,
      untilGrain,
      untilGrainValue,
      anchorValue,
      anchorMode,
    } = { ...customRange };