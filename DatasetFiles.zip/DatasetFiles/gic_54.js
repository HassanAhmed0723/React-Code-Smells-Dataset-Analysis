export class SlowChartPlugin extends ChartPlugin<QueryFormData> {
    constructor() {
      super({
        metadata: new ChartMetadata({
          name: ChartKeys.SLOW,
          thumbnail: '',
        }),
        loadChart: () =>
          new Promise(resolve => {
            setTimeout(() => {
              resolve(TestComponent);
            }, 1000);
          }),
        transformProps: x => x,
      });
    }
  }