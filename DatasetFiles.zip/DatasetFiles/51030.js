class Foo extends React.Component {
    constructor(props) {
      super(props);
      this.state = {bar: props.initialValue};
    }
    handleClick() {
      this.setState({bar: 'bar'});
    }
    render() {
      return <Inner name={this.state.bar} onClick={this.handleClick} />;
    }
  }
  test(<Foo initialValue="foo" />, 'DIV', 'foo');
  expect(attachedListener).toThrow();
}