const AdhocFilterEditPopoverSimpleTabContent: React.FC<Props> = props => {
    const {
      onSubjectChange,
      onOperatorChange,
      isOperatorRelevant,
      onComparatorChange,
      onDatePickerChange,
    } = useSimpleTabFilterProps(props);
    const [suggestions, setSuggestions] = useState<
      Record<'label' | 'value', any>[]
    >([]);
    const [comparator, setComparator] = useState(props.adhocFilter.comparator);
    const [loadingComparatorSuggestions, setLoadingComparatorSuggestions] =
      useState(false);
  
    const {
      advancedDataTypesState,
      subjectAdvancedDataType,
      fetchAdvancedDataTypeValueCallback,
      fetchSubjectAdvancedDataType,
    } = useAdvancedDataTypes(props.validHandler);
    // TODO: This does not need to exist, just use the advancedTypeOperatorList list
    const isOperatorRelevantWrapper = (operator: Operators, subject: string) =>
      subjectAdvancedDataType
        ? isOperatorRelevant(operator, subject) &&
          advancedDataTypesState.advancedDataTypeOperatorList.includes(operator)
        : isOperatorRelevant(operator, subject);
    const onInputComparatorChange = (
      event: React.ChangeEvent<HTMLInputElement>,
    ) => {
      const { value } = event.target;
      setComparator(value);
      onComparatorChange(value);
    };
  
    const renderSubjectOptionLabel = (option: ColumnType) => (
      <FilterDefinitionOption option={option} />
    );
  
    const getOptionsRemaining = () => {
      // if select is multi/value is array, we show the options not selected
      const valuesFromSuggestionsLength = Array.isArray(comparator)
        ? comparator.filter(v => suggestions.includes(v)).length
        : 0;
      return suggestions?.length - valuesFromSuggestionsLength ?? 0;
    };
    const createSuggestionsPlaceholder = () => {
      const optionsRemaining = getOptionsRemaining();
      const placeholder = t('%s option(s)', optionsRemaining);
      return optionsRemaining ? placeholder : '';
    };
  
    const handleSubjectChange = (subject: string) => {
      setComparator(undefined);
      onSubjectChange(subject);
    };
  
    let columns = props.options;
    const { subject, operator, operatorId } = props.adhocFilter;
  
    const subjectSelectProps = {
      ariaLabel: t('Select subject'),
      value: subject ?? undefined,
      onChange: handleSubjectChange,
      notFoundContent: t(
        'No such column found. To filter on a metric, try the Custom SQL tab.',
      ),
      autoFocus: !subject,
      placeholder: '',
    };
  
    subjectSelectProps.placeholder =
      props.adhocFilter.clause === CLAUSES.WHERE
        ? t('%s column(s)', columns.length)
        : t('To filter on a metric, use Custom SQL tab.');
    columns = props.options.filter(
      option => 'column_name' in option && option.column_name,
    );
  
    const operatorSelectProps = {
      placeholder: t(
        '%s operator(s)',
        (props.operators ?? OPERATORS_OPTIONS).filter(op =>
          isOperatorRelevantWrapper(op, subject),
        ).length,
      ),
      value: operatorId,
      onChange: onOperatorChange,
      autoFocus: !!subjectSelectProps.value && !operator,
      ariaLabel: t('Select operator'),
    };
  
    const shouldFocusComparator =
      !!subjectSelectProps.value && !!operatorSelectProps.value;
  
    const comparatorSelectProps = {
      allowClear: true,
      allowNewOptions: true,
      ariaLabel: t('Comparator option'),
      mode: MULTI_OPERATORS.has(operatorId)
        ? ('multiple' as const)
        : ('single' as const),
      loading: loadingComparatorSuggestions,
      value: comparator,
      onChange: onComparatorChange,
      notFoundContent: t('Type a value here'),
      disabled: DISABLE_INPUT_OPERATORS.includes(operatorId),
      placeholder: createSuggestionsPlaceholder(),
      autoFocus: shouldFocusComparator,
    };
  
    const labelText =
      comparator && comparator.length > 0 && createSuggestionsPlaceholder();
  
    const datePicker = useDatePickerInAdhocFilter({
      columnName: props.adhocFilter.subject,
      timeRange:
        props.adhocFilter.operator === Operators.TEMPORAL_RANGE
          ? props.adhocFilter.comparator
          : undefined,
      datasource: props.datasource,
      onChange: onDatePickerChange,
    });
  
    useEffect(() => {
      const refreshComparatorSuggestions = () => {
        const { datasource } = props;
        const col = props.adhocFilter.subject;
        const having = props.adhocFilter.clause === CLAUSES.HAVING;
  
        if (col && datasource && datasource.filter_select && !having) {
          const controller = new AbortController();
          const { signal } = controller;
          if (loadingComparatorSuggestions) {
            controller.abort();
          }
          setLoadingComparatorSuggestions(true);
          SupersetClient.get({
            signal,
            endpoint: `/api/v1/datasource/${datasource.type}/${datasource.id}/column/${col}/values/`,
          })
            .then(({ json }) => {
              setSuggestions(
                json.result.map(
                  (suggestion: null | number | boolean | string) => ({
                    value: suggestion,
                    label: optionLabel(suggestion),
                  }),
                ),
              );
              setLoadingComparatorSuggestions(false);
            })
            .catch(() => {
              setSuggestions([]);
              setLoadingComparatorSuggestions(false);
            });
        }
      };
      if (!datePicker) {
        refreshComparatorSuggestions();
      }
    }, [props.adhocFilter.subject]);
  
    useEffect(() => {
      if (isFeatureEnabled(FeatureFlag.ENABLE_ADVANCED_DATA_TYPES)) {
        fetchSubjectAdvancedDataType(props);
      }
    }, [props.adhocFilter.subject]);
  
    useEffect(() => {
      if (isFeatureEnabled(FeatureFlag.ENABLE_ADVANCED_DATA_TYPES)) {
        fetchAdvancedDataTypeValueCallback(
          comparator === undefined ? '' : comparator,
          advancedDataTypesState,
          subjectAdvancedDataType,
        );
      }
    }, [comparator, subjectAdvancedDataType, fetchAdvancedDataTypeValueCallback]);
  
    useEffect(() => {
      if (isFeatureEnabled(FeatureFlag.ENABLE_ADVANCED_DATA_TYPES)) {
        setComparator(props.adhocFilter.comparator);
      }
    }, [props.adhocFilter.comparator]);
  
    // another name for columns, just for following previous naming.
    const subjectComponent = (
      <Select
        css={(theme: SupersetTheme) => ({
          marginTop: theme.gridUnit * 4,
          marginBottom: theme.gridUnit * 4,
        })}
        data-test="select-element"
        options={columns.map(column => ({
          value:
            ('column_name' in column && column.column_name) ||
            ('optionName' in column && column.optionName) ||
            '',
          label:
            ('saved_metric_name' in column && column.saved_metric_name) ||
            ('column_name' in column && column.column_name) ||
            ('label' in column && column.label),
          key:
            ('id' in column && column.id) ||
            ('optionName' in column && column.optionName) ||
            undefined,
          customLabel: renderSubjectOptionLabel(column),
        }))}
        {...subjectSelectProps}
      />
    );
  
    const operatorsAndOperandComponent = (
      <>
        <Select
          css={(theme: SupersetTheme) => ({ marginBottom: theme.gridUnit * 4 })}
          options={(props.operators ?? OPERATORS_OPTIONS)
            .filter(op => isOperatorRelevantWrapper(op, subject))
            .map((option, index) => ({
              value: option,
              label: OPERATOR_ENUM_TO_OPERATOR_TYPE[option].display,
              key: option,
              order: index,
            }))}
          {...operatorSelectProps}
        />
        {MULTI_OPERATORS.has(operatorId) || suggestions.length > 0 ? (
          <Tooltip
            title={
              advancedDataTypesState.errorMessage ||
              advancedDataTypesState.parsedAdvancedDataType
            }
          >
            <SelectWithLabel
              labelText={labelText}
              options={suggestions}
              {...comparatorSelectProps}
            />
          </Tooltip>
        ) : (
          <Tooltip
            title={
              advancedDataTypesState.errorMessage ||
              advancedDataTypesState.parsedAdvancedDataType
            }
          >
            <StyledInput
              data-test="adhoc-filter-simple-value"
              name="filter-value"
              ref={ref => {
                if (ref && shouldFocusComparator) {
                  ref.focus();
                }
              }}
              onChange={onInputComparatorChange}
              value={comparator}
              placeholder={t('Filter value (case sensitive)')}
              disabled={DISABLE_INPUT_OPERATORS.includes(operatorId)}
            />
          </Tooltip>
        )}
      </>
    );
    return (
      <>
        {subjectComponent}
        {datePicker ?? operatorsAndOperandComponent}
      </>
    );
  };