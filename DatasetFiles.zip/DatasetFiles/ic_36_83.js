class SaveQueryError extends Error {
    constructor(message, detailedMessage = null) {
      super(message);
      this.detailedMessage = detailedMessage;
    }
  }