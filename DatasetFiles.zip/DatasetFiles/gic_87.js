import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import ScreenHeader from './ScreenHeader'; // Replace with the actual ScreenHeader component
import { themeStyle } from './theme'; // Replace with the actual themeStyle function
import Tag from './Tag'; // Replace with the actual Tag module

function TagsScreenComponent(props) {
    const [tags, setTags] = useState([]);

    const styles = StyleSheet.create({
        listItem: {
            flexDirection: 'row',
            borderBottomWidth: 1,
            borderBottomColor: theme.color.dividerColor,
            alignItems: 'flex-start',
            paddingLeft: theme.marginLeft,
            paddingRight: theme.marginRight,
            paddingTop: theme.itemMarginTop,
            paddingBottom: theme.itemMarginBottom,
        },
        listItemText: {
            flex: 1,
            color: theme.color,
            fontSize: theme.fontSize,
        },
    });

    const tagItem_press = (event) => {
        props.dispatch({ type: 'SIDE_MENU_CLOSE' });

        props.dispatch({
            type: 'NAV_GO',
            routeName: 'Notes',
            tagId: event.id,
        });
    };

    const tagList_renderItem = (event) => {
        const tag = event.item;
        return (
            <TouchableOpacity onPress={() => tagItem_press({ id: tag.id })}>
                <View style={styles.listItem}>
                    <Text style={styles.listItemText}>{tag.title}</Text>
                </View>
            </TouchableOpacity>
        );
    };

    const tagList_keyExtractor = (item) => item.id;

    useEffect(() => {
        const fetchTags = async () => {
            const fetchedTags = await Tag.allWithNotes();
            fetchedTags.sort((a, b) => (a.title.toLowerCase() < b.title.toLowerCase() ? -1 : 1));
            setTags(fetchedTags);
        };
        fetchTags();
    }, []);

    const theme = themeStyle(props.themeId);

    const rootStyle = {
        flex: 1,
        backgroundColor: theme.backgroundColor,
    };

    return (
        <View style={rootStyle}>
            <ScreenHeader title={_('Tags')} parentComponent={this} showSearchButton={false} />
            <FlatList style={{ flex: 1 }} data={tags} renderItem={tagList_renderItem} keyExtractor={tagList_keyExtractor} />
        </View>
    );
}

export default TagsScreenComponent;
