export class HandlerDrilldownViewBehavior extends SceneObjectBase<HandlerDrilldownViewBehaviorState> {
    protected _urlSync = new SceneObjectUrlSyncConfig(this, { keys: ['handler'] });
  
    public constructor() {
      super({});
  
      this.addActivationHandler(() => {
        this._subs.add(this.subscribeToState((state) => this.onHandlerChanged(state.handler)));
        this.onHandlerChanged(this.state.handler);
      });
    }
  
    private onHandlerChanged(handler: string | undefined) {
      const layout = this.getLayout();
  
      if (handler == null) {
        layout.setState({ children: layout.state.children.slice(0, 1) });
      } else {
        layout.setState({ children: [layout.state.children[0], this.getDrilldownView(handler)] });
      }
    }
  
    private getDrilldownView(handler: string): SceneFlexItem {
      return new SceneFlexItem({
        key: 'drilldown-flex',
        body: new VizPanel({
          $data: getTimeSeriesQuery({
            expr: `rate(grafana_http_request_duration_seconds_sum{handler="${handler}"}[$__rate_interval]) * 1e3`,
          }),
          pluginId: 'timeseries',
          title: `Handler: ${handler} details`,
          headerActions: (
            <Button size="sm" variant="secondary" icon="times" onClick={() => this.setState({ handler: undefined })} />
          ),
        }),
      });
    }
  
    public getUrlState() {
      return { handler: this.state.handler };
    }
  
    public updateFromUrl(values: SceneObjectUrlValues) {
      if (typeof values.handler === 'string' || values.handler === undefined) {
        this.setState({ handler: values.handler });
      }
    }
  
    private getLayout() {
      if (this.parent instanceof SceneFlexLayout) {
        return this.parent;
      }
  
      throw new Error('Invalid parent');
    }
  }