const DatabaseModal: FunctionComponent<DatabaseModalProps> = ({
    addDangerToast,
    addSuccessToast,
    onDatabaseAdd,
    onHide,
    show,
    databaseId,
    dbEngine,
    history,
  })