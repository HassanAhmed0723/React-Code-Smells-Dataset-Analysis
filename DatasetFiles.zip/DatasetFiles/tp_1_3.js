export type ControlHeaderProps = {
    name?: string;
    label?: ReactNode;
    description?: ReactNode;
    validationErrors?: ValidationError[];
    renderTrigger?: boolean;
    rightNode?: ReactNode;
    leftNode?: ReactNode;
    hovered?: boolean;
    required?: boolean;
    warning?: string;
    danger?: string;
    onClick?: () => void;
    tooltipOnClick?: () => void;
  };
  
  export default function ControlHeader({
    name,
    description,
    label,
    tooltipOnClick,
    onClick,
    warning,
    danger,
    leftNode,
    rightNode,
    validationErrors = [],
    renderTrigger = false,
    hovered = false,
    required = false,
  }: ControlHeaderProps) {
    const renderOptionalIcons = () => {
      if (hovered) {
        return (
          <span>
            {description && (
              <span>
                <InfoTooltipWithTrigger
                  label={t('description')}
                  tooltip={description}
                  placement="top"
                  onClick={tooltipOnClick}
                />{' '}
              </span>
            )}
            {renderTrigger && (
              <span>
                <InfoTooltipWithTrigger
                  label={t('bolt')}
                  tooltip={t('Changing this control takes effect instantly')}
                  placement="top"
                  icon="bolt"
                />{' '}
              </span>
            )}
          </span>
        );
      }
      return null;
    };
  
    if (!label) {
      return null;
    }
    const labelClass = validationErrors.length > 0 ? 'text-danger' : '';
    return (
      <div className="ControlHeader" data-test={`${name}-header`}>
        <div className="pull-left">
          <label className="control-label" htmlFor={name}>
            {leftNode && <span>{leftNode}</span>}
            <span
              role="button"
              tabIndex={0}
              onClick={onClick}
              className={labelClass}
              style={{ cursor: onClick ? 'pointer' : '' }}
            >
              {label}
            </span>{' '}
            {warning && (
              <span>
                <Tooltip id="error-tooltip" placement="top" title={warning}>
                  <i className="fa fa-exclamation-circle text-warning" />
                </Tooltip>{' '}
              </span>
            )}
            {danger && (
              <span>
                <Tooltip id="error-tooltip" placement="top" title={danger}>
                  <i className="fa fa-exclamation-circle text-danger" />
                </Tooltip>{' '}
              </span>
            )}
            {validationErrors.length > 0 && (
              <span>
                <Tooltip
                  id="error-tooltip"
                  placement="top"
                  title={validationErrors.join(' ')}
                >
                  <i className="fa fa-exclamation-circle text-danger" />
                </Tooltip>{' '}
              </span>
            )}
            {renderOptionalIcons()}
            {required && (
              <span className="text-danger m-l-4">
                <strong>*</strong>
              </span>
            )}
          </label>
        </div>
        {rightNode && <div className="pull-right">{rightNode}</div>}
        <div className="clearfix" />
      </div>
    );
  }
  