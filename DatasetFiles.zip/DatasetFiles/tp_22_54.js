export const WithNegativeNumbers = ({ width, height }) => (
    <SuperChart
      chartType="echarts-timeseries"
      width={width}
      height={height}
      queriesData={[
        { data: negativeNumData, colnames: ['__timestamp'], coltypes: [2] },
      ]}
      formData={{
        color_scheme: 'supersetColors',
        seriesType: select(
          'Line type',
          ['line', 'scatter', 'smooth', 'bar', 'start', 'middle', 'end'],
          'line',
        ),
        y_axis_format: '$,.2f',
        stack: boolean('Stack', true),
        show_value: true,
        show_legend: true,
        only_total: boolean('Only Total', true),
        orientation: select(
          'Orientation',
          ['vertical', 'horizontal'],
          'vertical',
        ),
        x_axis: '__timestamp',
      }}
    />
  );