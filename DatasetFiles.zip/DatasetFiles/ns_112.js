export function ExtraControls<
  F extends {
    stack: any;
    area: boolean;
    showExtraControls: boolean;
  },
>({
  formData,
  setControlValue,
}: {
  formData: F;
  setControlValue?: HandlerFunction;
}) {
  const { extraControlsOptions, extraControlsHandler, extraValue } =
    useExtraControl<F>({
      formData,
      setControlValue,
    });

  if (!formData.showExtraControls) {
    return null;
  }

  return (
    <ExtraControlsWrapper>
      <RadioButtonControl
        options={extraControlsOptions}
        onChange={extraControlsHandler}
        value={extraValue}
      />
    </ExtraControlsWrapper>
  );
}
