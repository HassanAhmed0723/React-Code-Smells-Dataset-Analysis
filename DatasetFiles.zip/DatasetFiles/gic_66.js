class RootElement extends FrameState {
    constructor(options, scene, changeCallback) {
        super(options, scene);

        this.sizeStyle = {
            height: '100%',
            width: '100%',
        };

        this.changeCallback = changeCallback;
    }

    onChange(options) {
        this.revId++;
        this.options = { ...options };
        this.changeCallback();
    }

    render() {
        return (
            <div
                onContextMenu={(event) => event.preventDefault()}
                key={this.UID}
                ref={this.setRootRef}
                style={{ ...this.sizeStyle, ...this.dataStyle }}
            >
                {this.elements.map((v) => v.render())}
            </div>
        );
    }

    // Additional methods and logic specific to RootElement...
}

class FrameState extends React.Component {
    // ... logic for rendering a frame ...
    render() {
        return (
            <div key={this.UID} ref={this.initElement}>
                {this.elements.map((v) => v.render())}
            </div>
        );
    }

    // Additional methods and logic specific to FrameState...
}

class ElementState extends React.Component {
    // ... logic for rendering an element ...
    render() {
        return <div>{/* Rendered content */}</div>;
    }

    // Additional methods and logic specific to ElementState...
}

class App extends React.Component {
    render() {
        return (
            <div>
                {/* Render components using inherited and overridden methods */}
            </div>
        );
    }
}

ReactDOM.render(<App />, document.getElementById("root"));
