const FilterControl = ({
    dataMaskSelected,
    filter,
    icon,
    onFilterSelectionChange,
    inView,
    showOverflow,
    parentRef,
    orientation = FilterBarOrientation.VERTICAL,
    overflow = false,
  }: FilterControlProps)