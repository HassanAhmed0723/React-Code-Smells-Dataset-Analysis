class Vehicle {
    constructor(make, model) {
      this.make = make;
      this.model = model;
    }
  
    getInfo() {
      return `${this.make} ${this.model}`;
    }
  
    startEngine() {
      console.log(`${this.getInfo()} engine started.`);
    }
  }
  
  class Car extends Vehicle {
    constructor(make, model, year) {
      super(make, model);
      this.year = year;
    }
  
    startEngine() {
      console.log(`${this.getInfo()} engine revving.`);
    }
  
    drive() {
      console.log(`${this.getInfo()} is now driving.`);
    }
  }
  
  class Motorcycle extends Vehicle {
    constructor(make, model, year) {
      super(make, model);
      this.year = year;
    }
  
    startEngine() {
      console.log(`${this.getInfo()} engine roaring.`);
    }
  
    ride() {
      console.log(`${this.getInfo()} is now riding.`);
    }
  }
  
  const car = new Car('Toyota', 'Camry', 2022);
  const motorcycle = new Motorcycle('Harley-Davidson', 'Sportster', 2022);
  
  car.startEngine();
  car.drive();
  
  motorcycle.startEngine();
  motorcycle.ride();
  