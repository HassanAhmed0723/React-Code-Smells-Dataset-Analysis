class BaseScreenComponent {
    // ... common methods and logic ...
}

class StatusScreenComponent extends BaseScreenComponent {
    constructor() {
        super();
        this.state = {
            report: [],
        };

        this.resfreshScreen = async () => {
            // ... specific logic ...
        };

        this.styles = () => {
            const theme = themeStyle(this.props.themeId);
            return {
                body: {
                    flex: 1,
                    margin: theme.margin,
                },
            };
        };
    }

    render() {
        const theme = themeStyle(this.props.themeId);

        const renderBody = (report) => {
            // ... specific rendering logic ...
        };

        const body = renderBody(this.state.report);

        return (
            <View style={this.rootStyle(this.props.themeId).root}>
                <ScreenHeader title={_('Status')} />
                <View style={this.styles().body}>{body}</View>
                <Button title={_('Refresh')} onPress={() => this.resfreshScreen()} />
            </View>
        );
    }
}
