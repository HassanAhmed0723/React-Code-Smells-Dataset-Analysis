interface CustomDatePickerProps {
  initialSelectedDate: Date | null;
  onDateSelected: (selectedDate: Date | null) => void;
}

interface CustomDatePickerState {
  selectedDate: Date | null;
}

class CustomDatePicker extends Component<CustomDatePickerProps, CustomDatePickerState> {
  constructor(props: CustomDatePickerProps) {
    super(props);
    this.state = {
      selectedDate: props.initialSelectedDate,
    };
  }

  componentDidUpdate(prevProps: CustomDatePickerProps) {
    if (this.props.initialSelectedDate !== prevProps.initialSelectedDate) {
      this.setState({ selectedDate: this.props.initialSelectedDate });
    }
  }

  handleDateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newDate = new Date(event.target.value);
    this.setState({ selectedDate: newDate }, () => {
      this.props.onDateSelected(this.state.selectedDate);
    });
  };

  render() {
    const { selectedDate } = this.state;

    return (
      <div>
        <input
          type="date"
          value={selectedDate ? selectedDate.toISOString().slice(0, 10) : ''}
          onChange={this.handleDateChange}
        />
        <p>Selected Date: {selectedDate ? selectedDate.toISOString().slice(0, 10) : 'None'}</p>
      </div>
    );
  }
}
