interface ExampleComponentProps {
  data: any;
  endpoint: string;
}

interface ExampleComponentState {
  initialData: any;
  isLoading: boolean;
  errorMessage: string | null;
}

export class ExampleComponent extends React.Component<ExampleComponentProps, ExampleComponentState> {
  constructor(props: ExampleComponentProps) {
    super(props);
    this.state = {
      initialData: props.data,
      isLoading: false,
      errorMessage: null,
    };
  }

  componentDidMount() {
    this.fetchData();
  }

  fetchData() {
    this.setState({ isLoading: true, errorMessage: null });

    // Simulating an API call
    setTimeout(() => {
      // Replace this with your API call
      const { endpoint } = this.props;
      fetch(endpoint)
        .then(response => response.json())
        .then(data => {
          this.setState({ initialData: data, isLoading: false });
        })
        .catch(error => {
          this.setState({ errorMessage: error.message, isLoading: false });
        });
    }, 1000); // Simulating a delay of 1 second
  }

  render() {
    const { initialData, isLoading, errorMessage } = this.state;

    if (isLoading) {
      return <div>Loading...</div>;
    }

    if (errorMessage) {
      return <div>Error: {errorMessage}</div>;
    }

    return <div>Data: {JSON.stringify(initialData)}</div>;
  }
}
