export default function EchartsGraph({
    height,
    width,
    echartOptions,
    formData,
    onContextMenu,
    setDataMask,
    filterState,
    emitCrossFilters,
    refs,
    coltypeMapping,
  }: GraphChartTransformedProps)