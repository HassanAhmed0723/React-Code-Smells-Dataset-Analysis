const FilterTitlePane: React.FC<Props> = ({
    getFilterTitle,
    onChange,
    onAdd,
    onRemove,
    onRearrange,
    restoreFilter,
    currentFilterId,
    filters,
    removedFilters,
    erroredFilters,
  })