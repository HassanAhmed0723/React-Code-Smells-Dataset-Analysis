export const DashboardPage: FC<PageProps> = ({ idOrSlug }: PageProps) => {
    const theme = useTheme();
    const dispatch = useDispatch();
    const history = useHistory();
    const dashboardPageId = useSyncDashboardStateWithLocalStorage();
    const { addDangerToast } = useToasts();
    const { result: dashboard, error: dashboardApiError } =
      useDashboard(idOrSlug);
    const { result: charts, error: chartsApiError } =
      useDashboardCharts(idOrSlug);
    const {
      result: datasets,
      error: datasetsApiError,
      status,
    } = useDashboardDatasets(idOrSlug);
    const isDashboardHydrated = useRef(false);
  
    const error = dashboardApiError || chartsApiError;
    const readyToRender = Boolean(dashboard && charts);
    const { dashboard_title, css, metadata, id = 0 } = dashboard || {};
  
    useEffect(() => {
      // mark tab id as redundant when user closes browser tab - a new id will be
      // generated next time user opens a dashboard and the old one won't be reused
      const handleTabClose = () => {
        const dashboardsContexts = getDashboardContextLocalStorage();
        setItem(LocalStorageKeys.dashboard__explore_context, {
          ...dashboardsContexts,
          [dashboardPageId]: {
            ...dashboardsContexts[dashboardPageId],
            isRedundant: true,
          },
        });
      };
      window.addEventListener('beforeunload', handleTabClose);
      return () => {
        window.removeEventListener('beforeunload', handleTabClose);
      };
    }, [dashboardPageId]);
  
    useEffect(() => {
      dispatch(setDatasetsStatus(status));
    }, [dispatch, status]);
  
    useEffect(() => {
      // eslint-disable-next-line consistent-return
      async function getDataMaskApplied() {
        const permalinkKey = getUrlParam(URL_PARAMS.permalinkKey);
        const nativeFilterKeyValue = getUrlParam(URL_PARAMS.nativeFiltersKey);
        const isOldRison = getUrlParam(URL_PARAMS.nativeFilters);
  
        let dataMask = nativeFilterKeyValue || {};
        // activeTabs is initialized with undefined so that it doesn't override
        // the currently stored value when hydrating
        let activeTabs: string[] | undefined;
        if (permalinkKey) {
          const permalinkValue = await getPermalinkValue(permalinkKey);
          if (permalinkValue) {
            ({ dataMask, activeTabs } = permalinkValue.state);
          }
        } else if (nativeFilterKeyValue) {
          dataMask = await getFilterValue(id, nativeFilterKeyValue);
        }
        if (isOldRison) {
          dataMask = isOldRison;
        }
  
        if (readyToRender) {
          if (!isDashboardHydrated.current) {
            isDashboardHydrated.current = true;
            if (isFeatureEnabled(FeatureFlag.DASHBOARD_NATIVE_FILTERS_SET)) {
              // only initialize filterset once
              dispatch(getFilterSets(id));
            }
          }
          dispatch(
            hydrateDashboard({
              history,
              dashboard,
              charts,
              activeTabs,
              dataMask,
            }),
          );
        }
        return null;
      }
      if (id) getDataMaskApplied();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [readyToRender]);
  
    useEffect(() => {
      if (dashboard_title) {
        document.title = dashboard_title;
      }
      return () => {
        document.title = originalDocumentTitle;
      };
    }, [dashboard_title]);
  
    useEffect(() => {
      if (typeof css === 'string') {
        // returning will clean up custom css
        // when dashboard unmounts or changes
        return injectCustomCss(css);
      }
      return () => {};
    }, [css]);
  
    useEffect(() => {
      const sharedLabelColor = getSharedLabelColor();
      sharedLabelColor.source = SharedLabelColorSource.dashboard;
      return () => {
        // clean up label color
        const categoricalNamespace = CategoricalColorNamespace.getNamespace(
          metadata?.color_namespace,
        );
        categoricalNamespace.resetColors();
        sharedLabelColor.clear();
      };
    }, [metadata?.color_namespace]);
  
    useEffect(() => {
      if (datasetsApiError) {
        addDangerToast(
          t('Error loading chart datasources. Filters may not work correctly.'),
        );
      } else {
        dispatch(setDatasources(datasets));
      }
    }, [addDangerToast, datasets, datasetsApiError, dispatch]);
  
    if (error) throw error; // caught in error boundary
    if (!readyToRender || !isDashboardHydrated.current) return <Loading />;
  
    return (
      <>
        <Global
          styles={[
            filterCardPopoverStyle(theme),
            headerStyles(theme),
            chartContextMenuStyles(theme),
          ]}
        />
        <DashboardPageIdContext.Provider value={dashboardPageId}>
          <DashboardContainer />
        </DashboardPageIdContext.Provider>
      </>
    );
  };
  