class AnimalComponent extends React.Component {
    render() {
        return <div>{this.props.animal} component</div>;
    }
}

class DogComponent extends AnimalComponent {
    render() {
        return <div>{this.props.animal} component that barks</div>;
    }
}

class CatComponent extends AnimalComponent {
    render() {
        return <div>{this.props.animal} component that meows</div>;
    }
}

class App extends React.Component {
    render() {
        return (
            <div>
                <AnimalComponent animal="Generic Animal" />
                <DogComponent animal="Dog" />
                <CatComponent animal="Cat" />
            </div>
        );
    }
}

ReactDOM.render(<App />, document.getElementById("root"));
