class PageComponent extends React.Component {
    render() {
        return (
            <div>
                {this.renderHeader()}
                {this.renderContent()}
                {this.renderFooter()}
            </div>
        );
    }

    renderHeader() {
        return <header>This is the header</header>;
    }

    renderContent() {
        return <p>This is the content</p>;
    }

    renderFooter() {
        return <footer>This is the footer</footer>;
    }
}

class HomePage extends PageComponent {
    renderHeader() {
        return <header>Welcome to our website</header>;
    }

    renderContent() {
        return <p>Explore our products and services.</p>;
    }
}

class AboutPage extends PageComponent {
    renderHeader() {
        return <header>About Us</header>;
    }

    renderContent() {
        return <p>Learn more about our history and mission.</p>;
    }
}

class App extends React.Component {
    render() {
        return (
            <div>
                <HomePage />
                <AboutPage />
            </div>
        );
    }
}

ReactDOM.render(<App />, document.getElementById("root"));
