const PanelHeader = () => (
    <span data-test="collapsible-control-panel-header">
      <span
        css={(theme: SupersetTheme) => css`
          font-size: ${theme.typography.sizes.m}px;
          line-height: 1.3;
        `}
      >
        {label}
      </span>{' '}
      {description && (
        <Tooltip id={sectionId} title={description}>
          <Icons.InfoCircleOutlined css={iconStyles} />
        </Tooltip>
      )}
      {hasErrors && (
        <Tooltip
          id={`${kebabCase('validation-errors')}-tooltip`}
          title={t('This section contains validation errors')}
        >
          <Icons.InfoCircleOutlined
            css={css`
              ${iconStyles};
              color: ${errorColor};
            `}
          />
        </Tooltip>
      )}
    </span>
  );