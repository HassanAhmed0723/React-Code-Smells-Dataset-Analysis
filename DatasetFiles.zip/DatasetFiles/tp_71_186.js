function ReportModal({
    onHide,
    show = false,
    dashboardId,
    chart,
    userId,
    userEmail,
    creationMethod,
    dashboardName,
    chartName,
  }: ReportProps)