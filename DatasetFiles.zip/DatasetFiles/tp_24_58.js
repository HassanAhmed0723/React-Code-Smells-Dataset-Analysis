class CustomHistogram extends React.PureComponent {
    render() {
      const {
        className,
        data,
        width,
        height,
        binCount,
        colorScheme,
        normalized,
        cumulative,
        opacity,
        xAxisLabel,
        yAxisLabel,
        showLegend,
        sliceId,
      } = this.props;
  
      const colorFn = CategoricalColorNamespace.getScale(colorScheme);
      const keys = data.map(d => d.key);
      const colorScale = scaleOrdinal({
        domain: keys,
        range: keys.map(x => colorFn(x, sliceId)),
      });
  
      return (
        <WithLegend
          className={`superset-legacy-chart-histogram ${className}`}
          width={width}
          height={height}
          position="top"
          renderLegend={({ direction, style }) =>
            showLegend && (
              <LegendOrdinal
                style={style}
                scale={colorScale}
                direction={direction}
                shape="rect"
                labelMargin="0 15px 0 0"
              />
            )
          }
          renderChart={parent => (
            <Histogram
              width={parent.width}
              height={parent.height}
              ariaLabel="Histogram"
              normalized={normalized}
              cumulative={cumulative}
              binCount={binCount}
              binType="numeric"
              margin={{ top: 20, right: 20 }}
              renderTooltip={({ datum, color }) => (
                <div>
                  <strong style={{ color }}>
                    {datum.bin0} {t('to')} {datum.bin1}
                  </strong>
                  <div>
                    <strong>{t('count')} </strong>
                    {datum.count}
                  </div>
                  <div>
                    <strong>{t('cumulative')} </strong>
                    {datum.cumulative}
                  </div>
                  <div>
                    <strong>{t('percentile (exclusive)')} </strong>
                    {`${(
                      (datum.cumulativeDensity - datum.density) *
                      100
                    ).toPrecision(4)}th`}
                  </div>
                </div>
              )}
              valueAccessor={datum => datum}
              theme={chartTheme}
            >
              {data.map(series => (
                <BarSeries
                  key={series.key}
                  animated
                  rawData={series.values}
                  fill={colorScale(series.key)}
                  fillOpacity={opacity}
                />
              ))}
              <XAxis label={xAxisLabel} />
              <YAxis label={yAxisLabel} />
            </Histogram>
          )}
        />
      );
    }
  }