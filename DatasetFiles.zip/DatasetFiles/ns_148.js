export const MenuItemTooltip = ({
    title,
    color,
  }: {
    title: ReactNode;
    color?: string;
  }) => (
    <Tooltip title={title} placement="top">
      <Icons.InfoCircleOutlined
        data-test="tooltip-trigger"
        css={(theme: SupersetTheme) => css`
          color: ${color || theme.colors.text.label};
          margin-left: ${theme.gridUnit * 2}px;
          &.anticon {
            font-size: unset;
            .anticon {
              line-height: unset;
              vertical-align: unset;
            }
          }
        `}
      />
    </Tooltip>
  );