class Employee {
    constructor(name, role) {
        this.name = name;
        this.role = role;
    }

    getRole() {
        return this.role;
    }

    work() {
        console.log(`${this.name} is working as a ${this.role}`);
    }
}

class Manager extends Employee {
    constructor(name) {
        super(name, "Manager");
    }

    manage() {
        console.log(`${this.name} is managing employees.`);
    }
}

class Developer extends Employee {
    constructor(name) {
        super(name, "Developer");
    }

    code() {
        console.log(`${this.name} is writing code.`);
    }
}

const manager = new Manager("Alice");
manager.work();   // Output: Alice is working as a Manager
manager.manage(); // Output: Alice is managing employees.

const developer = new Developer("Bob");
developer.work(); // Output: Bob is working as a Developer
developer.code(); // Output: Bob is writing code.
