import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

const initialState = {
  target: null,
  targetId: null,
  items: [],
  isScrollLocked: false,
};

export class AnotherComponent extends PureComponent {
  static propTypes = {
    columnConfigurations: PropTypes.array,
    currentHighlightKey: PropTypes.any,
    hasMoreAfterEnd: PropTypes.bool,
    hasMoreBeforeStart: PropTypes.bool,
    highlightedItem: PropTypes.any,
    isLoadingMore: PropTypes.bool,
    isReloading: PropTypes.bool,
    isStreaming: PropTypes.bool,
    scale: PropTypes.string,
    wrap: PropTypes.bool,
    startDateExpression: PropTypes.any,
    endDateExpression: PropTypes.any,
    lastLoadedTime: PropTypes.any,
    updateDateRange: PropTypes.func.isRequired,
    startLiveStreaming: PropTypes.func.isRequired,
    onOpenLogEntryFlyout: PropTypes.func,
    setContextEntry: PropTypes.func,
  };

  constructor(props) {
    super(props);

    this.state = {
      ...initialState,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    const { items, isStreaming } = nextProps;
    const { target, isScrollLocked } = prevState;
    const hasItems = items.length > 0;
    const nextItems = hasItems && isScrollLocked ? prevState.items : items;
    let newState = null;

    if (isStreaming && hasItems) {
      newState = {
        target: nextProps.target,
        targetId: getStreamItemId(items[items.length - 1]),
        items: nextItems,
      };
    } else if (nextProps.target && nextProps.target !== target && hasItems) {
      newState = {
        target: nextProps.target,
        targetId: getStreamItemId(getStreamItemBeforeTimeKey(items, nextProps.target)),
        items: nextItems,
        isScrollLocked: false,
      };
    } else if (!hasItems) {
      newState = {
        target: null,
        targetId: null,
        items: [],
        isScrollLocked: false,
      };
    } else if (
      hasItems &&
      (nextItems.length !== prevState.items.length || nextItems[0] !== prevState.items[0])
    ) {
      newState = {
        ...prevState,
        items: nextItems,
        isScrollLocked: false,
      };
    }

    return newState;
  }

  // ... Rest of the component's code
}
