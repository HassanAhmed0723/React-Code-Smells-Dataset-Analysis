export class DashboardScene extends SceneObjectBase<DashboardSceneState> {
    public static Component = DashboardSceneRenderer;
  }