export const ButtonGallery = () => (
    <>
      {SIZES.options.map(size => (
        <div key={size} style={{ marginBottom: 40 }}>
          <h4>{size}</h4>
          {Object.values(STYLES.options).map(style => (
            <Button
              buttonStyle={style}
              buttonSize={size}
              onClick={() => true}
              key={`${style}_${size}`}
              style={{ marginRight: 20, marginBottom: 10 }}
            >
              {style}
            </Button>
          ))}
        </div>
      ))}
    </>
  );