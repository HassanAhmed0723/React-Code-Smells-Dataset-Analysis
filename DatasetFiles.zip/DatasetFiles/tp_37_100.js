export default function EchartsTreemap({
    echartOptions,
    emitCrossFilters,
    groupby,
    height,
    labelMap,
    onContextMenu,
    refs,
    setDataMask,
    selectedValues,
    width,
    formData,
    coltypeMapping,
  }: TreemapTransformedProps)