class Foo extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      tag: context.tag,
      className: this.context.className,
    };
  }

  render() {
    const Tag = this.state.tag;
    return <Tag className={this.state.className} />;
  }
}
