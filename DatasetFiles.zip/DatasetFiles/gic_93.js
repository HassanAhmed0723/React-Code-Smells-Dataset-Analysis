class Shape {
    constructor() {
      this.color = 'red';
    }
  
    draw() {
      console.log(`Drawing a shape with color ${this.color}`);
    }
  }
  
  class Circle extends Shape {
    constructor(radius) {
      super();
      this.radius = radius;
    }
  
    draw() {
      console.log(`Drawing a circle with radius ${this.radius} and color ${this.color}`);
    }
  }
  
  class Square extends Shape {
    constructor(sideLength) {
      super();
      this.sideLength = sideLength;
    }
  
    draw() {
      console.log(`Drawing a square with side length ${this.sideLength} and color ${this.color}`);
    }
  }
  
  const circle = new Circle(5);
  const square = new Square(4);
  
  circle.draw(); // Output: Drawing a circle with radius 5 and color red
  square.draw(); // Output: Drawing a square with side length 4 and color red
  