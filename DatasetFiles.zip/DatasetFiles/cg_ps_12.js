interface LiveLogsProps {
  logRows: LogRowModel[];
  isPaused: boolean;
  onPause: () => void;
  onResume: () => void;
  onClear: () => void;
  stopLive: () => void;
  theme: any;
  timeZone: string;
}

interface LiveLogsState {
  logRowsToRender: LogRowModel[];
}

class LiveLogs extends React.PureComponent<LiveLogsProps, LiveLogsState> {
  private liveEndDiv: HTMLDivElement | null = null;
  private scrollContainerRef = React.createRef<HTMLTableSectionElement>();

  constructor(props: LiveLogsProps) {
    super(props);
    this.state = {
      logRowsToRender: props.logRows,
    };
  }

  static getDerivedStateFromProps(nextProps: LiveLogsProps, state: LiveLogsState) {
    if (nextProps.isPaused && nextProps.clearedAtIndex) {
      return {
        logRowsToRender: filterLogRowsByIndex(nextProps.clearedAtIndex, state.logRowsToRender),
      };
    }

    if (nextProps.isPaused) {
      return null;
    }

    return {
      logRowsToRender: nextProps.logRows,
    };
  }

  onScroll = (event: React.SyntheticEvent) => {
    const { isPaused, onPause } = this.props;
    const { scrollTop, clientHeight, scrollHeight } = event.currentTarget;
    const distanceFromBottom = scrollHeight - (scrollTop + clientHeight);
    if (distanceFromBottom >= 5 && !isPaused) {
      onPause();
    }
  };

  rowsToRender = () => {
    const { isPaused } = this.props;
    let { logRowsToRender: rowsToRender = [] } = this.state;
    if (!isPaused) {
      rowsToRender = sortLogRows(rowsToRender, LogsSortOrder.Ascending).slice(-100);
    }
    return rowsToRender;
  };

  render() {
    const { theme, timeZone, onPause, onResume, onClear, isPaused } = this.props;

    return (
      <div>
        <table>
          <tbody
            onScroll={isPaused ? undefined : this.onScroll}
            ref={this.scrollContainerRef}
          >
            {this.rowsToRender().map((row: LogRowModel) => {
              return (
                <tr key={row.uid}>
                  <td>{dateTimeFormat(row.timeEpochMs, { timeZone })}</td>
                  <td>{row.hasAnsi ? <LogMessageAnsi value={row.raw} /> : row.entry}</td>
                </tr>
              );
            })}
            <tr
              ref={(element) => {
                this.liveEndDiv = element;
                if (this.liveEndDiv && this.scrollContainerRef.current?.scrollTo && !isPaused) {
                  this.scrollContainerRef.current?.scrollTo(0, this.scrollContainerRef.current.scrollHeight);
                }
              }}
            />
          </tbody>
        </table>
        <div>
          <button onClick={isPaused ? onResume : onPause}>
            {isPaused ? 'Resume' : 'Pause'}
          </button>
          <button onClick={onClear}>Clear logs</button>
          <button onClick={this.props.stopLive}>Exit live mode</button>
          {isPaused ||
            (this.rowsToRender().length > 0 && (
              <span>
                Last line received: <ElapsedTime resetKey={this.props.logRows} humanize={true} /> ago
              </span>
            ))}
        </div>
      </div>
    );
  }
}

export default LiveLogs;
