class ExtensionsRegistry extends TypedRegistry<Extensions> {
    name = 'ExtensionsRegistry';
  }