class Shape {
    constructor(type) {
      this.type = type;
    }
  
    draw() {
      console.log(`Drawing a ${this.type}`);
    }
  }
  
  class Circle extends Shape {
    constructor(radius) {
      super('circle');
      this.radius = radius;
    }
  
    draw() {
      console.log(`Drawing a circle with radius ${this.radius}`);
    }
  }
  
  class Square extends Shape {
    constructor(sideLength) {
      super('square');
      this.sideLength = sideLength;
    }
  
    draw() {
      console.log(`Drawing a square with side length ${this.sideLength}`);
    }
  }
  
  const circle = new Circle(5);
  const square = new Square(8);
  
  circle.draw();
  square.draw();
  