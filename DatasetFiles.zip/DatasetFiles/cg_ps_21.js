class CustomComponent extends React.Component {
  static propTypes = {
    prop1: PropTypes.string.isRequired,
    prop2: PropTypes.number.isRequired,
    prop3: PropTypes.bool,
    prop4: PropTypes.func,
  };

  static defaultProps = {
    prop3: true,
    prop4: () => {},
  };

  constructor(props) {
    super(props);
    this.state = {
      localState1: props.prop1,
      localState2: props.prop2,
      localState3: props.prop3,
    };
  }

  render() {
    return (
      <div>
        <h1>Component Rendering</h1>
        <p>Prop1: {this.props.prop1}</p>
        <p>Prop2: {this.props.prop2}</p>
        <p>Prop3: {this.props.prop3 ? 'true' : 'false'}</p>
        <p>Prop4: {typeof this.props.prop4 === 'function' ? 'Function' : 'Not a function'}</p>
        <p>Local State 1: {this.state.localState1}</p>
        <p>Local State 2: {this.state.localState2}</p>
        <p>Local State 3: {this.state.localState3 ? 'true' : 'false'}</p>
      </div>
    );
  }
}
