interface CustomDroppableProps {
  items: Array<Record<string, unknown>>;
  deleteOption: (id: string) => void;
  onEdit: (id: string) => void;
  renderComponent: (props: CustomRenderComponentProps) => React.ReactNode;
  toggleVisibility: () => void;
  updateCurrentFocusedInput: (id: string) => void;
  updateOption: (id: string, option: any) => void;
}

interface CustomRenderComponentProps {
  deleteOption: (id: string) => void;
  updateCurrentFocusedInput: (id: string) => void;
  updateOption: (id: string, option: any) => void;
  toggleVisibility: () => void;
  onEdit: (id: string) => void;
  item: { id: string } & any;
  index: number;
}

const CustomDroppableComponent: React.FC<CustomDroppableProps> = ({
  items,
  deleteOption,
  onEdit,
  renderComponent,
  toggleVisibility,
  updateCurrentFocusedInput,
  updateOption,
}) => {
  const [droppableItems, setDroppableItems] = useState<Array<Record<string, unknown>>>([]);

  useEffect(() => {
    setDroppableItems(items);
  }, [items]);

  const onDragEnd = (result: any) => {
    const { destination, source } = result;
    const newItems: Array<Record<string, unknown>> = [...droppableItems];
    const sourceIndex = source.index;
    let destinationIndex;
    if (!destination) {
      destinationIndex = newItems.length;
    } else {
      if (destination.droppableId === source.droppableId && destination.index === source.index) {
        return;
      }
      destinationIndex = destination.index;
    }
    newItems.splice(destinationIndex, 0, newItems[sourceIndex]);
    newItems.splice(sourceIndex + (destinationIndex < sourceIndex ? 1 : 0), 1);
    setDroppableItems(newItems);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <Droppable droppableId="droppable">
        {({ droppableProps, innerRef, placeholder }) => (
          <div ref={innerRef} {...droppableProps}>
            {droppableItems.map((item: { id: string } & any, index: number) => {
              return (
                <Draggable draggableId={item.id} index={index} key={item.id}>
                  {({ draggableProps, dragHandleProps, innerRef }) => (
                    <div
                      ref={innerRef}
                      {...draggableProps}
                      {...dragHandleProps}
                      style={{
                        ...draggableProps.style,
                        userSelect: "none",
                        position: "static",
                      }}
                    >
                      {renderComponent({
                        deleteOption,
                        updateCurrentFocusedInput,
                        updateOption,
                        toggleVisibility,
                        onEdit,
                        item,
                        index,
                      })}
                    </div>
                  )}
                </Draggable>
              );
            })}
            {placeholder}
          </div>
        )}
      </Droppable>
    </DragDropContext>
  );
};