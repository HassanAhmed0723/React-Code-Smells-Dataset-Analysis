export default React.memo(function SelectPageSize({
    total,
    options: sizeOptions,
    current: currentSize,
    selectRenderer,
    onChange,
  }: SelectPageSizeProps) {
    const sizeOptionValues = sizeOptions.map(getOptionValue);
    let options = [...sizeOptions];
    // insert current size to list
    if (
      currentSize !== undefined &&
      (currentSize !== total || !sizeOptionValues.includes(0)) &&
      !sizeOptionValues.includes(currentSize)
    ) {
      options = [...sizeOptions];
      options.splice(
        sizeOptionValues.findIndex(x => x > currentSize),
        0,
        formatSelectOptions([currentSize])[0],
      );
    }
    const current = currentSize === undefined ? sizeOptionValues[0] : currentSize;
    const SelectRenderer = selectRenderer || DefaultSelectRenderer;
    return (
      <SelectRenderer current={current} options={options} onChange={onChange} />
    );
  });