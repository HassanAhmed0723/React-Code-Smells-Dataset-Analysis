class TeamAnalytics extends React.PureComponent {
  static propTypes = {
    initialTeam: PropTypes.object,
    actions: PropTypes.shape({
      getTeams: PropTypes.func,
      setGlobalItem: PropTypes.func,
      getProfilesInTeam: PropTypes.func,
    }),
    stats: PropTypes.object,
    teams: PropTypes.arrayOf(PropTypes.object),
    locale: PropTypes.string,
    license: PropTypes.shape({
      Users: PropTypes.string,
      Cloud: PropTypes.string,
    }),
  };

  constructor(props) {
    super(props);

    this.state = {
      team: props.initialTeam,
      recentlyActiveUsers: [],
      newUsers: [],
    };
  }

  componentDidMount() {
    if (this.state.team) {
      this.getData(this.state.team.id);
    }

    this.props.actions.getTeams(0, 1000);
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.state.team && prevState.team !== this.state.team) {
      this.getData(this.state.team.id);
    }
  }

  getStatValue(stat) {
    if (typeof stat === 'number') {
      return stat;
    }
    if (!stat || stat.length === 0) {
      return undefined;
    }
    return stat[0].value;
  }

  getData = async (id) => {
    // Assuming AdminActions is defined somewhere
    AdminActions.getStandardAnalytics(id);
    AdminActions.getPostsPerDayAnalytics(id);
    AdminActions.getBotPostsPerDayAnalytics(id);
    AdminActions.getUsersPerDayAnalytics(id);
    const { data: recentlyActiveUsers } = await this.props.actions.getProfilesInTeam(
      id,
      0,
      General.PROFILE_CHUNK_SIZE,
      'last_activity_at'
    );
    const { data: newUsers } = await this.props.actions.getProfilesInTeam(
      id,
      0,
      General.PROFILE_CHUNK_SIZE,
      'create_at'
    );

    this.setState({
      recentlyActiveUsers,
      newUsers,
    });
  };

  handleTeamChange = (e) => {
    const teamId = e.target.value;

    let team;
    this.props.teams.forEach((t) => {
      if (t.id === teamId) {
        team = t;
      }
    });

    this.setState({
      team,
    });

    this.props.actions.setGlobalItem(LAST_ANALYTICS_TEAM, teamId);
  };

  render() {
  }
}

export default TeamAnalytics;
