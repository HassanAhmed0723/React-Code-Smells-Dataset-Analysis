export const InteractiveButton = (args: ButtonProps & { label: string }) => {
    const { label, ...btnArgs } = args;
    return <Button {...btnArgs}>{label}</Button>;
  };