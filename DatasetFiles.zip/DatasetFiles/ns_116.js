export const ControlHeader = ({
    children,
  }: ControlHeaderProps): JSX.Element => (
    <div className="ControlHeader">
      <div className="pull-left">{children}</div>
    </div>
  );