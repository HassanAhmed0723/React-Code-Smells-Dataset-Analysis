class ToggleFeature extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isEnabled: props.isEnabled,
    };
    this.toggleFeatureState = this.toggleFeatureState.bind(this);
  }

  toggleFeatureState(e) {
    const isChecked = e.target.checked;
    this.setState({ isEnabled: isChecked });
    this.props.toggleFeature(isChecked);
  }

  render() {
    return (
      <EuiFlexGroup>
        <EuiFlexItem grow={false}>
          <FormattedMessage
            id="toggleFeature.label"
            defaultMessage="Toggle Feature"
          />
        </EuiFlexItem>
        <EuiFlexItem>
          <EuiSwitch
            label={i18n.translate(
              'toggleFeature.toggleLabel',
              {
                defaultMessage: 'Toggle the feature on/off',
              }
            )}
            onChange={this.toggleFeatureState}
            checked={this.state.isEnabled}
            data-test-subj="featureToggleSwitch"
          />
        </EuiFlexItem>
      </EuiFlexGroup>
    );
  }
}
