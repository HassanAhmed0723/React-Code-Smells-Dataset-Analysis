const Row: FunctionComponent<ListChildComponentProps> = ({
    data,
    index,
    style,
  })