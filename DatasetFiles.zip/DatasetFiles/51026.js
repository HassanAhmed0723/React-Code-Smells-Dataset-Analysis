class Foo extends React.Component {
    constructor(props) {
      super(props);
      this.state = {bar: props.initialValue};
    }
    changeState() {
      this.setState({bar: 'bar'});
    }
    render() {
      if (this.state.bar === 'foo') {
        return <div className="foo" />;
      }
      return <span className={this.state.bar} />;
    }
  }
  const ref = React.createRef();
  test(<Foo initialValue="foo" ref={ref} />, 'DIV', 'foo');
  ReactDOM.flushSync(() => ref.current.changeState());
  test(<Foo />, 'SPAN', 'bar');