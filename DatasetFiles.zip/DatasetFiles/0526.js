export class ParameterMappingListInput extends React.Component {
    static propTypes = {
      mappings: PropTypes.arrayOf(PropTypes.object),
      existingParams: PropTypes.arrayOf(PropTypes.object),
      onChange: PropTypes.func,
    };
  
    static defaultProps = {
      mappings: [],
      existingParams: [],
      onChange: () => {},
    };
  
    static getStringValue(value) {
      // null
      if (!value) {
        return "";
      }
  
      // range
      if (value instanceof Object && "start" in value && "end" in value) {
        return `${value.start} ~ ${value.end}`;
      }
  
      // just to be safe, array or object
      if (typeof value === "object") {
        return map(value, v => this.getStringValue(v)).join(", ");
      }
  
      // rest
      return value.toString();
    }
  
    static getDefaultValue(mapping, existingParams) {
      const { type, mapTo, name } = mapping;
      let { param } = mapping;
  
      // if mapped to another param, swap 'em
      if (type === MappingType.DashboardMapToExisting && mapTo !== name) {
        const mappedTo = find(existingParams, { name: mapTo });
        if (mappedTo) {
          // just being safe
          param = mappedTo;
        }
  
        // static type is different since it's fed param.normalizedValue
      } else if (type === MappingType.StaticValue) {
        param = cloneParameter(param).setValue(mapping.value);
      }
  
      let value = Parameter.getExecutionValue(param);
  
      // in case of dynamic value display the name instead of value
      if (param.hasDynamicValue) {
        value = param.normalizedValue.name;
      }
  
      return this.getStringValue(value);
    }
  
    static getSourceTypeLabel({ type, mapTo }) {
      switch (type) {
        case MappingType.DashboardAddNew:
        case MappingType.DashboardMapToExisting:
          return (
            <Fragment>
              Dashboard <Tag className="tag">{mapTo}</Tag>
            </Fragment>
          );
        case MappingType.WidgetLevel:
          return "Widget parameter";
        case MappingType.StaticValue:
          return "Static value";
        default:
          return ""; // won't happen (typescript-ftw)
      }
    }
  
    updateParamMapping(oldMapping, newMapping) {
      const mappings = [...this.props.mappings];
      const index = findIndex(mappings, oldMapping);
      if (index >= 0) {
        // This should be the only possible case, but need to handle `else` too
        mappings[index] = newMapping;
      } else {
        mappings.push(newMapping);
      }
      this.props.onChange(mappings);
    }
  
    render() {
      const { existingParams } = this.props; // eslint-disable-line react/prop-types
      const dataSource = this.props.mappings.map(mapping => ({ mapping }));
  
      return (
        <div className="parameters-mapping-list">
          <Table dataSource={dataSource} size="middle" pagination={false} rowKey={(record, idx) => `row${idx}`}>
            <Table.Column
              title="Title"
              dataIndex="mapping"
              key="title"
              render={mapping => (
                <TitleEditor
                  existingParams={existingParams}
                  mapping={mapping}
                  onChange={newMapping => this.updateParamMapping(mapping, newMapping)}
                />
              )}
            />
            <Table.Column
              title="Keyword"
              dataIndex="mapping"
              key="keyword"
              className="keyword"
              render={mapping => <code>{`{{ ${mapping.name} }}`}</code>}
            />
            <Table.Column
              title="Default Value"
              dataIndex="mapping"
              key="value"
              render={mapping => this.constructor.getDefaultValue(mapping, this.props.existingParams)}
            />
            <Table.Column
              title="Value Source"
              dataIndex="mapping"
              key="source"
              render={mapping => {
                const existingParamsNames = existingParams
                  .filter(({ type }) => type === mapping.param.type) // exclude mismatching param types
                  .map(({ name }) => name); // keep names only
  
                return (
                  <Fragment>
                    {this.constructor.getSourceTypeLabel(mapping)}{" "}
                    <MappingEditor
                      mapping={mapping}
                      existingParamNames={existingParamsNames}
                      onChange={(oldMapping, newMapping) => this.updateParamMapping(oldMapping, newMapping)}
                    />
                  </Fragment>
                );
              }}
            />
          </Table>
        </div>
      );
    }
  }
  