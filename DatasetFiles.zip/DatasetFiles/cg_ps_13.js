interface Props<T> {
  initialSubProps: T;
  watch: Observable<T>;
  child: React.ComponentType<T>;
}

interface State<T> {
  subProps: T;
}

export class ObservablePropsWrapper<T extends {}> extends React.Component<Props<T>, State<T>> {
  sub?: Unsubscribable;

  constructor(props: Props<T>) {
    super(props);
    this.state = {
      subProps: props.initialSubProps,
    };
  }

  componentDidMount() {
    this.sub = this.props.watch.subscribe({
      next: (subProps: T) => {
        this.setState({ subProps });
      },
      complete: () => {},
      error: (err) => {},
    });
  }

  componentWillUnmount() {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }

  render() {
    const { subProps } = this.state;
    const ChildComponent = this.props.child;
    return <ChildComponent {...subProps} />;
  }
}
