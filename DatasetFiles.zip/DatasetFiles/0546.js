static getDerivedStateFromProps(props: Props, state: State): Partial<State> {
    let updatedState: Partial<State> = {
        currentChannel: props.currentChannel,
    };
    if (
        props.currentChannel.id !== state.currentChannel.id ||
        (props.isRemoteDraft && props.draft.message !== state.message)
    ) {
        updatedState = {
            ...updatedState,
            message: props.draft.message,
            submitting: false,
            serverError: null,
        };
    }
    return updatedState;
}

constructor(props: Props) {
    super(props);
    this.state = {
        message: props.draft.message,
        caretPosition: props.draft.message.length,
        submitting: false,
        showEmojiPicker: false,
        uploadsProgressPercent: {},
        renderScrollbar: false,
        scrollbarWidth: 0,
        currentChannel: props.currentChannel,
        errorClass: null,
        serverError: null,
        showFormat: false,
        isFormattingBarHidden: props.isFormattingBarHidden,
        showPostPriorityPicker: false,
    };

    this.topDiv = React.createRef<HTMLFormElement>();
    this.textboxRef = React.createRef<TextboxClass>();
    this.fileUploadRef = React.createRef<FileUploadClass>();
}

componentDidMount() {
    const {actions} = this.props;
    this.onOrientationChange();
    actions.setShowPreview(false);
    actions.clearDraftUploads();
    this.focusTextbox();
    document.addEventListener('paste', this.pasteHandler);
    document.addEventListener('keydown', this.documentKeyHandler);
    window.addEventListener('beforeunload', this.unloadHandler);
    this.setOrientationListeners();
    this.getChannelMemberCountsByGroup();
}

componentDidUpdate(prevProps: Props, prevState: State) {
    const {currentChannel, actions} = this.props;
    if (prevProps.currentChannel.id !== currentChannel.id) {
        this.lastChannelSwitchAt = Date.now();
        this.focusTextbox();
        this.saveDraftWithShow(prevProps);
        this.getChannelMemberCountsByGroup();
    }

    if (currentChannel.id !== prevProps.currentChannel.id) {
        actions.setShowPreview(false);
    }

    // Focus on textbox when emoji picker is closed
    if (prevState.showEmojiPicker && !this.state.showEmojiPicker) {
        this.focusTextbox();
    }

    // Focus on textbox when returned from preview mode
    if (prevProps.shouldShowPreview && !this.props.shouldShowPreview) {
        this.focusTextbox();
    }
}

componentWillUnmount() {
    document.removeEventListener('paste', this.pasteHandler);
    document.removeEventListener('keydown', this.documentKeyHandler);
    window.removeEventListener('beforeunload', this.unloadHandler);
    this.removeOrientationListeners();
    this.saveDraftWithShow();
}

getChannelMemberCountsByGroup = () => {
    const {useLDAPGroupMentions, useCustomGroupMentions, currentChannel, isTimezoneEnabled, actions, draft} = this.props;

    if ((useLDAPGroupMentions || useCustomGroupMentions) && currentChannel.id) {
        const mentions = mentionsMinusSpecialMentionsInText(draft.message);

        if (mentions.length === 1) {
            actions.searchAssociatedGroupsForReference(mentions[0], this.props.currentTeamId, currentChannel.id);
        } else if (mentions.length > 1) {
            actions.getChannelMemberCountsByGroup(currentChannel.id, isTimezoneEnabled);
        }
    }
};

unloadHandler = () => {
    this.saveDraftWithShow();
};

saveDraftWithShow = (props = this.props) => {
    if (this.saveDraftFrame && props.currentChannel) {
        const channelId = props.currentChannel.id;
        const draft = this.draftsForChannel[channelId];

        if (draft) {
            this.draftsForChannel[channelId] = {
                ...draft,
                show: !isDraftEmpty(draft),
            } as PostDraft;
        }
    }

    this.saveDraft(props, true);
};
