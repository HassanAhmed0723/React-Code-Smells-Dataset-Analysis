class MainPreset extends Preset {
    constructor() {
      super({
        name: 'Legacy charts',
        plugins: [
          new SelectFilterPlugin().configure({ key: 'filter_select' }),
          new RangeFilterPlugin().configure({ key: 'filter_range' }),
          new TimeFilterPlugin().configure({ key: 'filter_time' }),
          new TimeColumnFilterPlugin().configure({ key: 'filter_timecolumn' }),
          new TimeGrainFilterPlugin().configure({ key: 'filter_timegrain' }),
        ],
      });
    }
  }