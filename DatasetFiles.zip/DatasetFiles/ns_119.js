const HandlebarsTemplateControl = (
    props: CustomControlConfig<HandlebarsCustomControlProps>,
  ) => {
    const val = String(
      props?.value ? props?.value : props?.default ? props?.default : '',
    );
  
    return (
      <div>
        <ControlHeader>{props.label}</ControlHeader>
        <CodeEditor
          theme="dark"
          value={val}
          onChange={source => {
            debounceFunc(props.onChange, source || '');
          }}
        />
      </div>
    );
  };