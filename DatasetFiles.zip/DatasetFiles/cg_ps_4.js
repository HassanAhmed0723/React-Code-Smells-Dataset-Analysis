class Markdown extends React.PureComponent {
    constructor(props) {
      super(props);
      this.state = {
        isFocused: false,
        markdownSource: props.component.meta.code,
        editor: null,
        editorMode: 'preview',
        undoLength: props.undoLength,
        redoLength: props.redoLength,
        data: props.data,
      };
  
      // Rest of the component's code
    }
  
    render() {
      const { isFocused, markdownSource, editorMode, undoLength, redoLength, data } = this.state;
  
      <SafeMarkdown
        source={
          hasError
            ? MARKDOWN_ERROR_MESSAGE
            : this.state.markdownSource || MARKDOWN_PLACE_HOLDER
        }
        htmlSanitization={this.props.htmlSanitization}
        htmlSchemaOverrides={this.props.htmlSchemaOverrides}
      />
    }
  }
  