class Animal {
    constructor(name) {
      this.name = name;
    }
  
    speak() {
      console.log(`${this.name} makes a sound.`);
    }
  }
  
  class Dog extends Animal {
    constructor(name, breed) {
      super(name);
      this.breed = breed;
    }
  
    speak() {
      console.log(`${this.name} barks loudly.`);
    }
  
    fetch() {
      console.log(`${this.name} is fetching the ball.`);
    }
  }
  
  class Cat extends Animal {
    constructor(name, color) {
      super(name);
      this.color = color;
    }
  
    speak() {
      console.log(`${this.name} meows softly.`);
    }
  
    nap() {
      console.log(`${this.name} is taking a nap.`);
    }
  }
  
  const dog = new Dog('Buddy', 'Golden Retriever');
  const cat = new Cat('Whiskers', 'Calico');
  
  dog.speak();
  dog.fetch();
  
  cat.speak();
  cat.nap();
  