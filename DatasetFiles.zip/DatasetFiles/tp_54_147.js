export default function DatabaseSelector({
    db,
    formMode = false,
    emptyState,
    getDbList,
    handleError,
    isDatabaseSelectEnabled = true,
    onDbChange,
    onEmptyResults,
    onSchemaChange,
    readOnly = false,
    schema,
    sqlLabMode = false,
  }: DatabaseSelectorProps)