class EditNamePopover extends Component {
  static displayName = 'EditNamePopover';
  static propTypes = {
    name: PropTypes.string,
    updateName: PropTypes.func.isRequired,
    canEditName: PropTypes.bool.isRequired,
  };

  constructor(props) {
    super(props);

    this.state = {
      isPopoverOpen: false,
      value: props.name,
    };
  }

  onChange = (e) => {
    this.setState({
      value: e.target.value,
    });
  };

  onButtonClick = () => {
    if (this.state.isPopoverOpen === false) {
      this.setState({
        isPopoverOpen: !this.state.isPopoverOpen,
        value: this.props.name,
      });
    } else {
      this.closePopover();
    }
  };

  closePopover = () => {
    if (this.state.isPopoverOpen === true) {
      this.setState({
        isPopoverOpen: false,
      });
      this.props.updateName(this.state.value);
    }
  };

  render() {
    const { isPopoverOpen, value } = this.state;

    const button = (
      <EuiButtonIcon
        size="s"
        color="primary"
        onClick={this.onButtonClick}
        iconType="pencil"
        aria-label={i18n.translate('editNamePopover.editNameAriaLabel', {
          defaultMessage: 'Edit name',
        })}
        isDisabled={this.props.canEditName === false}
        data-test-subj="editNamePopoverButton"
      />
    );

    return (
      <div>
        <EuiPopover
          id="edit_name_popover"
          ownFocus
          button={button}
          isOpen={isPopoverOpen}
          closePopover={this.closePopover}
          initialFocus="#edit_name_input"
        >
          <div style={{ width: '300px' }}>
            <EuiForm>
              <EuiFormRow
                id="edit_name_row"
                label={i18n.translate('editNamePopover.nameLabel', {
                  defaultMessage: 'Name',
                })}
              >
                <EuiFieldText
                  id="edit_name_input"
                  name="edit_name"
                  value={value}
                  onChange={this.onChange}
                  data-test-subj="editNameInput"
                />
              </EuiFormRow>
            </EuiForm>
          </div>
        </EuiPopover>
      </div>
    );
  }
}
