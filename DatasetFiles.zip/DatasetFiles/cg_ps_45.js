export function createStatefulPropHoc(fieldName, updater = 'updateValue') {
  return (Comp) => {
    class WrappedControlledInput extends React.PureComponent {
      constructor(props) {
        super(props);

        this.state = {
          [fieldName]: props[fieldName],
        };
      }

      UNSAFE_componentWillReceiveProps(nextProps) {
        this.setState({ [fieldName]: nextProps[fieldName] });
      }

      handleChange = (ev) => {
        if (ev.target) {
          this.setState({ [fieldName]: ev.target.value });
        } else {
          this.setState({ [fieldName]: ev });
        }
      };

      render() {
        const passedProps = {
          ...this.props,
          [fieldName]: this.state[fieldName],
          [updater]: this.handleChange,
        };

        return <Comp {...passedProps} />;
      }
    }

    WrappedControlledInput.propTypes = {
      [fieldName]: PropTypes.any,
    };

    WrappedControlledInput.displayName = `statefulProp(${getDisplayName(Comp)})`;

    return WrappedControlledInput;
  };
}
