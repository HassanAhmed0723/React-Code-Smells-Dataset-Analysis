export const InteractiveCopyToClipboard = ({ copyNode, ...rest }: any) => {
    const theme = useTheme();
    let node = <Button>Copy</Button>;
    if (copyNode === 'Icon') {
      node = <Icons.Copy iconColor={theme.colors.grayscale.base} />;
    } else if (copyNode === 'Text') {
      node = <span role="button">Copy</span>;
    }
    return (
      <>
        <CopyToClipboard copyNode={node} {...rest} />
        <ToastContainer />
      </>
    );
  };