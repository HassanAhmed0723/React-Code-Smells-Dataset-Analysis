class TooltipFrame extends PureComponent<Props, {}> {
    static defaultProps = defaultProps;
  
    render() {
      const { className, children } = this.props;
  
      return (
        <div className={className} style={CONTAINER_STYLE}>
          {children}
        </div>
      );
    }
  }