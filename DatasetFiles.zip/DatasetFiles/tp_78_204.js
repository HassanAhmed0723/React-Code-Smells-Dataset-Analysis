const DashboardBuilder: FC<DashboardBuilderProps> = () => {
    const dispatch = useDispatch();
    const uiConfig = useUiConfig();
    const theme = useTheme();
  
    const dashboardId = useSelector<RootState, string>(
      ({ dashboardInfo }) => `${dashboardInfo.id}`,
    );
    const dashboardLayout = useSelector<RootState, DashboardLayout>(
      state => state.dashboardLayout.present,
    );
    const editMode = useSelector<RootState, boolean>(
      state => state.dashboardState.editMode,
    );
    const canEdit = useSelector<RootState, boolean>(
      ({ dashboardInfo }) => dashboardInfo.dash_edit_perm,
    );
    const dashboardIsSaving = useSelector<RootState, boolean>(
      ({ dashboardState }) => dashboardState.dashboardIsSaving,
    );
    const fullSizeChartId = useSelector<RootState, number | null>(
      state => state.dashboardState.fullSizeChartId,
    );
    const crossFiltersEnabled = isFeatureEnabled(
      FeatureFlag.DASHBOARD_CROSS_FILTERS,
    );
    const filterBarOrientation = useSelector<RootState, FilterBarOrientation>(
      ({ dashboardInfo }) =>
        isFeatureEnabled(FeatureFlag.HORIZONTAL_FILTER_BAR)
          ? dashboardInfo.filterBarOrientation
          : FilterBarOrientation.VERTICAL,
    );
  
    const handleChangeTab = useCallback(
      ({ pathToTabIndex }: { pathToTabIndex: string[] }) => {
        dispatch(setDirectPathToChild(pathToTabIndex));
      },
      [dispatch],
    );
  
    const handleDeleteTopLevelTabs = useCallback(() => {
      dispatch(deleteTopLevelTabs());
  
      const firstTab = getDirectPathToTabIndex(
        getRootLevelTabsComponent(dashboardLayout),
        0,
      );
      dispatch(setDirectPathToChild(firstTab));
    }, [dashboardLayout, dispatch]);
  
    const handleDrop = useCallback(
      dropResult => dispatch(handleComponentDrop(dropResult)),
      [dispatch],
    );
  
    const headerRef = React.useRef<HTMLDivElement>(null);
    const dashboardRoot = dashboardLayout[DASHBOARD_ROOT_ID];
    const rootChildId = dashboardRoot?.children[0];
    const topLevelTabs =
      rootChildId !== DASHBOARD_GRID_ID
        ? dashboardLayout[rootChildId]
        : undefined;
    const standaloneMode = getUrlParam(URL_PARAMS.standalone);
    const isReport = standaloneMode === DashboardStandaloneMode.REPORT;
    const hideDashboardHeader =
      uiConfig.hideTitle ||
      standaloneMode === DashboardStandaloneMode.HIDE_NAV_AND_TITLE ||
      isReport;
  
    const [barTopOffset, setBarTopOffset] = useState(0);
  
    useEffect(() => {
      setBarTopOffset(headerRef.current?.getBoundingClientRect()?.height || 0);
  
      let observer: ResizeObserver;
      if (global.hasOwnProperty('ResizeObserver') && headerRef.current) {
        observer = new ResizeObserver(entries => {
          setBarTopOffset(
            current => entries?.[0]?.contentRect?.height || current,
          );
        });
  
        observer.observe(headerRef.current);
      }
  
      return () => {
        observer?.disconnect();
      };
    }, []);
  
    const {
      showDashboard,
      dashboardFiltersOpen,
      toggleDashboardFiltersOpen,
      nativeFiltersEnabled,
    } = useNativeFilters();
  
    const [containerRef, isSticky] = useElementOnScreen<HTMLDivElement>({
      threshold: [1],
    });
  
    const filterSetEnabled = isFeatureEnabled(
      FeatureFlag.DASHBOARD_NATIVE_FILTERS_SET,
    );
    const showFilterBar =
      (crossFiltersEnabled || nativeFiltersEnabled) && !editMode;
  
    const offset =
      FILTER_BAR_HEADER_HEIGHT +
      (isSticky || standaloneMode ? 0 : MAIN_HEADER_HEIGHT) +
      (filterSetEnabled ? FILTER_BAR_TABS_HEIGHT : 0);
  
    const filterBarHeight = `calc(100vh - ${offset}px)`;
    const filterBarOffset = dashboardFiltersOpen ? 0 : barTopOffset + 20;
  
    const draggableStyle = useMemo(
      () => ({
        marginLeft:
          dashboardFiltersOpen ||
          editMode ||
          !nativeFiltersEnabled ||
          filterBarOrientation === FilterBarOrientation.HORIZONTAL
            ? 0
            : -32,
      }),
      [
        dashboardFiltersOpen,
        editMode,
        filterBarOrientation,
        nativeFiltersEnabled,
      ],
    );
  
    // If a new tab was added, update the directPathToChild to reflect it
    const currentTopLevelTabs = useRef(topLevelTabs);
    useEffect(() => {
      const currentTabsLength = currentTopLevelTabs.current?.children?.length;
      const newTabsLength = topLevelTabs?.children?.length;
  
      if (
        currentTabsLength !== undefined &&
        newTabsLength !== undefined &&
        newTabsLength > currentTabsLength
      ) {
        const lastTab = getDirectPathToTabIndex(
          getRootLevelTabsComponent(dashboardLayout),
          newTabsLength - 1,
        );
        dispatch(setDirectPathToChild(lastTab));
      }
  
      currentTopLevelTabs.current = topLevelTabs;
    }, [topLevelTabs]);
  
    const renderDraggableContent = useCallback(
      ({ dropIndicatorProps }: { dropIndicatorProps: JsonObject }) => (
        <div>
          {!hideDashboardHeader && <DashboardHeader />}
          {showFilterBar &&
            filterBarOrientation === FilterBarOrientation.HORIZONTAL && (
              <FilterBar
                orientation={FilterBarOrientation.HORIZONTAL}
                hidden={isReport}
              />
            )}
          {dropIndicatorProps && <div {...dropIndicatorProps} />}
          {!isReport && topLevelTabs && !uiConfig.hideNav && (
            <WithPopoverMenu
              shouldFocus={shouldFocusTabs}
              menuItems={[
                <IconButton
                  icon={<Icons.FallOutlined iconSize="xl" />}
                  label={t('Collapse tab content')}
                  onClick={handleDeleteTopLevelTabs}
                />,
              ]}
              editMode={editMode}
            >
              {/* @ts-ignore */}
              <DashboardComponent
                id={topLevelTabs?.id}
                parentId={DASHBOARD_ROOT_ID}
                depth={DASHBOARD_ROOT_DEPTH + 1}
                index={0}
                renderTabContent={false}
                renderHoverMenu={false}
                onChangeTab={handleChangeTab}
              />
            </WithPopoverMenu>
          )}
        </div>
      ),
      [
        nativeFiltersEnabled,
        filterBarOrientation,
        editMode,
        handleChangeTab,
        handleDeleteTopLevelTabs,
        hideDashboardHeader,
        isReport,
        topLevelTabs,
        uiConfig.hideNav,
      ],
    );
  
    const dashboardContentMarginLeft =
      !dashboardFiltersOpen &&
      !editMode &&
      nativeFiltersEnabled &&
      filterBarOrientation !== FilterBarOrientation.HORIZONTAL
        ? 0
        : theme.gridUnit * 8;
  
    return (
      <StyledDiv>
        {showFilterBar && filterBarOrientation === FilterBarOrientation.VERTICAL && (
          <>
            <ResizableSidebar
              id={`dashboard:${dashboardId}`}
              enable={dashboardFiltersOpen}
              minWidth={OPEN_FILTER_BAR_WIDTH}
              maxWidth={OPEN_FILTER_BAR_MAX_WIDTH}
              initialWidth={OPEN_FILTER_BAR_WIDTH}
            >
              {adjustedWidth => {
                const filterBarWidth = dashboardFiltersOpen
                  ? adjustedWidth
                  : CLOSED_FILTER_BAR_WIDTH;
                return (
                  <FiltersPanel
                    width={filterBarWidth}
                    hidden={isReport}
                    data-test="dashboard-filters-panel"
                  >
                    <StickyPanel ref={containerRef} width={filterBarWidth}>
                      <ErrorBoundary>
                        <FilterBar
                          orientation={FilterBarOrientation.VERTICAL}
                          verticalConfig={{
                            filtersOpen: dashboardFiltersOpen,
                            toggleFiltersBar: toggleDashboardFiltersOpen,
                            width: filterBarWidth,
                            height: filterBarHeight,
                            offset: filterBarOffset,
                          }}
                        />
                      </ErrorBoundary>
                    </StickyPanel>
                  </FiltersPanel>
                );
              }}
            </ResizableSidebar>
          </>
        )}
        <StyledHeader ref={headerRef}>
          {/* @ts-ignore */}
          <DragDroppable
            data-test="top-level-tabs"
            component={dashboardRoot}
            parentComponent={null}
            depth={DASHBOARD_ROOT_DEPTH}
            index={0}
            orientation="column"
            onDrop={handleDrop}
            editMode={editMode}
            // you cannot drop on/displace tabs if they already exist
            disableDragDrop={!!topLevelTabs}
            style={draggableStyle}
          >
            {renderDraggableContent}
          </DragDroppable>
        </StyledHeader>
        <StyledContent fullSizeChartId={fullSizeChartId}>
          <Global
            styles={css`
              // @z-index-above-dashboard-header (100) + 1 = 101
              ${fullSizeChartId &&
              `div > .filterStatusPopover.ant-popover{z-index: 101}`}
            `}
          />
          {!editMode &&
            !topLevelTabs &&
            dashboardLayout[DASHBOARD_GRID_ID]?.children?.length === 0 && (
              <EmptyStateBig
                title={t('There are no charts added to this dashboard')}
                description={
                  canEdit &&
                  t(
                    'Go to the edit mode to configure the dashboard and add charts',
                  )
                }
                buttonText={canEdit && t('Edit the dashboard')}
                buttonAction={() => dispatch(setEditMode(true))}
                image="dashboard.svg"
              />
            )}
          <DashboardContentWrapper
            data-test="dashboard-content-wrapper"
            className={cx('dashboard', editMode && 'dashboard--editing')}
          >
            <StyledDashboardContent
              className="dashboard-content"
              editMode={editMode}
              marginLeft={dashboardContentMarginLeft}
            >
              {showDashboard ? (
                <DashboardContainer topLevelTabs={topLevelTabs} />
              ) : (
                <Loading />
              )}
              {editMode && <BuilderComponentPane topOffset={barTopOffset} />}
            </StyledDashboardContent>
          </DashboardContentWrapper>
        </StyledContent>
        {dashboardIsSaving && (
          <Loading
            css={css`
              && {
                position: fixed;
              }
            `}
          />
        )}
      </StyledDiv>
    );
  };