class Animal {
    constructor(name) {
      this.name = name;
    }
  
    makeSound() {
      console.log(`${this.name} makes a sound.`);
    }
  }
  
  class Dog extends Animal {
    constructor(name, breed) {
      super(name);
      this.breed = breed;
    }
  
    makeSound() {
      console.log(`${this.name} barks loudly.`);
    }
  
    fetch() {
      console.log(`${this.name} is fetching the ball.`);
    }
  }
  
  class Cat extends Animal {
    constructor(name, color) {
      super(name);
      this.color = color;
    }
  
    makeSound() {
      console.log(`${this.name} meows softly.`);
    }
  
    climbTree() {
      console.log(`${this.name} is climbing a tree.`);
    }
  }
  
  const dog = new Dog('Buddy', 'Golden Retriever');
  const cat = new Cat('Whiskers', 'Gray');
  
  dog.makeSound();
  dog.fetch();
  
  cat.makeSound();
  cat.climbTree();
  