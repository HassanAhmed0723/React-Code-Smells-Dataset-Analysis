function ClientApp({serverModel}) {
    return (
      <>
        {serverModel}
        <ClientBaz />
      </>
    );
  }