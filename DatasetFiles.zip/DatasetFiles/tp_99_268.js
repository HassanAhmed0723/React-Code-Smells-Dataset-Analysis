const MockModal = ({ scope }: { scope?: object }) => {
    const [newForm] = AntdForm.useForm<NativeFiltersForm>();
    form = newForm;
    if (scope) {
      form.setFieldsValue({
        filters: {
          [mockedProps.filterId]: {
            scope,
          },
        },
      });
    }
    return (
      <Provider store={mockStoreWithChartsInTabsAndRoot}>
        <AntdForm form={form}>
          <FiltersConfigForm form={form} {...mockedProps} />
        </AntdForm>
      </Provider>
    );
  };
