class Foo extends React.Component {
    constructor(props, context) {
      super(props, context);
      this.state = {tag: context.tag, className: this.context.className};
    }