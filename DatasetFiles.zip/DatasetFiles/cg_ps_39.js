class CustomToastWrapper extends React.PureComponent<Props, State> {
    static defaultProps = {
        unreadCountInChannel: 0,
    };

    constructor(props: Props) {
        super(props);
        this.state = {
            unreadCountInChannel: props.unreadCountInChannel,
            unreadCount: 0,
            showUnreadToast: false,
            showNewMessagesToast: false,
            showMessageHistoryToast: false,
            showUnreadWithBottomStartToast: false,
            lastViewedAt: props.lastViewedAt,
            atBottom: props.atBottom,
            channelMarkedAsUnread: false,
        };
    }

    render() {
        const toastToRender = this.getToastToRender();

        return (
            <React.Fragment>
                {toastToRender}
            </React.Fragment>
        );
    }
}
