function ExploreViewContainer(props) {
    const dynamicPluginContext = usePluginContext();
    const dynamicPlugin = dynamicPluginContext.dynamicPlugins[props.vizType];
    const isDynamicPluginLoading = dynamicPlugin && dynamicPlugin.mounting;
    const wasDynamicPluginLoading = usePrevious(isDynamicPluginLoading);
  
    /** the state of controls in the previous render */
    const previousControls = usePrevious(props.controls);
    /** the state of controls last time a query was triggered */
    const [lastQueriedControls, setLastQueriedControls] = useState(
      props.controls,
    );
  
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [shouldForceUpdate, setShouldForceUpdate] = useState(-1);
    const tabId = useTabId();
  
    const theme = useTheme();
  
    const defaultSidebarsWidth = {
      controls_width: 320,
      datasource_width: 300,
    };
  
    const addHistory = useCallback(
      async ({ isReplace = false, title } = {}) => {
        const formData = props.dashboardId
          ? {
              ...props.form_data,
              dashboardId: props.dashboardId,
            }
          : props.form_data;
        const { id: datasourceId, type: datasourceType } = props.datasource;
  
        updateHistory(
          formData,
          datasourceId,
          datasourceType,
          isReplace,
          props.standalone,
          props.force,
          title,
          tabId,
        );
      },
      [
        props.dashboardId,
        props.form_data,
        props.datasource.id,
        props.datasource.type,
        props.standalone,
        props.force,
        tabId,
      ],
    );