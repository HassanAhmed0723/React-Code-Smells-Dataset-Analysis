function TimeoutErrorMessage({
    error,
    source,
  }: ErrorMessageComponentProps<TimeoutErrorExtra>) {
    const { extra, level } = error;
  
    const isVisualization = (
      ['dashboard', 'explore'] as (string | undefined)[]
    ).includes(source);
  
    const subtitle = isVisualization
      ? tn(
          'Weâ€™re having trouble loading this visualization. Queries are set to timeout after %s second.',
          'Weâ€™re having trouble loading this visualization. Queries are set to timeout after %s seconds.',
          extra.timeout,
          extra.timeout,
        )
      : tn(
          'Weâ€™re having trouble loading these results. Queries are set to timeout after %s second.',
          'Weâ€™re having trouble loading these results. Queries are set to timeout after %s seconds.',
          extra.timeout,
          extra.timeout,
        );
  
    const body = (
      <>
        <p>
          {t('This may be triggered by:')}
          <br />
          {extra.issue_codes
            .map<React.ReactNode>(issueCode => <IssueCode {...issueCode} />)
            .reduce((prev, curr) => [prev, <br />, curr])}
        </p>
        {isVisualization && extra.owners && (
          <>
            <br />
            <p>
              {tn(
                'Please reach out to the Chart Owner for assistance.',
                'Please reach out to the Chart Owners for assistance.',
                extra.owners.length,
              )}
            </p>
            <p>
              {tn(
                'Chart Owner: %s',
                'Chart Owners: %s',
                extra.owners.length,
                extra.owners.join(', '),
              )}
            </p>
          </>
        )}
      </>
    );
  
    const copyText = t('%(subtitle)s\nThis may be triggered by:\n %(issue)s', {
      subtitle,
      issue: extra.issue_codes.map(issueCode => issueCode.message).join('\n'),
    });
  
    return (
      <ErrorAlert
        title={t('Timeout error')}
        subtitle={subtitle}
        level={level}
        source={source}
        copyText={copyText}
        body={body}
      />
    );
  }