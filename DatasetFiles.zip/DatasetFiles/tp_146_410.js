function DashboardTable({
    user,
    addDangerToast,
    addSuccessToast,
    mine,
    showThumbnails,
    otherTabData,
    otherTabFilters,
    otherTabTitle,
  }: DashboardTableProps)