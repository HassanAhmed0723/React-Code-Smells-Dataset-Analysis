class WillMount extends React.Component {
    state = {};
    static getDerivedStateFromProps() {
      return null;
    }
    UNSAFE_componentWillMount() {}
    render() {
      return null;
    }
  }

  expect(() => ReactDOM.render(<WillMount />, container)).toErrorDev(
    'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
      'WillMount uses getDerivedStateFromProps() but also contains the following legacy lifecycles:\n' +
      '  UNSAFE_componentWillMount\n\n' +
      'The above lifecycles should be removed. Learn more about this warning here:\n' +
      'https://reactjs.org/link/unsafe-component-lifecycles',
  );

  class WillMountAndUpdate extends React.Component {
    state = {};
    static getDerivedStateFromProps() {
      return null;
    }
    componentWillMount() {}
    UNSAFE_componentWillUpdate() {}
    render() {
      return null;
    }
  }

  expect(() => {
    expect(() =>
      ReactDOM.render(<WillMountAndUpdate />, container),
    ).toErrorDev(
      'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
        'WillMountAndUpdate uses getDerivedStateFromProps() but also contains the following legacy lifecycles:\n' +
        '  componentWillMount\n' +
        '  UNSAFE_componentWillUpdate\n\n' +
        'The above lifecycles should be removed. Learn more about this warning here:\n' +
        'https://reactjs.org/link/unsafe-component-lifecycles',
    );
  }).toWarnDev(['componentWillMount has been renamed'], {
    withoutStack: true,
  });

  class WillReceiveProps extends React.Component {
    state = {};
    static getDerivedStateFromProps() {
      return null;
    }
    componentWillReceiveProps() {}
    render() {
      return null;
    }
  }

  expect(() => {
    expect(() => ReactDOM.render(<WillReceiveProps />, container)).toErrorDev(
      'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
        'WillReceiveProps uses getDerivedStateFromProps() but also contains the following legacy lifecycles:\n' +
        '  componentWillReceiveProps\n\n' +
        'The above lifecycles should be removed. Learn more about this warning here:\n' +
        'https://reactjs.org/link/unsafe-component-lifecycles',
    );
  }).toWarnDev(['componentWillReceiveProps has been renamed'], {
    withoutStack: true,
  });
});

it('should warn about deprecated lifecycles (cWM/cWRP/cWU) if new getSnapshotBeforeUpdate is present', () => {
  const container = document.createElement('div');

  class AllLegacyLifecycles extends React.Component {
    state = {};
    getSnapshotBeforeUpdate() {}
    componentWillMount() {}
    UNSAFE_componentWillReceiveProps() {}
    componentWillUpdate() {}
    componentDidUpdate() {}
    render() {
      return null;
    }
  }

  expect(() => {
    expect(() =>
      ReactDOM.render(<AllLegacyLifecycles />, container),
    ).toErrorDev(
      'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
        'AllLegacyLifecycles uses getSnapshotBeforeUpdate() but also contains the following legacy lifecycles:\n' +
        '  componentWillMount\n' +
        '  UNSAFE_componentWillReceiveProps\n' +
        '  componentWillUpdate\n\n' +
        'The above lifecycles should be removed. Learn more about this warning here:\n' +
        'https://reactjs.org/link/unsafe-component-lifecycles',
    );
  }).toWarnDev(
    [
      'componentWillMount has been renamed',
      'componentWillUpdate has been renamed',
    ],
    {withoutStack: true},
  );

  class WillMount extends React.Component {
    state = {};
    getSnapshotBeforeUpdate() {}
    UNSAFE_componentWillMount() {}
    componentDidUpdate() {}
    render() {
      return null;
    }
  }

  expect(() => ReactDOM.render(<WillMount />, container)).toErrorDev(
    'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
      'WillMount uses getSnapshotBeforeUpdate() but also contains the following legacy lifecycles:\n' +
      '  UNSAFE_componentWillMount\n\n' +
      'The above lifecycles should be removed. Learn more about this warning here:\n' +
      'https://reactjs.org/link/unsafe-component-lifecycles',
  );

  class WillMountAndUpdate extends React.Component {
    state = {};
    getSnapshotBeforeUpdate() {}
    componentWillMount() {}
    UNSAFE_componentWillUpdate() {}
    componentDidUpdate() {}
    render() {
      return null;
    }
  }

  expect(() => {
    expect(() =>
      ReactDOM.render(<WillMountAndUpdate />, container),
    ).toErrorDev(
      'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
        'WillMountAndUpdate uses getSnapshotBeforeUpdate() but also contains the following legacy lifecycles:\n' +
        '  componentWillMount\n' +
        '  UNSAFE_componentWillUpdate\n\n' +
        'The above lifecycles should be removed. Learn more about this warning here:\n' +
        'https://reactjs.org/link/unsafe-component-lifecycles',
    );
  }).toWarnDev(['componentWillMount has been renamed'], {
    withoutStack: true,
  });

  class WillReceiveProps extends React.Component {
    state = {};
    getSnapshotBeforeUpdate() {}
    componentWillReceiveProps() {}
    componentDidUpdate() {}
    render() {
      return null;
    }
  }

  expect(() => {
    expect(() => ReactDOM.render(<WillReceiveProps />, container)).toErrorDev(
      'Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' +
        'WillReceiveProps uses getSnapshotBeforeUpdate() but also contains the following legacy lifecycles:\n' +
        '  componentWillReceiveProps\n\n' +
        'The above lifecycles should be removed. Learn more about this warning here:\n' +
        'https://reactjs.org/link/unsafe-component-lifecycles',
    );
  }).toWarnDev(['componentWillReceiveProps has been renamed'], {
    withoutStack: true,
  });
});

if (!require('shared/ReactFeatureFlags').disableModulePatternComponents) {
  it('calls effects on module-pattern component', function () {
    const log = [];

    function Parent() {
      return {
        render() {
          expect(typeof this.props).toBe('object');
          log.push('render');
          return <Child />;
        },
        UNSAFE_componentWillMount() {
          log.push('will mount');
        },
        componentDidMount() {
          log.push('did mount');
        },
        componentDidUpdate() {
          log.push('did update');
        },
        getChildContext() {
          return {x: 2};
        },
      };
    }
    Parent.childContextTypes = {
      x: PropTypes.number,
    };
    function Child(props, context) {
      expect(context.x).toBe(2);
      return <div />;
    }
    Child.contextTypes = {
      x: PropTypes.number,
    };

    const div = document.createElement('div');
    expect(() =>
      ReactDOM.render(<Parent ref={c => c && log.push('ref')} />, div),
    ).toErrorDev(
      'Warning: The <Parent /> component appears to be a function component that returns a class instance. ' +
        'Change Parent to a class that extends React.Component instead. ' +
        "If you can't use a class try assigning the prototype on the function as a workaround. " +
        '`Parent.prototype = React.Component.prototype`. ' +
        "Don't use an arrow function since it cannot be called with `new` by React.",
    );
    ReactDOM.render(<Parent ref={c => c && log.push('ref')} />, div);

    expect(log).toEqual([
      'will mount',
      'render',
      'did mount',
      'ref',

      'render',
      'did update',
      'ref',
    ]);
  });
}

it('should warn if getDerivedStateFromProps returns undefined', () => {
  class MyComponent extends React.Component {
    state = {};
    static getDerivedStateFromProps() {}
    render() {
      return null;
    }
  }

  const div = document.createElement('div');
  expect(() => ReactDOM.render(<MyComponent />, div)).toErrorDev(
    'MyComponent.getDerivedStateFromProps(): A valid state object (or null) must ' +
      'be returned. You have returned undefined.',
  );

  // De-duped
  ReactDOM.render(<MyComponent />, div);
});

it('should warn if state is not initialized before getDerivedStateFromProps', () => {
  class MyComponent extends React.Component {
    static getDerivedStateFromProps() {
      return null;
    }
    render() {
      return null;
    }
  }

  const div = document.createElement('div');
  expect(() => ReactDOM.render(<MyComponent />, div)).toErrorDev(
    '`MyComponent` uses `getDerivedStateFromProps` but its initial state is ' +
      'undefined. This is not recommended. Instead, define the initial state by ' +
      'assigning an object to `this.state` in the constructor of `MyComponent`. ' +
      'This ensures that `getDerivedStateFromProps` arguments have a consistent shape.',
  );

  // De-duped
  ReactDOM.render(<MyComponent />, div);
});

it('should invoke both deprecated and new lifecycles if both are present', () => {
  const log = [];

  class MyComponent extends React.Component {
    componentWillMount() {
      log.push('componentWillMount');
    }
    componentWillReceiveProps() {
      log.push('componentWillReceiveProps');
    }
    componentWillUpdate() {
      log.push('componentWillUpdate');
    }
    UNSAFE_componentWillMount() {
      log.push('UNSAFE_componentWillMount');
    }
    UNSAFE_componentWillReceiveProps() {
      log.push('UNSAFE_componentWillReceiveProps');
    }
    UNSAFE_componentWillUpdate() {
      log.push('UNSAFE_componentWillUpdate');
    }
    render() {
      return null;
    }
  }

  const div = document.createElement('div');
  expect(() => ReactDOM.render(<MyComponent foo="bar" />, div)).toWarnDev(
    [
      'componentWillMount has been renamed',
      'componentWillReceiveProps has been renamed',
      'componentWillUpdate has been renamed',
    ],
    {withoutStack: true},
  );
  expect(log).toEqual(['componentWillMount', 'UNSAFE_componentWillMount']);

  log.length = 0;

  ReactDOM.render(<MyComponent foo="baz" />, div);
  expect(log).toEqual([
    'componentWillReceiveProps',
    'UNSAFE_componentWillReceiveProps',
    'componentWillUpdate',
    'UNSAFE_componentWillUpdate',
  ]);
});

it('should not override state with stale values if prevState is spread within getDerivedStateFromProps', () => {
  const divRef = React.createRef();
  let childInstance;

  class Child extends React.Component {
    state = {local: 0};
    static getDerivedStateFromProps(nextProps, prevState) {
      return {...prevState, remote: nextProps.remote};
    }
    updateState = () => {
      this.setState(state => ({local: state.local + 1}));
      this.props.onChange(this.state.remote + 1);
    };
    render() {
      childInstance = this;
      return (
        <div
          onClick={this.updateState}
          ref={
            divRef
          }>{`remote:${this.state.remote}, local:${this.state.local}`}</div>
      );
    }
  }

  class Parent extends React.Component {
    state = {value: 0};
    handleChange = value => {
      this.setState({value});
    };
    render() {
      return <Child remote={this.state.value} onChange={this.handleChange} />;
    }
  }

  const container = document.createElement('div');
  document.body.appendChild(container);
  try {
    ReactDOM.render(<Parent />, container);
    expect(divRef.current.textContent).toBe('remote:0, local:0');

    // Trigger setState() calls
    childInstance.updateState();
    expect(divRef.current.textContent).toBe('remote:1, local:1');

    // Trigger batched setState() calls
    divRef.current.click();
    expect(divRef.current.textContent).toBe('remote:2, local:2');
  } finally {
    document.body.removeChild(container);
  }
});

it('should pass the return value from getSnapshotBeforeUpdate to componentDidUpdate', () => {
  const log = [];

  class MyComponent extends React.Component {
    state = {
      value: 0,
    };
    static getDerivedStateFromProps(nextProps, prevState) {
      return {
        value: prevState.value + 1,
      };
    }
    getSnapshotBeforeUpdate(prevProps, prevState) {
      log.push(
        `getSnapshotBeforeUpdate() prevProps:${prevProps.value} prevState:${prevState.value}`,
      );
      return 'abc';
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
      log.push(
        `componentDidUpdate() prevProps:${prevProps.value} prevState:${prevState.value} snapshot:${snapshot}`,
      );
    }
    render() {
      log.push('render');
      return null;
    }
  }

  const div = document.createElement('div');
  ReactDOM.render(
    <div>
      <MyComponent value="foo" />
    </div>,
    div,
  );
  expect(log).toEqual(['render']);
  log.length = 0;

  ReactDOM.render(
    <div>
      <MyComponent value="bar" />
    </div>,
    div,
  );
  expect(log).toEqual([
    'render',
    'getSnapshotBeforeUpdate() prevProps:foo prevState:1',
    'componentDidUpdate() prevProps:foo prevState:1 snapshot:abc',
  ]);
  log.length = 0;

  ReactDOM.render(
    <div>
      <MyComponent value="baz" />
    </div>,
    div,
  );
  expect(log).toEqual([
    'render',
    'getSnapshotBeforeUpdate() prevProps:bar prevState:2',
    'componentDidUpdate() prevProps:bar prevState:2 snapshot:abc',
  ]);
  log.length = 0;

  ReactDOM.render(<div />, div);
  expect(log).toEqual([]);
});

it('should pass previous state to shouldComponentUpdate even with getDerivedStateFromProps', () => {
  const divRef = React.createRef();
  class SimpleComponent extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        value: props.value,
      };
    }

    static getDerivedStateFromProps(nextProps, prevState) {
      if (nextProps.value === prevState.value) {
        return null;
      }
      return {value: nextProps.value};
    }

    shouldComponentUpdate(nextProps, nextState) {
      return nextState.value !== this.state.value;
    }

    render() {
      return <div ref={divRef}>value: {this.state.value}</div>;
    }
  }

  const div = document.createElement('div');

  ReactDOM.render(<SimpleComponent value="initial" />, div);
  expect(divRef.current.textContent).toBe('value: initial');
  ReactDOM.render(<SimpleComponent value="updated" />, div);
  expect(divRef.current.textContent).toBe('value: updated');
});

it('should call getSnapshotBeforeUpdate before mutations are committed', () => {
  const log = [];

  class MyComponent extends React.Component {
    divRef = React.createRef();
    getSnapshotBeforeUpdate(prevProps, prevState) {
      log.push('getSnapshotBeforeUpdate');
      expect(this.divRef.current.textContent).toBe(
        `value:${prevProps.value}`,
      );
      return 'foobar';
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
      log.push('componentDidUpdate');
      expect(this.divRef.current.textContent).toBe(
        `value:${this.props.value}`,
      );
      expect(snapshot).toBe('foobar');
    }
    render() {
      log.push('render');
      return <div ref={this.divRef}>{`value:${this.props.value}`}</div>;
    }
  }

  const div = document.createElement('div');
  ReactDOM.render(<MyComponent value="foo" />, div);
  expect(log).toEqual(['render']);
  log.length = 0;

  ReactDOM.render(<MyComponent value="bar" />, div);
  expect(log).toEqual([
    'render',
    'getSnapshotBeforeUpdate',
    'componentDidUpdate',
  ]);
  log.length = 0;
});

it('should warn if getSnapshotBeforeUpdate returns undefined', () => {
  class MyComponent extends React.Component {
    getSnapshotBeforeUpdate() {}
    componentDidUpdate() {}
    render() {
      return null;
    }
  }

  const div = document.createElement('div');
  ReactDOM.render(<MyComponent value="foo" />, div);
  expect(() => ReactDOM.render(<MyComponent value="bar" />, div)).toErrorDev(
    'MyComponent.getSnapshotBeforeUpdate(): A snapshot value (or null) must ' +
      'be returned. You have returned undefined.',
  );

  // De-duped
  ReactDOM.render(<MyComponent value="baz" />, div);
});

it('should warn if getSnapshotBeforeUpdate is defined with no componentDidUpdate', () => {
  class MyComponent extends React.Component {
    getSnapshotBeforeUpdate() {
      return null;
    }
    render() {
      return null;
    }
  }

  const div = document.createElement('div');
  expect(() => ReactDOM.render(<MyComponent />, div)).toErrorDev(
    'MyComponent: getSnapshotBeforeUpdate() should be used with componentDidUpdate(). ' +
      'This component defines getSnapshotBeforeUpdate() only.',
  );

  // De-duped
  ReactDOM.render(<MyComponent />, div);
});

it('warns about deprecated unsafe lifecycles', function () {
  class MyComponent extends React.Component {
    componentWillMount() {}
    componentWillReceiveProps() {}
    componentWillUpdate() {}
    render() {
      return null;
    }
  }

  const container = document.createElement('div');
  expect(() => ReactDOM.render(<MyComponent x={1} />, container)).toWarnDev(
    [
      /* eslint-disable max-len */
      `Warning: componentWillMount has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.
* Rename componentWillMount to UNSAFE_componentWillMount to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: MyComponent`,
      `Warning: componentWillReceiveProps has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state
* Rename componentWillReceiveProps to UNSAFE_componentWillReceiveProps to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: MyComponent`,
      `Warning: componentWillUpdate has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* Rename componentWillUpdate to UNSAFE_componentWillUpdate to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: MyComponent`,
      /* eslint-enable max-len */
    ],
    {withoutStack: true},
  );

  // Dedupe check (update and instantiate new)
  ReactDOM.render(<MyComponent x={2} />, container);
  ReactDOM.render(<MyComponent key="new" x={1} />, container);
});

describe('react-lifecycles-compat', () => {
  const {polyfill} = require('react-lifecycles-compat');

  it('should not warn for components with polyfilled getDerivedStateFromProps', () => {
    class PolyfilledComponent extends React.Component {
      state = {};
      static getDerivedStateFromProps() {
        return null;
      }
      render() {
        return null;
      }
    }

    polyfill(PolyfilledComponent);

    const container = document.createElement('div');
    ReactDOM.render(
      <React.StrictMode>
        <PolyfilledComponent />
      </React.StrictMode>,
      container,
    );
  });

  it('should not warn for components with polyfilled getSnapshotBeforeUpdate', () => {
    class PolyfilledComponent extends React.Component {
      getSnapshotBeforeUpdate() {
        return null;
      }
      componentDidUpdate() {}
      render() {
        return null;
      }
    }

    polyfill(PolyfilledComponent);

    const container = document.createElement('div');
    ReactDOM.render(
      <React.StrictMode>
        <PolyfilledComponent />
      </React.StrictMode>,
      container,
    );
  });
});
