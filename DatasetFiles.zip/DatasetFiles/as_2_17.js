class AnotherTestComponent extends React.PureComponent {
    render() {
      return <TheChartWithWillUnmountHook id="another_test" />;
    }
}

  
