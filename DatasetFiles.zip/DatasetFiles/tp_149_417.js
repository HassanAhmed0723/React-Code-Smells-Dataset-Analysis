function QueryPreviewModal({
    onHide,
    openInSqlLab,
    queries,
    query,
    fetchData,
    show,
    addDangerToast,
    addSuccessToast,
  }: QueryPreviewModalProps)