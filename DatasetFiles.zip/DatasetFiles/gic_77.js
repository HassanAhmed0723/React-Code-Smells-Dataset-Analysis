function ServerModelComponent({ serverModel }) {
    return (
        <div>
            {/* Render serverModel data */}
        </div>
    );
}

function ClientBaz() {
    return (
        <div>
            {/* Render ClientBaz content */}
        </div>
    );
}

function ClientApp({ serverModel }) {
    return (
        <div>
            <ServerModelComponent serverModel={serverModel} />
            <ClientBaz />
        </div>
    );
}

ReactDOM.render(<ClientApp serverModel={/* pass serverModel here */} />, document.getElementById("root"));
