export default function EditableTitle({
    canEdit = false,
    editing = false,
    extraClasses,
    multiLine = false,
    noPermitTooltip,
    onSaveTitle,
    showTooltip = true,
    style,
    title = '',
    defaultTitle = '',
    placeholder = '',
    certifiedBy,
    certificationDetails,
    url,
    // rest is related to title tooltip
    ...rest
  }: EditableTitleProps)