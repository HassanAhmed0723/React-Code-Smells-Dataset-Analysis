const ControlHeader: FC<ControlHeaderProps> = ({
    name,
    label,
    description,
    validationErrors = [],
    renderTrigger = false,
    rightNode,
    leftNode,
    onClick,
    hovered = false,
    tooltipOnClick = () => {},
    warning,
    danger,
  })