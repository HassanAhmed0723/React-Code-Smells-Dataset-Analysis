export class AnotherComponent extends PureComponent {
  static propTypes = {
    followerIndices: PropTypes.array,
    selectFollowerIndex: PropTypes.func.isRequired,
  };

  constructor(props) {
    super(props);

    this.state = {
      ...initialState,
      prevFollowerIndices: props.followerIndices,
      queryText: '',
    };
  }

  static getDerivedStateFromProps(props, state) {
    const { followerIndices } = props;
    const { prevFollowerIndices, queryText } = state;

    // If a follower index gets deleted, we need to recreate the cached filtered follower indices.
    if (prevFollowerIndices !== followerIndices) {
      return {
        prevFollowerIndices: followerIndices,
        filteredIndices: getFilteredIndices(followerIndices, queryText),
      };
    }

    return null;
  }

  // ... Rest of the component's code
}
