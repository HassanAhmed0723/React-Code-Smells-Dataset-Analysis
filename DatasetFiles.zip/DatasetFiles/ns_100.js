export function getLayer(
    formData: QueryFormData,
    payload: JsonObject,
    onAddFilter: () => void,
    setTooltip: (tooltip: TooltipProps['tooltip']) => void,
  ) {
    const fd = formData;
    const c = fd.color_picker;
    const fixedColor = [c.r, c.g, c.b, 255 * c.a];
    let data = payload.data.features.map((feature: JsonObject) => ({
      ...feature,
      path: feature.path,
      width: fd.line_width,
      color: fixedColor,
    }));
  
    if (fd.js_data_mutator) {
      const jsFnMutator = sandboxedEval(fd.js_data_mutator);
      data = jsFnMutator(data);
    }
  
    return new PathLayer({
      id: `path-layer-${fd.slice_id}` as const,
      getColor: d => d.color,
      getPath: d => d.path,
      getWidth: d => d.width,
      data,
      rounded: true,
      widthScale: 1,
      widthUnits: fd.line_width_unit,
      ...commonLayerProps(fd, setTooltip, setTooltipContent),
    });
  }