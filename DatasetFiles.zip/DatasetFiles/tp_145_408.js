function ChartTable({
    user,
    addDangerToast,
    addSuccessToast,
    mine,
    showThumbnails,
    otherTabData,
    otherTabFilters,
    otherTabTitle,
  }: ChartTableProps)