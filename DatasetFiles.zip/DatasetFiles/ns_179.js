export const MediumEmptyState = () => (
    <EmptyStateMedium
      image={<ChartImage />}
      title="Medium empty state"
      description="This is an example of a medium empty state"
    />
  );