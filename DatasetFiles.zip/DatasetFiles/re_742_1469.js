class PolyfilledComponent extends React.Component {
  state = {};
  static getDerivedStateFromProps() {
    return null;
  }
  render() {
    return null;
  }
}
