export default function ColumnConfigControl<T extends ColumnConfig>({
    queryResponse,
    appliedColumnNames = [],
    value,
    onChange,
    configFormLayout = DEFAULT_CONFIG_FORM_LAYOUT,
    ...props
  }: ColumnConfigControlProps<T>)