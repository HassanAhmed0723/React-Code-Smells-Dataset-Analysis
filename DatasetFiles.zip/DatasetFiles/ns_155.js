export const MenuItemWithTruncation = ({
    tooltipText,
    children,
    ...props
  }: MenuItemWithTruncationProps) => {
    const [itemRef, itemIsTruncated] = useCSSTextTruncation<HTMLDivElement>();
  
    return (
      <Menu.Item
        css={css`
          display: flex;
        `}
        {...props}
      >
        <Tooltip title={itemIsTruncated ? tooltipText : null}>
          <div
            ref={itemRef}
            css={css`
              max-width: 100%;
              ${truncationCSS};
            `}
          >
            {children}
          </div>
        </Tooltip>
      </Menu.Item>
    );
  };