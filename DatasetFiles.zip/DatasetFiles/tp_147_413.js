const RightMenu = ({
    align,
    settings,
    navbarRight,
    isFrontendRoute,
    environmentTag,
    setQuery,
  }: RightMenuProps & {
    setQuery: ({
      databaseAdded,
      datasetAdded,
    }: {
      databaseAdded?: boolean;
      datasetAdded?: boolean;
    }) => void;
  })