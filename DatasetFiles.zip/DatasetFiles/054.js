<div className="editor">
        <Toolbar>
          <Themes
            theme={theme}
            highlights={highlights}
            update={this.updateTheme}
            updateHighlights={this.updateHighlights}
            remove={this.removeTheme}
            create={this.createTheme}
            themes={this.props.themes}
          />
          <Dropdown
            title="Language"
            icon={languageIcon}
            selected={
              LANGUAGE_NAME_HASH[language] ||
              LANGUAGE_MIME_HASH[language] ||
              LANGUAGE_MODE_HASH[language] ||
              LANGUAGE_MODE_HASH[DEFAULT_LANGUAGE]
            }
            list={LANGUAGES}
            onChange={this.updateLanguage}
          />
          <div className="toolbar-second-row">
            <div className="setting-buttons">
              <BackgroundSelect
                onChange={this.updateBackground}
                updateHighlights={this.updateHighlights}
                mode={backgroundMode}
                color={backgroundColor}
                image={backgroundImage}
                carbonRef={this.carbonNode.current}
              />
              <Settings
                {...config}
                onChange={this.updateSetting}
                resetDefaultSettings={this.resetDefaultSettings}
                format={this.format}
                applyPreset={this.applyPreset}
                getCarbonImage={this.getCarbonImage}
              />
              <CopyMenu copyImage={this.copyImage} carbonRef={this.carbonNode.current} />
            </div>
            <div id="style-editor-button" />
            <div className="share-buttons">
              <ShareMenu tweet={this.tweet} imgur={this.imgur} />
              <ExportMenu
                onChange={this.updateSetting}
                exportImage={this.exportImage}
                exportSize={exportSize}
              />
            </div>
          </div>
        </Toolbar>

        <Dropzone accept="image/*, text/*, application/*" onDrop={this.onDrop}>
          {({ canDrop }) => (
            <Overlay
              isOver={canDrop}
              title={`Drop your file here to import ${canDrop ? '✋' : '✊'}`}
            >
              {/*key ensures Carbon's internal language state is updated when it's changed by Dropdown*/}
              <Carbon
                key={language}
                ref={this.carbonNode}
                config={this.state}
                onChange={this.updateCode}
                updateWidth={this.updateWidth}
                updateWidthConfirm={this.sync}
                loading={this.state.loading}
                theme={theme}
                titleBar={titleBar}
                onTitleBarChange={this.updateTitleBar}
              >
                {code != null ? code : DEFAULT_CODE}
              </Carbon>
            </Overlay>
          )}
        </Dropzone>
        <SnippetToolbar
          state={this.state}
          snippet={this.props.snippet}
          onCreate={this.handleSnippetCreate}
          onDelete={this.handleSnippetDelete}
          onUpdate={this.handleSnippetUpdate}
          name={config.name}
          onChange={this.updateSetting}
        />
        <FontFace {...config} />
        <style jsx>
          {`
            .editor {
              background: ${COLORS.BLACK};
              border: 3px solid ${COLORS.SECONDARY};
              border-radius: 8px;
              padding: 16px;
            }

            .share-buttons,
            .setting-buttons {
              display: flex;
              height: 40px;
            }
            .share-buttons {
              margin-left: auto;
            }
            .toolbar-second-row {
              display: flex;
              flex: 1 1 auto;
            }
            .setting-buttons > :global(div) {
              margin-right: 0.5rem;
            }

            #style-editor-button {
              display: flex;
              align-items: center;
            }
            @media (max-width: 768px) {
              .toolbar-second-row {
                display: block;
              }
              #style-editor-button {
                margin-top: 0.5rem;
              }
            }
          `}
        </style>
      </div>
    )
  }
}

Editor.defaultProps = {
  onUpdate: () => {},
  onReset: () => {},
}

