
class App extends Component {
  constructor(props) {
    super(props);

    this.sidebarRef = createRef();
    this.reactotronTerminalRef = createRef();
  }

  componentDidMount() {
    ipcRenderer.on("toggle-side-menu", this.handleSideMenuToggle);
  }

  handleSideMenuToggle = () => {
    this.sidebarRef.current.toggleSidebar();
  };

  render() {
    const { ui } = this.props.session;
    const showHome = ui.tab === "home";
    const showTimeline = ui.tab === "timeline";
    const showHelp = ui.tab === "help";
    const showSettings = ui.tab === "settings";
    const showNative = ui.tab === "native";
    const showState = ui.tab === "state";
    const showCustomCommands = ui.tab === "customCommands";

    return (
      <Provider session={this.props.session}>
        <div style={Styles.container}>
          <div style={Styles.content}>
            {!ui.inTerminal && (
              <div style={Styles.body}>
                <Sidebar ref={this.sidebarRef} />
                <div style={Styles.app}>
                  <div style={showHome ? Styles.page : Styles.pageHidden}>
                    <Home />
                  </div>
                  <div style={showTimeline ? Styles.page : Styles.pageHidden}>
                    <Timeline />
                  </div>
                  <div style={showState ? Styles.page : Styles.pageHidden}>
                    <State />
                  </div>
                  <div style={showHelp ? Styles.page : Styles.pageHidden}>
                    <Help />
                  </div>
                  <div style={showNative ? Styles.page : Styles.pageHidden}>
                    <Native />
                  </div>
                  <div style={showCustomCommands ? Styles.page : Styles.pageHidden}>
                    <CustomCommandsList />
                  </div>
                  <div style={showSettings ? Styles.page : Styles.pageHidden}>
                    <h1>Settings</h1>
                  </div>
                </div>
              </div>
            )}
            {ui.inTerminal && (
              <div style={Styles.body}>
                <div style={Styles.app}>
                  <div style={Styles.page}>
                    <ReactotronTerminal ref={this.reactotronTerminalRef} />
                  </div>
                </div>
              </div>
            )}
            <StatusBar />
          </div>
          <StateKeysAndValuesDialog />
          <StateDispatchDialog />
          <StateWatchDialog />
          <RenameStateDialog />
          <FilterTimelineDialog />
          <ExportTimelineDialog />
          <SendCustomDialog />
        </div>
      </Provider>
    );
  }
}

export default App;
