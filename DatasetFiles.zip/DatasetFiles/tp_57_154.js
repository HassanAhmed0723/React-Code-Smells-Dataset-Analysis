function ColumnCollectionTable({
    columns,
    datasource,
    onColumnsChange,
    onDatasourceChange,
    editableColumnName,
    showExpression,
    allowAddItem,
    allowEditDataType,
    itemGenerator,
  }) 