<input
hidden
ref={input}
type="file"
accept=".json"
onChange={async e => {
  const json = await fileToJSON(e.target.files[0])
  if (json) {
    applyPreset(json)
  }
}}
/>
<Button
center
style={{ borderRight: `1px solid ${COLORS.SECONDARY}` }}
onClick={() => input.current.click()}
>
Import config
</Button>
<Button center Component="a" href={download} download="carbon-config.json">
Export config
</Button>
</div>
<Button center onClick={format} style={resetButtonStyle}>
Prettify code
</Button>
<Button center color={COLORS.RED} onClick={reset} style={resetButtonStyle}>
Reset settings
</Button>
<style jsx>
{`
.row {
  flex: 1;
}
.settings-content {
  display: flex;
  flex-direction: column;
}
.settings-content :global(a) {
  display: flex;
  flex: 1;
  user-drag: none;
}
`}
</style>
</div>
)
}
