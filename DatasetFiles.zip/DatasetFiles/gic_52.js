class BaseComponent extends React.Component {
    componentDidMount() {
        console.log("BaseComponent mounted");
    }

    render() {
        return <div>BaseComponent content</div>;
    }
}

class ExtendedComponent extends BaseComponent {
    componentDidMount() {
        super.componentDidMount();
        console.log("ExtendedComponent mounted");
    }

    render() {
        return (
            <div>
                <p>ExtendedComponent content</p>
                {super.render()}
            </div>
        );
    }
}

function App() {
    return (
        <div>
            <ExtendedComponent />
        </div>
    );
}

ReactDOM.render(<App />, document.getElementById("root"));
