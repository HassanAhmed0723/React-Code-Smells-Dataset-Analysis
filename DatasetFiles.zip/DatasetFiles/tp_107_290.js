const SliceHeaderControls = (props: SliceHeaderControlsPropsWithRouter) => {
    const [openScopingModal, scopingModal] = useCrossFiltersScopingModal(
      props.slice.slice_id,
    );
  
    const canEditCrossFilters =
      useSelector<RootState, boolean>(
        ({ dashboardInfo }) => dashboardInfo.dash_edit_perm,
      ) &&
      isFeatureEnabled(FeatureFlag.DASHBOARD_CROSS_FILTERS) &&
      getChartMetadataRegistry()
        .get(props.slice.viz_type)
        ?.behaviors?.includes(Behavior.INTERACTIVE_CHART);
  
    const refreshChart = () => {
      if (props.updatedDttm) {
        props.forceRefresh(props.slice.slice_id, props.dashboardId);
      }
    };
  
    const handleMenuClick = ({
      key,
      domEvent,
    }: {
      key: Key;
      domEvent: MouseEvent<HTMLElement>;
    }) => {
      switch (key) {
        case MENU_KEYS.FORCE_REFRESH:
          refreshChart();
          props.addSuccessToast(t('Data refreshed'));
          break;
        case MENU_KEYS.TOGGLE_CHART_DESCRIPTION:
          // eslint-disable-next-line no-unused-expressions
          props.toggleExpandSlice?.(props.slice.slice_id);
          break;
        case MENU_KEYS.EXPLORE_CHART:
          // eslint-disable-next-line no-unused-expressions
          props.logExploreChart?.(props.slice.slice_id);
          break;
        case MENU_KEYS.EXPORT_CSV:
          // eslint-disable-next-line no-unused-expressions
          props.exportCSV?.(props.slice.slice_id);
          break;
        case MENU_KEYS.FULLSCREEN:
          props.handleToggleFullSize();
          break;
        case MENU_KEYS.EXPORT_FULL_CSV:
          // eslint-disable-next-line no-unused-expressions
          props.exportFullCSV?.(props.slice.slice_id);
          break;
        case MENU_KEYS.EXPORT_XLSX:
          // eslint-disable-next-line no-unused-expressions
          props.exportXLSX?.(props.slice.slice_id);
          break;
        case MENU_KEYS.DOWNLOAD_AS_IMAGE: {
          // menu closes with a delay, we need to hide it manually,
          // so that we don't capture it on the screenshot
          const menu = document.querySelector(
            '.ant-dropdown:not(.ant-dropdown-hidden)',
          ) as HTMLElement;
          menu.style.visibility = 'hidden';
          downloadAsImage(
            getScreenshotNodeSelector(props.slice.slice_id),
            props.slice.slice_name,
            true,
            // @ts-ignore
          )(domEvent).then(() => {
            menu.style.visibility = 'visible';
          });
          props.logEvent?.(LOG_ACTIONS_CHART_DOWNLOAD_AS_IMAGE, {
            chartId: props.slice.slice_id,
          });
          break;
        }
        case MENU_KEYS.CROSS_FILTER_SCOPING: {
          openScopingModal();
          break;
        }
        default:
          break;
      }
    };
  
    const {
      componentId,
      dashboardId,
      slice,
      isFullSize,
      cachedDttm = [],
      updatedDttm = null,
      addSuccessToast = () => {},
      addDangerToast = () => {},
      supersetCanShare = false,
      isCached = [],
    } = props;
    const isTable = slice.viz_type === 'table';
    const cachedWhen = (cachedDttm || []).map(itemCachedDttm =>
      moment.utc(itemCachedDttm).fromNow(),
    );
    const updatedWhen = updatedDttm ? moment.utc(updatedDttm).fromNow() : '';
    const getCachedTitle = (itemCached: boolean) => {
      if (itemCached) {
        return t('Cached %s', cachedWhen);
      }
      if (updatedWhen) {
        return t('Fetched %s', updatedWhen);
      }
      return '';
    };
    const refreshTooltipData = [...new Set(isCached.map(getCachedTitle) || '')];
    // If all queries have same cache time we can unit them to one
    const refreshTooltip = refreshTooltipData.map((item, index) => (
      <div key={`tooltip-${index}`}>
        {refreshTooltipData.length > 1
          ? t('Query %s: %s', index + 1, item)
          : item}
      </div>
    ));
    const fullscreenLabel = isFullSize
      ? t('Exit fullscreen')
      : t('Enter fullscreen');
  
    const menu = (
      <Menu
        onClick={handleMenuClick}
        selectable={false}
        data-test={`slice_${slice.slice_id}-menu`}
      >
        <Menu.Item
          key={MENU_KEYS.FORCE_REFRESH}
          disabled={props.chartStatus === 'loading'}
          style={{ height: 'auto', lineHeight: 'initial' }}
          data-test="refresh-chart-menu-item"
        >
          {t('Force refresh')}
          <RefreshTooltip data-test="dashboard-slice-refresh-tooltip">
            {refreshTooltip}
          </RefreshTooltip>
        </Menu.Item>
  
        <Menu.Item key={MENU_KEYS.FULLSCREEN}>{fullscreenLabel}</Menu.Item>
  
        <Menu.Divider />
  
        {slice.description && (
          <Menu.Item key={MENU_KEYS.TOGGLE_CHART_DESCRIPTION}>
            {props.isDescriptionExpanded
              ? t('Hide chart description')
              : t('Show chart description')}
          </Menu.Item>
        )}
  
        {props.supersetCanExplore && (
          <Menu.Item key={MENU_KEYS.EXPLORE_CHART}>
            <Link to={props.exploreUrl}>
              <Tooltip title={getSliceHeaderTooltip(props.slice.slice_name)}>
                {t('Edit chart')}
              </Tooltip>
            </Link>
          </Menu.Item>
        )}
  
        {canEditCrossFilters && (
          <>
            <Menu.Item key={MENU_KEYS.CROSS_FILTER_SCOPING}>
              {t('Cross-filtering scoping')}
            </Menu.Item>
            <Menu.Divider />
          </>
        )}
  
        {props.supersetCanExplore && (
          <Menu.Item key={MENU_KEYS.VIEW_QUERY}>
            <ModalTrigger
              triggerNode={
                <span data-test="view-query-menu-item">{t('View query')}</span>
              }
              modalTitle={t('View query')}
              modalBody={<ViewQueryModal latestQueryFormData={props.formData} />}
              draggable
              resizable
              responsive
            />
          </Menu.Item>
        )}
  
        {props.supersetCanExplore && (
          <Menu.Item key={MENU_KEYS.VIEW_RESULTS}>
            <ViewResultsModalTrigger
              exploreUrl={props.exploreUrl}
              triggerNode={
                <span data-test="view-query-menu-item">{t('View as table')}</span>
              }
              modalTitle={t('Chart Data: %s', slice.slice_name)}
              modalBody={
                <ResultsPaneOnDashboard
                  queryFormData={props.formData}
                  queryForce={false}
                  dataSize={20}
                  isRequest
                  isVisible
                />
              }
            />
          </Menu.Item>
        )}
  
        {isFeatureEnabled(FeatureFlag.DRILL_TO_DETAIL) &&
          props.supersetCanExplore && (
            <DrillDetailMenuItems
              chartId={slice.slice_id}
              formData={props.formData}
            />
          )}
  
        {(slice.description || props.supersetCanExplore) && <Menu.Divider />}
  
        {supersetCanShare && (
          <Menu.SubMenu title={t('Share')}>
            <ShareMenuItems
              dashboardId={dashboardId}
              dashboardComponentId={componentId}
              copyMenuItemTitle={t('Copy permalink to clipboard')}
              emailMenuItemTitle={t('Share chart by email')}
              emailSubject={t('Superset chart')}
              emailBody={t('Check out this chart: ')}
              addSuccessToast={addSuccessToast}
              addDangerToast={addDangerToast}
            />
          </Menu.SubMenu>
        )}
  
        {props.slice.viz_type !== 'filter_box' && props.supersetCanCSV && (
          <Menu.SubMenu title={t('Download')}>
            <Menu.Item
              key={MENU_KEYS.EXPORT_CSV}
              icon={<Icons.FileOutlined css={dropdownIconsStyles} />}
            >
              {t('Export to .CSV')}
            </Menu.Item>
  
            {props.slice.viz_type !== 'filter_box' &&
              isFeatureEnabled(FeatureFlag.ALLOW_FULL_CSV_EXPORT) &&
              props.supersetCanCSV &&
              isTable && (
                <Menu.Item
                  key={MENU_KEYS.EXPORT_FULL_CSV}
                  icon={<Icons.FileOutlined css={dropdownIconsStyles} />}
                >
                  {t('Export to full .CSV')}
                </Menu.Item>
              )}
  
            <Menu.Item
              key={MENU_KEYS.EXPORT_XLSX}
              icon={<Icons.FileOutlined css={dropdownIconsStyles} />}
            >
              {t('Export to Excel')}
            </Menu.Item>
            <Menu.Item
              key={MENU_KEYS.DOWNLOAD_AS_IMAGE}
              icon={<Icons.FileImageOutlined css={dropdownIconsStyles} />}
            >
              {t('Download as image')}
            </Menu.Item>
          </Menu.SubMenu>
        )}
      </Menu>
    );
  
    return (
      <>
        {isFullSize && (
          <Icons.FullscreenExitOutlined
            style={{ fontSize: 22 }}
            onClick={() => {
              props.handleToggleFullSize();
            }}
          />
        )}
        <NoAnimationDropdown
          overlay={menu}
          trigger={['click']}
          placement="bottomRight"
        >
          <span
            css={css`
              display: flex;
              align-items: center;
            `}
            id={`slice_${slice.slice_id}-controls`}
            role="button"
            aria-label="More Options"
          >
            <VerticalDotsTrigger />
          </span>
        </NoAnimationDropdown>
        {canEditCrossFilters && scopingModal}
      </>
    );
  };
  