export class DiligentChartPlugin extends ChartPlugin<QueryFormData> {
    constructor() {
      super({
        metadata: new ChartMetadata({
          name: ChartKeys.DILIGENT,
          thumbnail: '',
        }),
        Chart: TestComponent,
        transformProps: x => x,
      });
    }
  }