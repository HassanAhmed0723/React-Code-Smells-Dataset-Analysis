interface Props {
  initialPercentiles: number[];
  onChange: (percentiles: number[]) => void;
}

interface State {
  percentiles: number[];
}

const initialState: State = {
  percentiles: [],
};

export class AnotherComponent extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      percentiles: props.initialPercentiles,
    };
  }

  _onSubmit = () => {
    const hasInvalidPercentile = this.state.percentiles.some(isInvalidPercentile);
    if (!hasInvalidPercentile) {
      this.props.onChange(this.state.percentiles);
    }
  };

  // ... Rest of the component's code
}
