export const OptionControlLabel = ({
    label,
    savedMetric,
    adhocMetric,
    onRemove,
    onMoveLabel,
    onDropLabel,
    withCaret,
    isFunction,
    type,
    index,
    isExtra,
    datasourceWarningMessage,
    tooltipTitle,
    multi = true,
    ...props
  }: {
    label: string | React.ReactNode;
    savedMetric?: savedMetricType;
    adhocMetric?: AdhocMetric;
    onRemove: () => void;
    onMoveLabel: (dragIndex: number, hoverIndex: number) => void;
    onDropLabel: () => void;
    withCaret?: boolean;
    isFunction?: boolean;
    isDraggable?: boolean;
    type: string;
    index: number;
    isExtra?: boolean;
    datasourceWarningMessage?: string;
    tooltipTitle?: string;
    multi?: boolean;
  }) 