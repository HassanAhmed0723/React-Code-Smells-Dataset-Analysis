class CustomSystemUsersList extends React.PureComponent {
  static propTypes = {
    filter: PropTypes.string,
    teamId: PropTypes.string,
    nextPage: PropTypes.func,
    search: PropTypes.func,
    users: PropTypes.arrayOf(PropTypes.object),
    mfaEnabled: PropTypes.bool,
    enableUserAccessTokens: PropTypes.bool,
    experimentalEnableAuthenticationTransfer: PropTypes.bool,
    isDisabled: PropTypes.bool,
    term: PropTypes.string,
    onTermChange: PropTypes.func,
  };

  constructor(props) {
    super(props);

    this.state = {
      page: 0,
      filter: props.filter,
      teamId: props.teamId,
      showManageTeamsModal: false,
      showManageRolesModal: false,
      showManageTokensModal: false,
      showPasswordModal: false,
      showEmailModal: false,
      user: undefined,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (
      prevState.teamId !== nextProps.teamId ||
      prevState.filter !== nextProps.filter
    ) {
      return {
        page: 0,
        teamId: nextProps.teamId,
        filter: nextProps.filter,
      };
    }
    return null;
  }

  nextPage = () => {
    this.setState({ page: this.state.page + 1 });

    this.props.nextPage(this.state.page + 1);
  };

  render() {
    const extraInfo = {};
    if (this.props.users) {
      for (const user of this.props.users) {
        extraInfo[user.id] = this.getInfoForUser(user);
      }
    }

    return (
      <div>
      </div>
    );
  }
}
