class SuperChart extends React.PureComponent<Props, {}> {
    /**
     * SuperChart's core
     */
    core?: SuperChartCore | null;
  
    private createChartProps = ChartProps.createSelector();
  
    private parseDimension = createSelector(
      [
        ({ width }: { width: string | number; height: string | number }) => width,
        ({ height }) => height,
      ],
      (width, height) => {
        // Parse them in case they are % or 'auto'
        const widthInfo = parseLength(width);
        const heightInfo = parseLength(height);
  
        const boxHeight = heightInfo.isDynamic
          ? `${heightInfo.multiplier * 100}%`
          : heightInfo.value;
        const boxWidth = widthInfo.isDynamic
          ? `${widthInfo.multiplier * 100}%`
          : widthInfo.value;
        const style = {
          height: boxHeight,
          width: boxWidth,
        };
  
        // bounding box will ensure that when one dimension is not dynamic
        // e.g. height = 300
        // the auto size will be bound to that value instead of being 100% by default
        // e.g. height: 300 instead of height: '100%'
        const BoundingBox =
          widthInfo.isDynamic &&
          heightInfo.isDynamic &&
          widthInfo.multiplier === 1 &&
          heightInfo.multiplier === 1
            ? React.Fragment
            : ({ children }: { children: ReactNode }) => (
                <div style={style}>{children}</div>
              );
  
        return { BoundingBox, heightInfo, widthInfo };
      },
    );
  
    static defaultProps = defaultProps;
  
    private setRef = (core: SuperChartCore | null) => {
      this.core = core;
    };
  
    private getQueryCount = () =>
      getChartMetadataRegistry().get(this.props.chartType)?.queryObjectCount ?? 1;
  
    renderChart(width: number, height: number) {
      const {
        id,
        className,
        chartType,
        preTransformProps,
        overrideTransformProps,
        postTransformProps,
        onRenderSuccess,
        onRenderFailure,
        disableErrorBoundary,
        FallbackComponent,
        onErrorBoundary,
        Wrapper,
        queriesData,
        enableNoResults,
        noResults,
        theme,
        ...rest
      } = this.props as PropsWithDefault;
  
      const chartProps = this.createChartProps({
        ...rest,
        queriesData,
        height,
        width,
        theme,
      });
  
      let chart;
      // Render the no results component if the query data is null or empty
      const noResultQueries =
        enableNoResults &&
        (!queriesData ||
          queriesData
            .slice(0, this.getQueryCount())
            .every(
              ({ data }) => !data || (Array.isArray(data) && data.length === 0),
            ));
      if (noResultQueries) {
        chart = noResults || (
          <NoResultsComponent
            id={id}
            className={className}
            height={height}
            width={width}
          />
        );
      } else {
        const chartWithoutWrapper = (
          <SuperChartCore
            ref={this.setRef}
            id={id}
            className={className}
            chartType={chartType}
            chartProps={chartProps}
            preTransformProps={preTransformProps}
            overrideTransformProps={overrideTransformProps}
            postTransformProps={postTransformProps}
            onRenderSuccess={onRenderSuccess}
            onRenderFailure={onRenderFailure}
          />
        );
        chart = Wrapper ? (
          <Wrapper width={width} height={height}>
            {chartWithoutWrapper}
          </Wrapper>
        ) : (
          chartWithoutWrapper
        );
      }
      // Include the error boundary by default unless it is specifically disabled.
      return disableErrorBoundary === true ? (
        chart
      ) : (
        <ErrorBoundary
          FallbackComponent={(props: FallbackProps) => (
            <FallbackComponent width={width} height={height} {...props} />
          )}
          onError={onErrorBoundary}
        >
          {chart}
        </ErrorBoundary>
      );
    }
  
    render() {
      const { heightInfo, widthInfo, BoundingBox } = this.parseDimension(
        this.props as PropsWithDefault,
      );
  
      // If any of the dimension is dynamic, get parent's dimension
      if (widthInfo.isDynamic || heightInfo.isDynamic) {
        const { debounceTime } = this.props;
  
        return (
          <BoundingBox>
            <ParentSize debounceTime={debounceTime}>
              {({ width, height }) =>
                this.renderChart(
                  widthInfo.isDynamic ? Math.floor(width) : widthInfo.value,
                  heightInfo.isDynamic ? Math.floor(height) : heightInfo.value,
                )
              }
            </ParentSize>
          </BoundingBox>
        );
      }
  
      return this.renderChart(widthInfo.value, heightInfo.value);
    }
  }