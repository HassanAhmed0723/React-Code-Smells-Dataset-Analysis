const PropertiesModal = ({
    addSuccessToast,
    addDangerToast,
    colorScheme: currentColorScheme,
    dashboardId,
    dashboardInfo: currentDashboardInfo,
    dashboardTitle,
    onHide = () => {},
    onlyApply = false,
    onSubmit = () => {},
    show = false,
  }: PropertiesModalProps) 