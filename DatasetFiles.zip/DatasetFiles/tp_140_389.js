const AlertReportModal: FunctionComponent<AlertReportModalProps> = ({
    addDangerToast,
    onAdd,
    onHide,
    show,
    alert = null,
    isReport = false,
    addSuccessToast,
  })